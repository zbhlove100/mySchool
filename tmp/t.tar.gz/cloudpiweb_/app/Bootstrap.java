import play.jobs.Job;
import play.jobs.OnApplicationStart;
 
@OnApplicationStart
public class Bootstrap extends Job {
 
    public void doJob() {
//        if(Account.count() == 0) {
//            //Fixtures.loadYaml("initial-data.yml");
//        	String path = play.Play.applicationPath.getAbsolutePath();
//        	Fixtures.executeSQL(new File(path+"/conf/initialdata/1.sql"));
//        	Fixtures.executeSQL(new File(path+"/conf/initialdata/3.sql"));
//        	Fixtures.executeSQL(new File(path+"/conf/initialdata/2.sql"));
//        }
    }
 
}
