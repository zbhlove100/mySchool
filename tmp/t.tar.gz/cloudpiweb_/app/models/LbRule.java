package models;


import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.db.jpa.Model;
@Entity
@Table(name="lb_rule")
public class LbRule extends Model {
	
	@MaxSize(48)
	public String protocal;
	
	public int private_port;
	
	public int public_port;
	
	@MaxSize(255)
	public String algorithm;

	@OneToOne
	public LoadBalancer loadBalancer;
}
