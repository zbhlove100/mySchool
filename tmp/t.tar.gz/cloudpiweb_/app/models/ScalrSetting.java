package models;

import javax.persistence.Entity;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
@Table(name = "scalr_setting")

public class ScalrSetting extends Model{

	@Required
	@MaxSize(512)
	public String accessUrl;
	@Required
	@MaxSize(100)
	public String adminApiKey;
	@Required
	@MaxSize(100)
	public String adminApiKeySecret;
	@Required
	public long createdBy;

	// default constructor
	public ScalrSetting() {
	}

	public ScalrSetting(String accessUrl,String adminApiKey,String adminApiKeySecret, long createdBy) {
		this.accessUrl = accessUrl;
		this.createdBy = createdBy;
		this.adminApiKey = adminApiKey;
		this.adminApiKeySecret = adminApiKeySecret;
	}


}
