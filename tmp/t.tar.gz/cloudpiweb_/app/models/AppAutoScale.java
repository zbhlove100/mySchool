package models;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import models.spec.BaseModel;
import play.data.validation.MaxSize;
import play.data.validation.Required;

@Entity
@Table(name = "application_autoscale")
public class AppAutoScale extends BaseModel {

	@Required
	@OneToOne
	public PassApplication application;
	
	public int isEnable;
	
	public int minInstance;
	
	public int maxInstance;
	@MaxSize(100)
	public String metricMeasurement;
	
	public int metricPeriod;
	
	@MaxSize(20)
	public String metricStatistic;
	
	public double upperThrethod;
	
	public double lowerThrethod;

}
