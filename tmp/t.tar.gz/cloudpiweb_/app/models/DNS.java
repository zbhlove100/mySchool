package models;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
@Table(name="dns")
public class DNS extends Model{
	
	public Long userID;
	
	@Required
	@MaxSize(100)
	public String name; //dns name
	
	public Date createdOn;
	
	@MaxSize(900)
	public String bak;
	
	@ManyToMany(cascade=CascadeType.ALL)
	public List<DNSTarget> dnsTargets = new LinkedList<DNSTarget>();
	
	
	public DNS(){}
	
	public DNS(long id){
		this.id = id;
	}
	
	public DNS(long userId, String name, Date createdOn, String bak){
		this.userID = userId;
		this.name = name;
		this.createdOn = createdOn;
		this.bak = bak;
	}
	
	
}


/*
//dns related sql creation
 
CREATE TABLE dns (
id bigint(20) NOT NULL AUTO_INCREMENT,
bak varchar(255) DEFAULT NULL,
created_on datetime DEFAULT NULL,
name varchar(255) DEFAULT NULL,
userid bigint(20) DEFAULT NULL,
PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE dnstarget (
id bigint(20) NOT NULL AUTO_INCREMENT,
bak varchar(255) DEFAULT NULL,
createdon datetime DEFAULT NULL,
name varchar(255) DEFAULT NULL,
routeip varchar(255) DEFAULT NULL,
url varchar(255) DEFAULT NULL,
PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE dns_dnstarget (
dnses_id bigint(20) NOT NULL,
dnsTargets_id bigint(20) NOT NULL,
KEY FK1FE8946497576248 (dnses_id),
KEY FK1FE894649A13DCD7 (dnsTargets_id),
CONSTRAINT FK1FE894649A13DCD7 FOREIGN KEY (dnsTargets_id) REFERENCES dnstarget (id),
CONSTRAINT FK1FE8946497576248 FOREIGN KEY (dnses_id) REFERENCES dns (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


*/
