package models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;



/*
 * 	only for dedicated-service; system-service is not stored in DB,it's
 * queried directlt from the CF REST api.
 */
@Entity
@Table(name="service")
public class Service extends Model {
	
	@Required
	@MaxSize(100)
	public String name;
	
	@Required
	@MaxSize(20)
	public String type;
	
	@MaxSize(30)
	public String version;
	
	@MaxSize(900)
	public String bak;
	
	//@As("yyyy-MM-dd HH:mm:ss")
	public Date registeredDate;
	
	@Required
	public int registered;  //if registered to all targets of the user. 0: unregistered; 1: registered
	
	@Required
    @ManyToOne
    public Account owned_by; //which account owns this dedicated-service
	
    @ManyToOne
	public Account used_by ; //which account imports/shares this service

	
	public Service(){}
	
	public Service(long id){
		this.id = id;
	}

	public Service(long id,String name, String type, String version, String bak,
			Date registeredDate) {
		this.id = id;
		this.name = name;
		this.type = type;
		this.version = version;
		this.bak = bak;
		this.registeredDate = registeredDate;
		registered=0;
	}
	
	
}


/*
		// service related table creation sql:
CREATE TABLE service (
id bigint(20) NOT NULL AUTO_INCREMENT,
bak varchar(900) DEFAULT NULL,
name varchar(255) DEFAULT NULL,
registered int(11) NOT NULL,
registered_date datetime DEFAULT NULL,
type varchar(255) DEFAULT NULL,
version varchar(255) DEFAULT NULL,
owned_by_id bigint(20) DEFAULT NULL,
used_by_id bigint(20) DEFAULT NULL,
PRIMARY KEY (id),
KEY FK7643C6B554E7D18A (used_by_id),
KEY FK7643C6B5E74E0A72 (owned_by_id),
CONSTRAINT FK7643C6B554E7D18A FOREIGN KEY (used_by_id) REFERENCES account (id),
CONSTRAINT FK7643C6B5E74E0A72 FOREIGN KEY (owned_by_id) REFERENCES account (id)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
*/