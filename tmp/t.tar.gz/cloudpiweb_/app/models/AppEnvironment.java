package models;

import play.db.jpa.Model;

public class AppEnvironment extends Model{
	
	public String name;
	
	public String value;

}
