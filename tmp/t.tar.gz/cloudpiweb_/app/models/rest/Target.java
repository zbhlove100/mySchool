package models.rest;

import play.data.validation.MaxSize;

public class Target {
	private long id;
	private String name;
    
    private String targetUrl;
    
    

	public Target(String name, String targetUrl, long id) {
		super();
		this.name = name;
		this.targetUrl = targetUrl;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
    
}
