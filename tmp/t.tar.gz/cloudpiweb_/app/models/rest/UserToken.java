package models.rest;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import utils.Base64Util;

/**
 * 
 * Note: just for demonstration implementation
 * 
 * @TODO: This class need to be enhanced according to CF token generation.
 * 
 * @author zhimin.ruan@samsung.com
 * 
 */
@XmlRootElement(name = "userToken")
public class UserToken {

	private String user_name;
	private long valid_until;
	private String token;

	public UserToken(String userName, long validUntil) {
		this.user_name = userName;
		this.valid_until = validUntil;
		this.token = Base64Util.encode(userName + ":" + validUntil);
	}

	public static UserToken createUserToken(String user_name) {
		Calendar current = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
		return new UserToken(user_name,
				current.getTimeInMillis() + 30 * 60 * 1000);
	}

	public static UserToken decode(String token) {
		String decodedString;
		decodedString = Base64Util.decode(token);
		return new UserToken(decodedString.split(":")[0], Long
				.parseLong(decodedString.split(":")[1]));
	}

	public boolean valid() {
		return true;
		/* long current = new GregorianCalendar(TimeZone.getTimeZone("UTC"))
				.getTimeInMillis();
		if (current > valid_until) {
			return false;
		} else {
			return true;
		} */
	}

	@XmlElement
	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String userName) {
		user_name = userName;
	}

	@XmlElement
	public long getValid_until() {
		return valid_until;
	}

	public void setValid_until(long validUntil) {
		valid_until = validUntil;
	}

	@XmlElement
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
