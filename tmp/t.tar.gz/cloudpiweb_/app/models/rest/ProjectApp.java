package models.rest;

public class ProjectApp {
	private String appName;
	private String targetName;
	private String url;
	private String tag;
	private String status;
	private int instance;

	// add by liuqin
	private String branch;
	private String projectName;
	private Long targetId;
	private int memory;
	private Long appId;
	
	
	public Long getAppId() {
		return appId;
	}
	
	public void setAppId(Long appId) {
		this.appId=appId;
	}
	
	
	public int getMemory() {
		return memory;
	}
	
	public void setMemory(int memory) {
		this.memory=memory;
	}
	
	
	public Long getTargetId() {
		return targetId;
	}

	public void setTargetId(Long targetId) {
		this.targetId=targetId;
	}
	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getTargetName() {
		return targetName;
	}

	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getInstance() {
		return instance;
	}

	public void setInstance(int instance) {
		this.instance = instance;
	}

}
