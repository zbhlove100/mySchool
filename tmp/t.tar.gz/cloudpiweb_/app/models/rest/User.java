package models.rest;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import models.Account;
import models.spec.Where;

import org.apache.commons.codec.digest.DigestUtils;

@XmlRootElement(name = "user")
public class User {

	private String userName;
	private String password;

	@XmlElement
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@XmlElement
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean authenticate() {
		String md5Password = DigestUtils.md5Hex(password); 
		Where where = new Where();
		where.addValue("username=", userName);
		where.addValue("password=", md5Password);
		if (Account.find(where.where(), where.paramsarr()).fetch().size() == 1) {
			return true;
		} else {
			return false;
		}
	}
}
