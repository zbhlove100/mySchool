package models.rest;

import java.util.Date;

import javax.persistence.ManyToOne;

import play.data.binding.As;
import play.data.validation.MaxSize;
import play.data.validation.Required;


import models.Account;
import models.Project;

public class Event {
	public String targetName;
    
    public String applicationName;
    
    public String eventDetail;
    
    public String eventType;
    
	public String createdAt;

	public String getTargetName() {
		return targetName;
	}

	public void setTargetName(String targetName) {
		this.targetName = targetName;
	}

	public String getApplicationName() {
		return applicationName;
	}

	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}

	public String getEventDetail() {
		return eventDetail;
	}

	public void setEventDetail(String eventDetail) {
		this.eventDetail = eventDetail;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public String getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
    
}
