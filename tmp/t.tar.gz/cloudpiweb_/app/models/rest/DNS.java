package models.rest;

import java.util.Date;
import java.util.List;
import java.util.LinkedList;

public class DNS {
	private long id;
	private long userID;
	
	private String name; //dns name
	
	private String createdOn;
	
	private String bak;
	
	private List<models.rest.DNSTarget> dnsTargets = new LinkedList<models.rest.DNSTarget>();
	
	//models.Target's ids, for create request parameter
	private List<String> targetIds = new LinkedList<String>();
	
	private List<String> viewNames = new LinkedList<String>(); //["China;Others","China;"]
	
	public DNS(){}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getUserID() {
		return userID;
	}

	public void setUserID(long userID) {
		this.userID = userID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getBak() {
		return bak;
	}

	public void setBak(String bak) {
		this.bak = bak;
	}

	public List<models.rest.DNSTarget> getDnsTargets() {
		return dnsTargets;
	}

	public void setDnsTargets(List<models.rest.DNSTarget> dnsTargets) {
		this.dnsTargets = dnsTargets;
	}

	public List<String> getTargetIds() {
		return targetIds;
	}

	public void setTargetIds(List<String> targetIds) {
		this.targetIds = targetIds;
	}

	public List<String> getViewNames() {
		return viewNames;
	}

	public void setViewNames(List<String> viewNames) {
		this.viewNames = viewNames;
	}
	
}
