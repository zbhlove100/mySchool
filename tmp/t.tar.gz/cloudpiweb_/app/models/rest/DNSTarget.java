package models.rest;

import java.util.Date;

public class DNSTarget {
	//private long id;
	private String name;
    
    private String targetUrl;
    
    private String createdOn;
    private String routeIP;
    
    private String viewNames;

	public DNSTarget() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	/* public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	} */

	public String getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}

	public String getRouteIP() {
		return routeIP;
	}

	public void setRouteIP(String routeIP) {
		this.routeIP = routeIP;
	}

	public String getViewNames() {
		return viewNames;
	}

	public void setViewNames(String viewNames) {
		this.viewNames = viewNames;
	}
	
}
