package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import models.spec.BaseModel;
import play.data.binding.As;
import play.data.validation.MaxSize;
import play.data.validation.Required;

@Entity
@Table(name="application")
public class PassApplication extends BaseModel{
	@Required
	@MaxSize(100)
	public String name;

	@Required
	@ManyToOne
	public Project project;
	
	@Required
	public Long accountId;
	
	@Required
	@ManyToOne
	public Target target;

	public String branch;
	public String url;
	public String tag;
	public String status;

	@As("yyyy-MM-dd HH:mm:ss")
	public Date createdAt;

	@Required
	public int instances;	
	
	@Required
	public int memory;	
	
	@OneToMany(mappedBy="application")  
	public List<PassApplicationService> services=new ArrayList<PassApplicationService>();
	
	@OneToOne(mappedBy="application")  
	public AppAutoScale autoScale;
	
	public String recordIds;
	
	public PassApplication() {

	}

}
