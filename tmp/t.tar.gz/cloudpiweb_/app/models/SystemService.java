package models;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
@Table(name="systemservice")
public class SystemService extends Model {
	
	@Required
	@MaxSize(100)
	public String name;
	
	@Required
	@MaxSize(20)
	public String type;
	
	@MaxSize(30)
	public String version;
	
	@MaxSize(30)
	public String tier;
	
	@ManyToOne
	public Account owned_by_account ;
	
	@ManyToOne
	public Domain owned_by_domain ;
	
	@ManyToOne
	public Target owned_by_target ;
	
	public SystemService(){}
	
	public SystemService(long id){
		this.id = id;
	}

	public SystemService(String name, String type, String version, String tier) {
		super();
		this.name = name;
		this.type = type;
		this.version = version;
		this.tier = tier;
	}
	
	
}


/**
CREATE TABLE systemservice (
id bigint(20) NOT NULL AUTO_INCREMENT,
name varchar(255) DEFAULT NULL,
tier varchar(255) DEFAULT NULL,
type varchar(255) DEFAULT NULL,
version varchar(255) DEFAULT NULL,
owned_by_account_id bigint(20) DEFAULT NULL,
owned_by_domain_id bigint(20) DEFAULT NULL,
owned_by_target_id bigint(20) DEFAULT NULL,
PRIMARY KEY (id),
KEY FK8BFA51A698D5F8D0 (owned_by_domain_id),
KEY FK8BFA51A6E8736BC4 (owned_by_account_id),
KEY FK8BFA51A65BDDA9B0 (owned_by_target_id),
CONSTRAINT FK8BFA51A65BDDA9B0 FOREIGN KEY (owned_by_target_id) REFERENCES target (id),
CONSTRAINT FK8BFA51A698D5F8D0 FOREIGN KEY (owned_by_domain_id) REFERENCES domain (id),
CONSTRAINT FK8BFA51A6E8736BC4 FOREIGN KEY (owned_by_account_id) REFERENCES account (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
*/