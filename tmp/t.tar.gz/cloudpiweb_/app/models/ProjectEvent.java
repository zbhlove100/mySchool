package models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import models.spec.BaseModel;
import play.data.binding.As;
import play.data.validation.MaxSize;
import play.data.validation.Required;

@Entity
@Table(name = "project_event")
public class ProjectEvent extends BaseModel{
	
	 public static String INFO = "INFO";
	 public static String ERROR = "ERROR";

	 
	    @Required
		@MaxSize(100)
		public String targetName;
	    
	    @Required
	    @ManyToOne
	    public Project project;
	    
	    @Required
		@MaxSize(100)
	    public String applicationName;
		
	    @Required
	    public Long accountId;
	    
	    @Required
	    @MaxSize(1000)
	    public String eventDetail;
	    
	    @Required
	    public String eventType;
	    
		@Required
		@As("yyyy-MM-dd HH:mm:ss")
		public Date createdAt;

		public ProjectEvent(){
			
		}
		
		public ProjectEvent(String targetName,String appName,String type,String detail,Long accountId,Project project,Date occTime){
			this.targetName=targetName;
			this.applicationName=appName;
			this.eventType=type;
			this.eventDetail=detail;
			this.accountId=accountId;
			this.project=project;
			this.createdAt=occTime;
			
		}
}
