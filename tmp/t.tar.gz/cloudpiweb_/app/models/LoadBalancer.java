package models;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;
@Entity
@Table(name = "load_balancer")
public class LoadBalancer extends Model {
	
    @ManyToOne    
    public Cloudprovider cloudprovider;
    
    @MaxSize(255)
    public String name;
    
    @MaxSize(255)
    public String virAddress;
    
    @Required
	public Date createAt;
	public Date removedAt;
	
	@Required
	@MaxSize(10)
	public String state;
	
	@OneToOne(mappedBy="loadBalancer")
	public LbRule lbRules;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="lb_instance",
				joinColumns={@JoinColumn(name="lb_id")},
				inverseJoinColumns={@JoinColumn(name="instance_id")})
	public List<Server> servers;
}
