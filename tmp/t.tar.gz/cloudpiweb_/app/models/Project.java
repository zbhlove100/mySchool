package models;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import play.data.binding.As;
import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;

@Entity
@Table(name = "project")
public class Project extends Model {
	@Required
	@MaxSize(100)
	public String name;
	public String description;
	public String gitUrl;
	@Required
	public String runtime;
	@Required
	public String framework;
	@Required
	public Long accountId;
	@Required
	public Long domainId;
	@Required
	@As("yyyy-MM-dd HH:mm:ss")
	public Date createdAt;
	
	@OneToMany(mappedBy="project")  
	public List<PassApplication> applications=new ArrayList<PassApplication>();
	
	@OneToMany(mappedBy="project")  
	public List<ProjectEvent> events=new ArrayList<ProjectEvent>();
	
		
	public Project() {

	}

	public Project(String name, String runtime, String framework,String description) {
		this.description=description;
		this.name=name;
		this.runtime=runtime;
		this.framework=framework;

	}

}
