package models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import models.spec.BaseModel;
import play.data.validation.MaxSize;
import play.data.validation.Required;

@Entity
@Table(name = "object")
public class Object extends BaseModel{
	//modified by zbh;
	@ManyToOne
	public Container container;
	@MaxSize(200)
	public String name;
	@MaxSize(200)
	public long size;
	public String coutentType;
	public String etag;
	@Required
	@MaxSize(10)
	public String state;
	@Required
	@ManyToOne
	public Account created_by;
	@Required
	public Date createdAt;
	public Date removedAt;

	// default constructor
	public Object() {
	}

	public Object(long id) {
		this.id = id;
	}

	public Object(long id, String name, int size, String coutentType,
			String etag, String state, Account created_by, Date createdAt,
			Date removedAt) {
		this.id = id;
		this.name = name;
		this.state = state;
		this.size = size;
		this.coutentType = coutentType;
		this.etag = etag;
		this.created_by = created_by;
		this.createdAt = createdAt;
		this.removedAt = removedAt;
	}
}
