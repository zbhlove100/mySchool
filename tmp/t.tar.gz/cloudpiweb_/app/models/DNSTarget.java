package models;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import play.data.validation.MaxSize;
import play.data.validation.Required;
import play.db.jpa.Model;

/*
 *  used in DNS page in PaaS. when user create a new dns, the init dns info is queried
 *  from Target, after the creation all the target-related info displayed in DNS-management
 *  page comes from this DNSTarget.
 */

@Entity
@Table(name="dnstarget")
public class DNSTarget  extends Model{
	
	@Required
	@MaxSize(200)
	public String name; //target name
	
	@MaxSize(200)
	public String url;
	
	@MaxSize(200)
	public String routeIP;
	
	@MaxSize(900)
	public String bak;
	
	
    public Date createdon;
    
    @Column(name="recordids")
    public String recordIds;  //view record ids
    
    @Column(name="viewnames")
    public String viewNames;  //view record ids
	
	@ManyToMany(mappedBy="dnsTargets")
	public List<DNS> dnses = new LinkedList<DNS>();
	
	public DNSTarget(){}
	
	public DNSTarget(long id){
		this.id = id;
	}
	
	public DNSTarget(String name, String url, String ip, String bak,Date createdon, String recordIds, String viewNames){
		this.name = name;
		this.url = url;
		this.routeIP = ip;
		this.bak = bak;
		this.createdon = createdon;
		this.recordIds = recordIds;
		this.viewNames = viewNames;
	}
	
	public boolean equals(DNSTarget o){
		return this.id==o.id;		
		
	}
}
