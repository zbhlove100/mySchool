package models;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import models.spec.BaseModel;
import play.data.validation.MaxSize;
import play.data.validation.Required;

@Entity
@Table(name="container")
public class Container extends BaseModel{

    @ManyToOne    
    public Cloudprovider cloudprovider;
    @MaxSize(200)
    public String name;
    @Required
    public Date putTimestamp;    
    @Required
    public int  objectCount;    
    @Required
    public long bytesUsed;
    @Required
    @MaxSize(10)
    public String state;
    @Required
    @ManyToOne    
    public Account created_by;
    @Required
    public Date createdAt;
    public Date removedAt; 
    @ManyToOne    
    public Zone zone;
    //default constructor 
    public Container() {
    }
    public Container(long id) {
     	this.id = id;
    }
    public Container(long id, String name, Date put_timestamp, int  object_count, long bytes_used, String state, Account created_by, Date createdAt, Date removedAt) {
        this.id = id;
        this.name = name;
        this.state = state;
        this.putTimestamp = put_timestamp;
        this.objectCount = object_count;   
        this.bytesUsed = bytes_used;       
        this.created_by = created_by;
        this.createdAt = createdAt;
        this.removedAt = removedAt;        
    }
  
}
