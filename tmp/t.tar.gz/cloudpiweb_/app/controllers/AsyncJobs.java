package controllers;

import java.util.concurrent.BlockingQueue;

import play.jobs.JobsPlugin;
import play.modules.cas.annotation.Check;

public class AsyncJobs extends CRUD {
	
    public static void list() {
    	
    	BlockingQueue<Runnable> a = JobsPlugin.executor.getQueue();
		
    	System.out.println("====bbbbbbbbb===>"+a.size());
		
		//render(jobs);
	}
}
