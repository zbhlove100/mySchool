package controllers;

import java.lang.reflect.Field;
import java.util.Date;
import java.util.List;
import java.util.Map;

import models.Account;
import models.Dnszone;
import models.Dnsrecord;
import models.Domain;
import models.Setting;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;

import org.springframework.util.StringUtils;

import play.db.jpa.Model;
import service.networking.DnsService;

public class Dnsrecords extends CRUD{
	
	private static String conName = "dnsrecords";
	
    public static void blankPublicZone(){
    	render();
    }
    
    public static void blankPublicRecord(){
    	Where where = new Where(params);
    	where.addValue("state!=", BaseModel.DELETE);
    	List<String> views = Setting.values("view");
        List<Dnszone> objects = Dnszone.find(where.where(), where.paramsarr()).fetch();
        
    	render(objects, views);
    }
    
    public static void blankPrivateRecord(){
    	Where where = new Where(params);
    	where.addValue("state!=", BaseModel.DELETE);
        List<Dnszone> objects = Dnszone.find(where.where(), where.paramsarr()).fetch();
        
    	render(objects);
    }
    
    public static void listPublic(){
    	
    	Where where = new Where(params);
    	
    	String privateview = Setting.value("PRIVATE_VIEW","Internal");
   	 	where.addValue("view!=", privateview);
   	 	
		where.add("search", "name like");
		//List<String> views = Setting.values("view");
		//where.in("view", views);
   	 	
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("created_by_id=",cuser.id);
		}
		
		_list(where);
    }
    
    public static void listPrivate(){
    	
    	Where where = new Where(params);
    	where.add("search", "name like");
    	String privateview = Setting.value("PRIVATE_VIEW","Internal");
   	 	where.addValue("view=", privateview);
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("created_by_id=",cuser.id);
		}
		
		_list(where);
    }
    
    public static void createPublicRecord(){
    	DnsService dnsService = new DnsService();
    	String zoneId = Setting.value("PUBLIC_DNSZONE_ID");
    	String ip = StringUtils.replace(params.get("data"), ".", "-");
    	Dnszone dnszone = Dnszone.findById(Long.parseLong(params.get("DnszoneId")));
    	Integer ttl = (params.get("ttl").equals("")?86400:Integer.parseInt(params.get("ttl")));
        String host = params.get("host") + "-" + ip + "." + dnszone.name;
    	
    	Map<String,String> map = dnsService.createRecord(zoneId, params.get("type"), host, ttl.toString(), params.get("data"), params.get("view"));
    	
    	CurrentUser cuser = CurrentUser.current();
    	
    	Dnsrecord dzr = new Dnsrecord();
    	dzr.createdById = cuser.id;
    	dzr.dnszone = Dnszone.findById(Long.parseLong(params.get("DnszoneId")));
    	dzr.name = host + "." +map.get("zone_name");
    	dzr.state = BaseModel.ACTIVE;
    	dzr.ttl = ttl;
    	dzr.type = params.get("type");
    	dzr.value = params.get("data");
    	dzr.impldnsrecord_id = map.get("id");
    	dzr.view = params.get("view");
    	dzr._save();
    	if (request.format.equals("json")) {
			renderJSON(forwardJson("listpublic",
					String.format("/%s/listpublic", conName),
					String.format("Create new public Dnszone Record:%s", dzr.name)));
		} else {

			flash.success(String.format("Create new public Dnszone Record:%s", dzr.name));
			redirect(request.controller + ".listpublic");
		}
    }
    
    public static void createPrivateRecord(){
    	DnsService dnsService = new DnsService();
    	String zoneId = Setting.value("PRIVATE_DNSZONE_ID");
    	String ip = StringUtils.replace(params.get("data"), ".", "-");
    	Dnszone dnszone = Dnszone.findById(Long.parseLong(params.get("DnszoneId")));
    	Integer ttl = (params.get("ttl").equals("")?86400:Integer.parseInt(params.get("ttl")));
        String host = params.get("host") + "-" + ip + "." + dnszone.name;
    	
    	Map<String,String> map = dnsService.createRecord(zoneId, params.get("type"), host, ttl.toString(), params.get("data"), params.get("view"));
    	
    	CurrentUser cuser = CurrentUser.current();
    	
    	Dnsrecord dzr = new Dnsrecord();
    	dzr.createdById = cuser.id;
    	dzr.dnszone = Dnszone.findById(Long.parseLong(params.get("DnszoneId")));
    	dzr.name = host + "." +map.get("zone_name");
    	dzr.state = BaseModel.ACTIVE;
    	dzr.ttl = ttl;
    	dzr.type = params.get("type");
    	dzr.value = params.get("data");
    	dzr.impldnsrecord_id = map.get("id");
    	dzr.view = params.get("view");
    	dzr._save();
    	if (request.format.equals("json")) {
			renderJSON(forwardJson("listprivate",
					String.format("/%s/listprivate", conName),
					String.format("Create new private Dnszone Record:%s", dzr.name)));
		} else {

			flash.success(String.format("Create new private Dnszone Record:%s", dzr.name));
			redirect(request.controller + ".listprivate");
		}
    }
    
    public static void createPublicZone(){
    	
    	
    	
    	CurrentUser cuser = CurrentUser.current();
    	Dnszone dnszone = new Dnszone();
    	
    	dnszone.domain = Domain.findById(cuser.domainid);
    	dnszone.createdAt = new Date(java.lang.System.currentTimeMillis());
    	dnszone.createdById = cuser.id;
    	dnszone.description = params.get("description");
    	dnszone.name = params.get("name");
    	dnszone.state = BaseModel.ACTIVE;
    	
    	dnszone._save();
    	
    	if (request.format.equals("json")) {
			renderJSON(forwardJson("listpublic",
					String.format("/%s/listpublic", conName),
					String.format("Create new Dns zone:%s", dnszone.name)));
		} else {

			flash.success(String.format("Create new Dns zone:%s", dnszone.name));
			redirect(request.controller + ".listpublic");
		}
    }
    
    public static void deleteRecord(){	
    	DnsService dnsService = new DnsService();
    	
    	String recordids = params.get("recordId");
		String where = String.format("id in (%s)", recordids);
		 
    	List<Dnsrecord> dzrs = Dnsrecord.find(where).fetch();
    	
    	String tabId = "listprivate";
    	
    	for(Dnsrecord dzr:dzrs){
    		
    		if(dzr.view != null && !dzr.view.equals(Setting.value("PRIVATE_VIEW", "Internal"))){
    			tabId="listpublic";
    		}
			String []implrecordids = dzr.impldnsrecord_id.split(",");
			for(String implrecordid: implrecordids){
				dnsService.deleteRecord(implrecordid);
			}	    		
	    	logicalDelete(dzr, "models.Dnsrecord");
    	}
    	if (request.format.equals("json")) {
			renderJSON(forwardJson(tabId,
					String.format("/%s/"+tabId, conName),
					String.format("Delete Dns records:%s",recordids)));
		} else {

			flash.success(String.format("Delete Dns record:%s", recordids));
			redirect(request.controller + "."+tabId);
		}
    }
    
    public static void listZone(){
    	String type = params.get("type");
    	Where where = new Where(params);
    	where.addValue("state!=", BaseModel.DELETE);
        List<Dnszone> objects = Dnszone.find(where.where(), where.paramsarr()).fetch();
    	
    	render(objects, type);
    }
    
    public static void deleteZone(){
    	
    	Dnszone dnszone = Dnszone.findById(Long.parseLong(params.get("zoneId")));
    	logicalDelete(dnszone, "models.Dnszone");
    	
    	String tabId = (params.get("type").equals("public") ? "listpublic" : "listprivate");
    	if (request.format.equals("json")) {
			renderJSON(forwardJson(tabId,
					String.format("/%s/"+tabId, conName),
					String.format("Delete Dns zone:%s", dnszone.name)));
		} else {

			flash.success(String.format("Delete new Dns zone:%s", dnszone.name));
			redirect(request.controller + "."+tabId);
		}
    }
    
    public static boolean logicalDelete(Model object, String clzName){
		
		
		try {
			Class entityclass = Class.forName(clzName);

			boolean islogicdelete = false;        
	        if (BaseModel.class.isAssignableFrom(entityclass)){
	        	islogicdelete = true;
	         }
	        
	        if (islogicdelete) {
				Field statefield = getField(entityclass,"state");
				if (statefield != null) {
					setField(statefield,object, BaseModel.DELETE);
					Field rdfield = getField(entityclass,"removedAt");
					if (rdfield != null)
						setField(rdfield,object, new Date(java.lang.System.currentTimeMillis()));
					object._save();
					return true;
				}

			} else {
				object._delete();
				return true;
			}
	        return true;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return true;
		}
	}
    
}
