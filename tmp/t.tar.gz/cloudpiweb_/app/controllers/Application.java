package controllers;

import java.util.ArrayList;
import java.util.List;

import jobs.MessageJob;
import models.Account;
import models.Cloudprovider;
import models.Domain;
import models.DomainCloudprovider;
import models.Event;
import models.Server;
import models.spec.CurrentUser;
import models.spec.Message;

import org.w3c.dom.Document;

import play.libs.F.Promise;
import play.libs.WS;
import play.mvc.Before;
import play.mvc.Controller;
import play.mvc.Router;
import play.mvc.Scope;
import play.mvc.With;
import controllers.modules.cas.SecureCAS;

@With(SecureCAS.class)
public class Application extends Controller {

	@Before
	public static void checkUser(){
		//for flash authorization
		if(request.cookies == null || request.cookies.get("PLAY_SESSION") == null){
			if(params.get("sessionId") != null){
				String ID_KEY = "___ID";
				session.put(ID_KEY, params.get("sessionId"));
				session.put("username",CasSecurity.connected());
			}
			//Logger.setUp("TRACE");
		}
		if(!CurrentUser.isAuthed()){
			String loginUrl = Router.reverse("modules.cas.SecureCAS.login").url;
			redirect(loginUrl);
		}else{
			if(CurrentUser.current() == null){
				String logoutUrl = Router.reverse("modules.cas.SecureCAS.logout").url;
				redirect(logoutUrl);
			}
			renderArgs.put("user",CurrentUser.current());
		}
	}
	
	private static List<String> excludeurls = new ArrayList<String>();
	static{
		excludeurls.add("/login");
		excludeurls.add("/logout");
		excludeurls.add("/events/list");
		excludeurls.add("/application/waitmessages");
	}
	
	@Before
	public static void LogEvent(){
		
		try{
			if(!excludeurls.contains(request.url)){
				
				Event evt = new Event();
				
				CurrentUser cuser = CurrentUser.current();
				if(cuser != null){
					evt.created_by = new Account(cuser.id);
				}
				
				evt.type = request.method;		
				evt.level = Event.LEVEL_INFO;
				evt.traceUrl = request.url;
				evt.rawdata = params.allSimple().toString();
				evt.state = Event.ACTIVE;
				
				evt.save();
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
    
	public static void index(){
		
		Long cps_count=null,domains_count=null,accounts_count=null,instances_count=null;
		
		if(CurrentUser.current().isSuper()){
			cps_count = Cloudprovider.count("state=?", Cloudprovider.ACTIVE);			
			domains_count = Domain.count("state=?", Domain.ACTIVE);
			accounts_count = Account.count("state=?", Account.ACTIVE);
			instances_count = Server.count("state='RUNNING'");
		}else{
			cps_count = DomainCloudprovider.domainProvidersCount(CurrentUser.current().domainid);	
			instances_count = Server.count("created_by_id=? and state='RUNNING'",CurrentUser.current().id);
		}
		
		render(cps_count,domains_count,accounts_count,instances_count);
	}
	
	public static void waitMessages() { 
		
//	    for(int i=0; i<5; i++) { 
//	    	Logger.info("waiting...%d",i);
//	    	await("1s");
//	     }		 
//	    String message = ""+System.currentTimeMillis();
//		 String test = String.format("{\"code\":200,\"text\":\"Warning:%s\"}",message);
			
		 Promise<Message> msg_job = new MessageJob(Scope.Session.current().getId()).now();
		 Message message = await(msg_job);
		 
        renderJSON(message);
    }
	
}
