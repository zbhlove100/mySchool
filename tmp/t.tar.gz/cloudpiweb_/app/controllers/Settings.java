package controllers;

import java.util.Map;

import jobs.AsyncJob;
import jobs.MessageJob;
import models.Setting;
import models.spec.Message;
import play.libs.F;
import play.modules.cas.annotation.Check;
import play.mvc.Scope;
import service.admin.CloudstackAdmin;

@Check("root")
public class Settings extends CRUD {
//    public static void blank() throws Exception {
    	
//    	System.out.println("+++++++>"+session.getId());
//    	System.out.println("==>"+request.cookies.get("PLAY_SESSION").value);
//    	_blank();
//    	for(int i=0; i<=10; i++) { 
//          Logger.info("waiting...%d",i);
//          await("1s");
//        }    	
    	//MessageJob.publish_info(Scope.Session.current().getId(),"haha"+System.currentTimeMillis());
    	//renderJSON(jsonMessage("Success!"));	
    	
//    	Cloudprovider cp = Cloudprovider.findById(Long.parseLong("126"));
//    	OpenstackAdmin osa = new OpenstackAdmin(cp);
//    	System.out.println("=================>>>"+osa.queryProject("test-o1s"));

/*    	
		CloudstackAdmin csa = new CloudstackAdmin("106");
		
		AsyncJob ajob = new AsyncJob(csa,"job_deleteAccount",new F.Action<Map>()
			{
		     public void invoke(Map params)
		      {
		    	 String key = (String)params.get(AsyncJob.session_key);
		    	 
		    	 Map callresult = (Map)params.get(AsyncJob.result_key);
		    	 
		    	 if(callresult.get(AsyncJob.event_key) != null){
		    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
		    	 }else{
		    		 MessageJob.publish_info(key,"Success to delete account");
		    	 }
		      }
		    });
		
		String session_key = Scope.Session.current().getId();	   	
		
		ajob.initParams(session_key);
		ajob.addInParam("implaccountId", "3");
		
		ajob.now();
		
*/
//   	 	_blank();
//    }
	 
}
