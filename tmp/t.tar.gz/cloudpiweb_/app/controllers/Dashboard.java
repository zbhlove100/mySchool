package controllers;

import models.Account;
import models.Cloudprovider;
import models.Domain;
import models.DomainCloudprovider;
import models.Server;
import models.spec.CurrentUser;
import play.modules.cas.annotation.Check;
import play.mvc.Controller;
@Check("root")
public class Dashboard extends Controller {

	public static void iaas() {
		Long cps_count=0l,domains_count=null,accounts_count=null,instances_count=0l;
		
		if(CurrentUser.current().isSuper()){
			cps_count = Cloudprovider.count("state=?", Cloudprovider.ACTIVE);			
			domains_count = Domain.count("state=?", Domain.ACTIVE);
			accounts_count = Account.count("state=?", Account.ACTIVE);
			instances_count = Server.count("state='RUNNING'");
		}else{
			cps_count = DomainCloudprovider.domainProvidersCount(CurrentUser.current().domainid);	
			instances_count = Server.count("created_by_id=? and state='RUNNING'",CurrentUser.current().id);
		}
		
		render(cps_count,domains_count,accounts_count,instances_count);
	}
}
