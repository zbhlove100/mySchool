package controllers;

import java.util.List;

import models.Cloudprovider;
import models.Server;
import models.spec.Where;

import org.dasein.cloud.network.LbAlgorithm;
import org.dasein.cloud.network.LbListener;
import org.dasein.cloud.network.LbProtocol;

public class LoadBalancers extends CRUD {

	public static void list(){
		Where where = new Where(params);
		where.add("bucketName", "name like");
		_list(where);
	}
	public static void blank(){
		render();
	}
	public static void create(){
		String providerId = params.get("cloudproviderId");
		LbProtocol protocal = params.get("lbRule.protocal",LbProtocol.class);
		int publicPort = params.get("lbRule.public_port",int.class);
		int privatePort = params.get("lbRule.private_port",int.class);
		LbAlgorithm algorithm = params.get("lbRule.algorithm",LbAlgorithm.class);
 		try {
			LbListener lbListener = new LbListener();
			
			lbListener.setNetworkProtocol(protocal);
			lbListener.setPublicPort(publicPort);
			lbListener.setPrivatePort(privatePort);
			lbListener.setAlgorithm(algorithm);
			
			
			System.err.println(lbListener.getNetworkProtocol());
			//LoadBalancerService lbService = new LoadBalancerService(providerId);
			//lbService.create(name, description, addressId, dataCenterIds, listeners, serverIds);
		} catch (Exception e) {
			// TODO: handle exception
		}
		renderJSON(jsonMessage(""));
	}
	public static void step(){
		int step = params.get("step",int.class)==0?1:params.get("step",int.class);
		String type = params.get("type");
		String loadBalancerName = params.get("loadBalancer.name"); 
		String providerId = params.get("cloudproviderId");
		String protocal = params.get("lbRule.protocal");
		int publicPort = params.get("lbRule.public_port",int.class);
		int privatePort = params.get("lbRule.private_port",int.class);
		String algorithm = params.get("lbRule.algorithm");
		renderArgs.put("cloudproviderId", providerId);
		renderArgs.put("public_port", publicPort);
		renderArgs.put("private_port", privatePort);
		renderArgs.put("algorithm", algorithm);
		renderArgs.put("type", type);
		renderArgs.put("loadBalancerName", loadBalancerName);
		switch (step) {
		case 0:
		case 1:
			if(type!=null){
				List<Cloudprovider> cloudproviders = Cloudprovider.find("byType", type).fetch();
				renderArgs.put("cloudproviders", cloudproviders);
			}
			break;
		case 2:
			List<Server> servers = Server.find("byCloudprovider_id", providerId).fetch();
			System.err.println(providerId);
			System.err.println(servers.size());
			renderArgs.put("servers", servers);
			break;
		default:
			break;
		}
		render("/LoadBalancers/step"+step+".html");
		
		
	}
	public static void delete(){
		
	}
	public static void edit(){
		
	}
}
