package controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import models.Account;
import models.Cloudprovider;
import models.CloudproviderDetail;
import models.Domain;
import models.DomainCloudprovider;
import models.Role;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;
import play.Logger;
import play.data.binding.Binder;
import play.modules.cas.annotation.Check;
import service.admin.CloudstackAdmin;
import service.admin.OpenstackAdmin;
import service.pass.ApplicationService;
import service.pass.ProjectService;

@Check("root")
public class Accounts extends CRUD {

	public static void blank() throws Exception {
		renderArgs.put("domains", Domain.availables());
		renderArgs.put("roles", Role.all().fetch());
		_blank();
	}
	
    public static void create() throws Exception {
    	 Account object = new Account();
    	 
    	 object.setPasswordBase64((params.get("object.password")));
    	 params.put("object.created_by.id", ""+CurrentUser.current().id);
		 Binder.bind(object, "object", params.all());
		 
		 object.createdAt = new Date(java.lang.System.currentTimeMillis());
		 object.state = BaseModel.ACTIVE;
		 
		  
		 //call API to create domain in all private cloud providers?
		 List<String> messages = new ArrayList<String>();
		 renderArgs.put("message",messages);
			
		 object._save();

		 List<Cloudprovider> all_account_cps = Cloudprovider.queryProviders(Cloudprovider.CloudType.CLOUDSTACK.name(),object);

		 for(Cloudprovider eachcsp : all_account_cps){
		   try{
				CloudstackAdmin csa = new CloudstackAdmin(eachcsp);
				
				DomainCloudprovider dcp = object.domain.getDomainCloudprovider(eachcsp.id.toString());
				
				if(dcp == null || dcp.impldomainId == null)
					continue;
	    		
				//not query for account for security cause 
				//Map implaccount = csa.createAccount(dcp.impldomainId, object);
				
	    		Map implaccount = csa.queryAccount(dcp.impldomainId, object);
	    		
	    		if(implaccount == null){
	    			implaccount = csa.createAccount(dcp.impldomainId, object);
	    		}else{
	    			List<Map> users = (List<Map>)implaccount.get("user");
	    			Map first_user = users.get(0);
	    			if(first_user.get("apikey") == null){
	    				Map implkeys = csa.generateKeys(first_user.get("id").toString());
	    		    	if(implkeys != null){
	    		    		implaccount.put("apikey",implkeys.get("apikey"));
	    		    		implaccount.put("secretkey",implkeys.get("secretkey"));
	    		    	}    				
	    			}else{
			    		implaccount.put("apikey",first_user.get("apikey"));
			    		implaccount.put("secretkey",first_user.get("secretkey"));    				
	    			}
	    		}
				
				if(implaccount == null){
					messages.add(String.format("Fail to created account: %s in %s CloudProvider", object.username, eachcsp.name));
				}else{
    				
					List<Map> users = (List<Map>)implaccount.get("user");
					Map first_user = users.get(0);
					
					CloudproviderDetail endpointcpd = new CloudproviderDetail();
					endpointcpd.account = object;
					endpointcpd.cloudprovider = eachcsp;
					endpointcpd.implaccountId = (String)implaccount.get("id");
					endpointcpd.impluserId = (String)first_user.get("id");
					endpointcpd.name = "endpoint";
					endpointcpd.value = eachcsp.detailshash().get("endpoint");
					endpointcpd.save();
					
					CloudproviderDetail apikeycpd = new CloudproviderDetail();
					apikeycpd.account = object;
					apikeycpd.cloudprovider = eachcsp;
					apikeycpd.implaccountId = (String)implaccount.get("id");
					apikeycpd.impluserId = (String)first_user.get("id");
					apikeycpd.name = "apiSharedKey";
					apikeycpd.value = (String)implaccount.get("apikey");
					apikeycpd.save();
					
					CloudproviderDetail secretkeycpd = new CloudproviderDetail();
					secretkeycpd.account = object;
					secretkeycpd.cloudprovider = eachcsp;
					secretkeycpd.implaccountId = (String)implaccount.get("id");
					secretkeycpd.impluserId = (String)first_user.get("id");
					secretkeycpd.name = "apiSecretKey";
					secretkeycpd.value = (String)implaccount.get("secretkey");
					secretkeycpd.save();
					
//					//FIXME: the follow'd remove after demo, and the valus'd save into zones for cloudstack
//					CloudproviderDetail regioncpd = new CloudproviderDetail();
//					regioncpd.account = object;
//					regioncpd.cloudprovider = eachcsp;
//					regioncpd.implaccountId = (String)implaccount.get("id");
//					regioncpd.impluserId = (String)implaccount.get("id");
//					regioncpd.name = "regionId";
//					regioncpd.value = eachcsp.detailshash().get("regionId");
//					regioncpd.save();
					
				}
			 }catch(Exception e){
				 Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
			 }
		  }
		 List<Cloudprovider> all_account_ops = Cloudprovider.queryProviders(Cloudprovider.CloudType.OPENSTACK.name(),object);

		 for(Cloudprovider eachcsp : all_account_ops){
		   try{
			   OpenstackAdmin osa = new OpenstackAdmin(eachcsp);
			   String account_as_project = osa.createProject(object.username);
				if(account_as_project == null){
					messages.add(String.format("Fail to created account: %s in %s CloudProvider", object.username, eachcsp.name));
				}
		   }catch(Exception e){
				Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
		   }
		 }
		 
		 //add for git and cloudfoundry user
		if (object.role.name.equals("user")) {
			
			try {
				ApplicationService.createGitAccount(object);
			} catch (Exception e) {
				Logger.error(">> Creating git account:"+object.username+"has error!!",e);
			}
			
			try{
				ApplicationService.createCloudFoundryUser(object);
			}catch (Exception e) {
				Logger.error(">> Creating cloudfoundry account:"+object.username+"has error!!",e);
			}
		}
			
		 _create(object);

    }
    
    public static void chgpass(String id){
    	_show(id,"chgpass");
    }
    
    public static void save(String id) throws Exception {
    	
    	Account account = Account.findById(Long.parseLong(id));
    	String pass = account.password;
    	
    	Binder.bind(account, "object", params.all());
    	String newpass = params.get("object.password");
    	
    	if(newpass !=null && !"".equals(newpass)){
    	//	account.setPasswordBase64(newpass);
    		account.setPassword(newpass);
    	}else{
    		account.password = pass;
    	}
    	
		List<Cloudprovider> all_account_cps = Cloudprovider.queryProviders(Cloudprovider.CloudType.CLOUDSTACK.name(),account);
		
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		for(Cloudprovider eachcsp : all_account_cps){
		  try{	
			CloudstackAdmin csa = new CloudstackAdmin(eachcsp);
			
			DomainCloudprovider dcp = account.domain.getDomainCloudprovider(eachcsp.id.toString());
			
			if(dcp == null || dcp.impldomainId == null)
				continue;
			
			try{
				String impluserid  =  eachcsp.onedetail(account).impluserId;
			
				Map impluser = csa.updateUser(dcp.impldomainId, impluserid, account, false);
				
				if(impluser == null){
					messages.add(String.format("Fail to update account: %s in %s CloudProvider",account.username,eachcsp.name));
				}
			}catch(Exception e){
				messages.add(String.format("Fail to update account: %s in %s CloudProvider",account.username,eachcsp.name));
			}
		  }catch(Exception e){
			 Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
		  }		 
		}
		
//		 List<Cloudprovider> all_account_ops = Cloudprovider.queryProviders(Cloudprovider.CloudType.OPENSTACK.name(),account);
//
//		 for(Cloudprovider eachcsp : all_account_ops){
//		   try{
//			   OpenstackAdmin osa = new OpenstackAdmin(eachcsp);
//			   String account_as_project = osa.createProject(account.username);
//				if(account_as_project == null){
//					messages.add(String.format("Fail to update account: %s in %s CloudProvider", account.username, eachcsp.name));
//				}
//		   }catch(Exception e){
//				Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
//		   }
//		 }
		 
	    _save(account);
	}
	
	public static void list() {
		
		renderArgs.put("domains", Domain.availables());
		renderArgs.put("roles", Role.all().fetch());		
		
		
		Where where = new Where(params);
		
		where.add("roleid","role_id=");
		where.add("domainid","domain_id=");
		
	  	_list(where);
	  	
	}

	
	public static void listkeys(long id) {
		
		Account account = Account.findById(id);
		notFoundIfNull(account);
		
		Domain domain = account.domain;
		
		List<DomainCloudprovider> dcps = domain.domainCloudproviders;
		
		render(account,dcps);
	  	
	}
	
	public static void showkeys(long id,long cpid) throws Exception {
		
		Account account = Account.findById(id);
		notFoundIfNull(account);
		
		Cloudprovider cp = Cloudprovider.findById(cpid);

		if(Cloudprovider.CloudType.CLOUDSTACK.toString().equals(cp.type) ){
			Map<String,String> details =  cp.detailshash(account.id);
			render(details);
		}		
	}

	
	public static void delete(long id){
		
		Account account = Account.findById(id);
		notFoundIfNull(account);				

		// add for git and cloudfoundry
		if (account.role.name.equals("user")) {
			ProjectService.deletePassDBInfoByOneUser(account.id);
			try {
				ApplicationService.deleteCloudFoundryUser(account);
			} catch (Exception e) {
				Logger.error(">> Deleting cloudfoundry account:"+account.username+"has error!!",e);
			}
			
			try{
				ApplicationService.deleteGitAccount(account);
			}catch (Exception e) {
				Logger.error(">> Deleting git account:"+account.username+"has error!!",e);
			}			
			
		}
		
		//call API to delete domain in all private cloud providers?
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		List<Cloudprovider> all_account_cps = Cloudprovider.queryProviders(Cloudprovider.CloudType.CLOUDSTACK.name(),account);		
		for(Cloudprovider eachcsp : all_account_cps){
			try{
				String providerId = eachcsp.id.toString();
				CloudstackAdmin csa = new CloudstackAdmin(providerId);
				
				String implaccountId =  eachcsp.onedetail(account).implaccountId;
				if(implaccountId == null)
					continue;
				
				if(csa.deleteAccount(implaccountId) == null){
					messages.add(String.format("Fail to delete account: %s in %s CloudProvider",account.username,eachcsp.name));
				}
			}catch(Exception e){
				messages.add(String.format("Fail to delete account: %s in %s CloudProvider",account.username,eachcsp.name));
			}
			//delete detail?
		}
		
		List<Cloudprovider> all_account_ops = Cloudprovider.queryProviders(Cloudprovider.CloudType.OPENSTACK.name(),account);
		
		for(Cloudprovider eachcsp : all_account_ops){
		   try{
			   OpenstackAdmin osa = new OpenstackAdmin(eachcsp);
			   String account_as_project = osa.deleteProject(account.username);
				if(account_as_project == null){
					messages.add(String.format("Fail to created account: %s in %s CloudProvider", account.username, eachcsp.name));
				}
		   }catch(Exception e){
				Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
		   }
		 }
		account.username = String.format("%s_removed_%d", account.username,System.currentTimeMillis());				
		
		_delete(account);		
	}    
	
	public static void deletes(String ids) {
		
		 //FIXME:
		 String where = String.format("id in (%s)", ids);
		 
		 List<Account> accounts = Account.find(where).fetch();
		 
		 //call API to delete domain in all private cloud providers?
		 List<String> messages = new ArrayList<String>();
		 renderArgs.put("message",messages);
					 
		for (Account account : accounts) {

			// add for git and cloudfoundry
			if (account.role.name.equals("user")) {				
				ProjectService.deletePassDBInfoByOneUser(account.id);
				try {
					ApplicationService.deleteCloudFoundryUser(account);
				} catch (Exception e) {
					Logger.error(">> Deleting cloudfoundry account:"+account.username+"has error!!",e);
				}
				
				try{
					ApplicationService.deleteGitAccount(account);
				}catch (Exception e) {
					Logger.error(">> Deleting git account:"+account.username+"has error!!",e);
				}							
				
			}

			account.username = String.format("%s_removed_%d", account.username,
					System.currentTimeMillis());

			List<Cloudprovider> all_account_cps = Cloudprovider.queryProviders(
					Cloudprovider.CloudType.CLOUDSTACK.name(), account);

			for (Cloudprovider eachcsp : all_account_cps) {
				try {

					String providerId = eachcsp.id.toString();

					String implaccountId = eachcsp.onedetail(account).implaccountId;
					if (implaccountId == null)
						continue;

					CloudstackAdmin csa = new CloudstackAdmin(providerId);
					if (csa.deleteAccount(implaccountId) == null) {
						messages.add(String
								.format("Fail to delete account: %s in %s CloudProvider",
										account.username, eachcsp.name));
					}
				} catch (Exception e) {
					messages.add(String.format(
							"Fail to delete account: %s in %s CloudProvider",
							account.username, eachcsp.name));
				}
			}

			List<Cloudprovider> all_account_ops = Cloudprovider.queryProviders(
					Cloudprovider.CloudType.OPENSTACK.name(), account);

			for (Cloudprovider eachcsp : all_account_ops) {
				try {
					OpenstackAdmin osa = new OpenstackAdmin(eachcsp);
					String account_as_project = osa
							.deleteProject(account.username);
					if (account_as_project == null) {
						messages.add(String
								.format("Fail to created account: %s in %s CloudProvider",
										account.username, eachcsp.name));
					}
				} catch (Exception e) {
					Logger.error("Fail to access %s cloudprovider: %s",
							eachcsp.name, e);
				}
			}

		}
		_delete(accounts);

	}

}
