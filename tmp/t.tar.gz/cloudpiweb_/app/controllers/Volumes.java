package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jobs.AsyncJob;
import jobs.MessageJob;
import models.Account;
import models.Cloudprovider;
import models.Server;
import models.Snapshot;
import models.Volume;
import models.Zone;
import models.spec.CurrentUser;
import models.spec.Message;
import models.spec.Where;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.compute.SnapshotState;

import play.data.binding.Binder;
import play.i18n.Messages;
import play.libs.F;
import play.mvc.Scope;
import service.compute.SnapshotService;
import service.compute.VolumeService;

import com.google.gson.Gson;

public class Volumes extends CRUD {

	public static void list() {

		Where where = new Where(params);
		where.add("cloudType", "cloudprovider.type=");
		where.add("volumeName", "name like");

		CurrentUser cuser = CurrentUser.current();
		if (!cuser.isSuper()) {
			where.addValue("created_by_id=", cuser.id);
		}

		_list(where);
	}

	/**
	 * 
	 * @description create volume page show
	 * @throws Exception
	 */

	public static void blank() throws Exception {
		_blank();
	}

	/**
	 * 
	 * @description create volume function
	 */
	public static void create() {
		Volume volume = new Volume();
		String zoneId = params.get("volume.zone.id");
		String type = params.get("volume.type");
		// String snapshotId = params.get("volume.snapshot.id");
		String name = params.get("volume.name");
		String size = params.get("volume.size");
		String cloudprovider_id = params.get("volume.cloudprovider.id");
		if ("".endsWith(zoneId) || "".endsWith(name) || "".endsWith(size)
				|| "".endsWith(cloudprovider_id))
			renderJSON(jsonMessage("300", "please input or select !"));
		if (!size.matches("\\d*")) {
			renderJSON(jsonMessage("300", "please input corrent volume size !"));
		} else {
			if ("CloudStack".equals(type)) {
				if (!"5".equals(size) && !"20".equals(size)
						&& !"100".equals(size)) {
					renderJSON(jsonMessage("300",
							"you can only create volume size: 5G, 20G, 100G !"));
				}

			}
		}
		Volume v = Volume.find("name=? and state !=?", name, "Delete").first();
		if(v != null)
			renderJSON(jsonMessage("300",
					"the volume is exist, please use another name !"));	
		
		try {
			String impId = "";
			String implsnapshotId = null;
			Zone zone = Zone.findById((long) Integer.parseInt(zoneId));
			// if (!"".endsWith(snapshotId) && snapshotId != null) {
			// snapshot = Snapshot.findById((long) Integer
			// .parseInt(snapshotId));
			// if (snapshot != null) {
			// params.put("volume.sourceClsid", snapshot.implsnapshotId);
			// implsnapshotId = snapshot.implsnapshotId;
			// }
			// }
			params.put("volume.sourceClsid", "null");
			VolumeService volumeService = new VolumeService(cloudprovider_id);
			if ((impId = volumeService.createVolume(implsnapshotId,
					Integer.parseInt(size), zone.implzoneId)) != null) {
				params.put("volume.name", name);
				params.put("volume.zone.id", zoneId);
				params.put("volume.cloudprovider.id", cloudprovider_id);
				params.put("volume.created_by.id", ""
						+ CurrentUser.current().id);
				params.put("volume.state", "AVAILABLE");
				params.put("volume.type", "dataDisk");
				params.put("volume.implvolumeId", impId);
				volume.createdAt = new Date(
						java.lang.System.currentTimeMillis());
				Binder.bind(volume, "volume", params.all());

				_create(volume);
			} else
				renderJSON(jsonMessage("300",
						Messages.get("volume.cerror", name)));
		} catch (Exception e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300", Messages.get("volume.cerror", name)));
		}
	}

	/**
	 * 
	 * @description delete volume
	 * @param ids
	 *            volume id
	 */

	public static void deleteVolume(String ids) {

		String where = String.format("id in (%s)", ids);
		List<Volume> volumes = Volume.find(where).fetch();

		List<String> messages = new ArrayList<String>();
		renderArgs.put("message", messages);
		Iterator<Volume> v = volumes.iterator();

		while (v.hasNext()) {
			Volume volume = v.next();
			String cloudId = volume.cloudprovider.id.toString();
			VolumeService volumeService = null;
			try {
				volumeService = new VolumeService(cloudId);
				// added by liubs
				volumeService.setProject(volume.created_by);
				if (volume.implvolumeId == null) {
					messages.add(volume.name + ": Invalid volume Id");
				} else {
					if (!volumeService.removeVolume(volume.implvolumeId)) {
						messages.add(Messages.get("volume.delete.error",
								volume.name));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				messages.add(e.getMessage().toString());				
				renderJSON(jsonMessage("300",messages.toString()));
			}
		}
		if (!volumes.isEmpty()) {
			_delete(volumes);
		}
//		} else
//			renderJSON(jsonMessage("300",
//					"Please check you network is connected !"));
	}

	/**
	 * 
	 * @description attach volume to server instance page show
	 * @param ids
	 *            volume id
	 */

	public static void attachVolume(String ids) {
		Volume volume = Volume.findById((long) Integer.parseInt(ids));

		Where where = new Where(null);
		where.addValue("cloudprovider_id =", volume.cloudprovider.id);
		where.addValue("zone_id =", volume.zone.id);
		where.addValue("state =", "RUNNING");
                where.or();
		where.addValue("state =", "PAUSED");
		where.and();

		CurrentUser cuser = CurrentUser.current();
		if (!cuser.isSuper()) {
			where.addValue("created_by_id=", cuser.id);
		}

		List<Server> servers = Server.find(where.where(), where.paramsarr())
				.fetch();

		// renderArgs.put(
		// "servers",
		// Server.find("cloudprovider_id=? and zone_id=? and state != ?",
		// volume.cloudprovider.id, volume.zone.id, "TERMINATED")
		// .fetch());
		// Server servers= Server.find("cloudprovider_id=? and zone_id=?",
		// volume.cloudprovider.id, volume.zone.id).first();
		render(volume, ids, servers);
	}

	/**
	 * 
	 * @description attach volume to server instance
	 * @param ids
	 */

	public static void attachVolumeimpl(String ids) {
		Volume volume = Volume.findById((long) Integer.parseInt(ids));
		String serverId = params.get("volume.server.id");
		String cloudId = volume.cloudprovider.id.toString();
		String device = params.get("device");
		if ("".endsWith(serverId) || "".endsWith(device))
			renderJSON(jsonMessage("300", "please input or select !"));
		Server server = Server.findById((long) Integer.parseInt(serverId));
		String implinstanceId = server.implinstanceId;
		Date time = new Date();
		try {
			VolumeService volumeService = new VolumeService(cloudId);

			// added by liubs
			volumeService.setProject(volume.created_by);
			if (volumeService.attachVolume(volume.implvolumeId, implinstanceId,
					device)) {
				params.put("volume.attachedAt", "" + time);
				params.put("volume.server.id", serverId);
				params.put("volume.state", "in-use");
				params.put("volume.device", device);
				Binder.bind(volume, "volume", params.all());
				volume.save();
				renderJSON(forwardJson("volumes", "/Volumes/list",
						Messages.get("volume.attach", volume.name)));
			} else
				renderJSON(jsonMessage("300",
						Messages.get("volume.aerror", volume.name)));
		} catch (Exception e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300",
					Messages.get("volume.aerror", volume.name)));
		}
	}

	/**
	 * 
	 * @description detach volume from server instance
	 * @param ids
	 *            volume id
	 */

	public static void deatchVolume(String ids) {
		Volume volume = Volume.findById((long) Integer.parseInt(ids));
		String cloudId = volume.cloudprovider.id.toString();
		try {
			VolumeService volumeService = new VolumeService(cloudId);
			// added by liubs
			volumeService.setProject(volume.created_by);
			
			if (volumeService.detachVolume(volume.implvolumeId)) {
				params.put("volume.state", "AVAILABLE");
				params.put("volume.server", "");
				params.put("volume.device", "");
				Binder.bind(volume, "volume", params.all());
				volume.save();
				renderJSON(forwardJson("volumes", "/Volumes/list",
						Messages.get("volume.deatch", volume.name)));
			} else
				renderJSON(jsonMessage("300",
						Messages.get("volume.derror", volume.name)));
		} catch (InternalException e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300",
					Messages.get("volume.derror", volume.name)));
		} catch (Exception e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300",
					Messages.get("volume.derror", volume.name)));
		}
	}

	/**
	 * 
	 * @description take a snapshot of volume
	 * @param ids
	 *            volume id
	 */

	public static void takeSnapshotVolume(String ids) {
		Volume volume = Volume.findById((long) Integer.parseInt(ids));
		String cloudId = volume.cloudprovider.id.toString();
		String description = "This snapshot created by "
				+ CurrentUser.current().name + " for " + volume.name;
		
		Snapshot snapshot = new Snapshot();
		try {
			SnapshotService snapshotService = new SnapshotService(cloudId);
			// added by liubs
			snapshotService.setProject(volume.created_by);
			if (volume.server != null) {
				snapshot.server = volume.server;
			}
			snapshot.cloudprovider = volume.cloudprovider;
			snapshot.volume = volume;
			snapshot.type = volume.type;
			snapshot.size = volume.size;
			snapshot.name = "from-" + volume.name;
			snapshot.state = SnapshotState.PENDING.toString();
			if ("AWS".equals(volume.cloudprovider.type))
				snapshot.hypervisorType = "XEN";
			else if ("CLOUDSTACK"
					.equals(volume.cloudprovider.type))
				snapshot.hypervisorType = "KVM";
			snapshot.created_by = new Account(CurrentUser.current().id);
			snapshot.createdAt = new Date(java.lang.System.currentTimeMillis());
			snapshot.save();	
 		    /**
 		     * commit the data for multi-threads operations.
 		     * */
			snapshot.em().getTransaction().commit();
			
			AsyncJob ajob = new AsyncJob(snapshotService, "createSnapshot",
					new F.Action<Map>() {
						public void invoke(Map param) {

							String session_key = (String) param
									.get(AsyncJob.session_key);
							Snapshot snapshot = Snapshot.findById((Long)param.get("snapshotId"));
							Map callresult = (Map) param
									.get(AsyncJob.result_key);
							String snapId = (String) callresult
									.get("snapshotId");
							if (null != snapId) {
								snapshot.implsnapshotId = snapId;
								snapshot.state = SnapshotState.AVAILABLE
										.toString();
								snapshot._save();
								
							}else{
								snapshot.state ="Delete";
								snapshot._save();
							}
							if (callresult.get(AsyncJob.event_key) != null) {
								MessageJob.publish(session_key,
										(Message) callresult
												.get(AsyncJob.event_key));
							} else {
								MessageJob.publish_info(session_key,
										String.format("Success to create snapshot %s!",snapshot.name));
							}
						}
					});
			ajob.initParams(Scope.Session.current().getId());
			ajob.addParam("snapshotId", snapshot.id);

			ajob.addInParam("implvolumeId", volume.implvolumeId);
			ajob.addInParam("description", description);

			ajob.now();
			renderJSON(forwardJson("volumes", "/Volumes/list",
					"Your task is running in back!"));
		} catch (Exception e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300", "Take " + volume.name
					+ " snapshot failed !"));
		}
	}

	/**
	 * 
	 * @description get cloudprovider information form database
	 * @param cloud
	 *            type
	 */

	public static void selectType(String cloudtype) {
		Gson gson = new Gson();

		List<Cloudprovider> result = Cloudprovider.queryProviders(cloudtype);

		List list = new ArrayList();
		for (Cloudprovider cloudprovider : result) {
			cloudprovider.cloudproviderDetails = null;
			list.add(cloudprovider);
		}
		String result2 = gson.toJson(list);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @description get zone information form database
	 * @param cloudproviderId
	 *            cloud provier id
	 */
	public static void selectZone(String cloudproviderId) {
		Gson gson = new Gson();
		List<Zone> result = Zone.find("cloudprovider_id = ?", cloudproviderId)
				.fetch();
		List list = new ArrayList();
		for (Zone zone : result) {
			zone.cloudprovider.cloudproviderDetails = null;
			list.add(zone);
		}
		String result2 = gson.toJson(list);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void selectSnapshot(String zoneId) {
		Gson gson = new Gson();
		Zone zone = Zone.findById((long) Integer.parseInt(zoneId));
		List<Snapshot> result = Snapshot.find(
				"cloudprovider_id = ? and state !=?", zone.cloudprovider.id,
				"delete").fetch();
		List list = new ArrayList();
		for (Snapshot snapshot : result) {
			snapshot.created_by = null;
			snapshot.cloudprovider = null;
			snapshot.server = null;
			snapshot.volume = null;
			list.add(snapshot);
		}
		String result2 = gson.toJson(list);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * @description show information about select volume
	 * @param ids
	 *            volume id
	 */

	public static void details(Long id) {
		Volume volume = Volume.findById(id);
		if (!"AVAILABLE".equals(volume.state) && !"in-use".equals(volume.state)) {
			String cloudId = volume.cloudprovider.id.toString();
			try {
				VolumeService volumeService = new VolumeService(cloudId);
				org.dasein.cloud.compute.Volume v = volumeService
						.getVolume(volume.implvolumeId);
				if (v != null) {
					volume.state = v.getCurrentState().toString();
					volume.save();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		render(volume);
	}

	/**
	 * 
	 * @Description simple method to sync the volume from remote clouds
	 *              tocloudpi db
	 * @param cloudId
	 */

	public static void syncVolume() {
		render();
	}

	/**
	 * 
	 * @Description simple method to sync the volume from remote clouds
	 *              tocloudpi db
	 * @param cloudId
	 */

	public static void syncVolumeimpl() {

		String cloudId = params.get("cloudprovider.id");
		if ("".equals(cloudId) || cloudId == null)
			renderJSON(jsonMessage("300", "please cloose a cloud !"));
		/** todo: manually test with cloudid, modified later */

		VolumeService volumeService = null;
		try {
			volumeService = new VolumeService(cloudId);
			volumeService.synchronizeVolumes();
		} catch (Exception e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300",
					"please check your's network whether is working !"));
		}
		renderJSON(forwardJson("volumes", "/Volumes/list",
				"sync volume successed !"));
	}
}
