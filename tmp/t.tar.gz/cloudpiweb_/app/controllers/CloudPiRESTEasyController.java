package controllers;

import models.rest.UserToken;

import org.jboss.resteasy.core.Dispatcher;
import org.jboss.resteasy.spi.HttpRequest;
import org.jboss.resteasy.spi.HttpResponse;
import org.jboss.resteasy.spi.ResteasyProviderFactory;

import play.Logger;
import play.Play;
import play.modules.resteasy.RESTEasyPlugin;
import play.modules.resteasy.RESTEasyRequestWrapper;
import play.modules.resteasy.RESTEasyResponseWrapper;
import play.mvc.Before;
import play.mvc.Controller;
import play.mvc.Http.Header;
import play.mvc.results.Unauthorized;

public class CloudPiRESTEasyController extends Controller {
	
	@Before
	public static void checkUserToken(){
		if (!request.url.startsWith("/api/info"))
		{
			//need to authenticate
			Header header = request.headers.get("authentication");
			if (header == null)
			{
				throw new Unauthorized("Unauthorized");
			}
			else
			{
				UserToken token = UserToken.decode(header.value());
				if (!token.valid())throw new Unauthorized("Token expired");
			}
		}
	}
	
	public static void serve(){
		Logger.info("RESTEasy controller invoked: %s", request.url);
		RESTEasyPlugin plugin = Play.plugin(RESTEasyPlugin.class);
		Dispatcher dispatcher = plugin.deployment.getDispatcher();
		ResteasyProviderFactory factory = plugin.deployment.getProviderFactory();
		HttpRequest restReq = new RESTEasyRequestWrapper(request, plugin.path);
		HttpResponse restRep = new RESTEasyResponseWrapper(request, response, factory);
		dispatcher.invoke(restReq, restRep);
	}
}
