package controllers;

import java.util.Date;
import java.util.Map;

import models.Account;
import models.Setting;
import models.Target;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import play.Logger;
import play.data.binding.Binder;
import play.i18n.Messages;
import service.pass.DNSService;

import com.samsung.cloudpi.client.dns.DnsService;

public class Targets extends CRUD {

	public static void list(int pageNum, String search, String searchFields, String orderField, String order,String where) {
		
		String search2 = params.get("search2");
		if (!"".equals(search2) && search2 != null) {
			where = String.format("state='%s'", search2);
		}
		_list( pageNum,  search,  searchFields,  orderField,  order, where);	

	}
	
	/*
	 * by zwz.
	 * call DNS restAPI to create a default zone for the target 
	 * 		and create the DNS in db
	 */
	public static void createTarget(){
		DnsService  dnsService = null;
		String targetName=null;
		String targetRouteIP = null;			
		//Map<String, String> result = null;
		//String zoneId = null;
		//String recordId = null;
		//Account account = null;
		
		
		//account = Account.findById( CurrentUser.current().id );
		
		targetName = params.get("object.name");
		targetRouteIP = params.get("object.routeip");
		
		//check targetName duplication
		if( Target.find( "from Target where name=?", params.get("object.name") ).first()!=null ){
			if (request.format.equals("json")) {
				renderJSON(forwardJson_error("DNSs",
						String.format("/%s/index", "DNSs"),
						Messages.get("The name, "+ params.get("object.name") + ", already exists!") )) ;
			} else {
				flash.error(Messages.get("The name, "+ params.get("object.name") +", already exists!"));
				redirect(request.controller + ".index");
			}
		}
		
		String recordIDList = DNSService.createARecordInAllViews(targetName, targetRouteIP);
		//Logger.info("########### recordIDList: %s", recordIDList);
		try{
			params.put("object.recordIds", recordIDList);
		}catch(Exception e){
			e.printStackTrace();
		}		
		
		//save in db
		Target target = new Target();
		Binder.bind(target, "object", params.all() );
		target.save();
		
		if (request.format.equals("json")) {
			renderJSON(forwardJson("targets",
					String.format("/%s/list", "targets"),
					Messages.get("Target created")));
		} else {
			flash.success(Messages.get("Target created"));
			redirect(request.controller + ".list");
		}		
	}

	
	/*
	public static void updateTarget(long tid){  
		DnsService  dnsService = null;
		Target target = null ;  //get from DB by id
		String oldName = null;
		String oldRouteIP = null;
		//long zoneId = -1;
		//Target targetToUpdate = new Target(); //constructed from page parameter
		
		
		String DNS_API_ADDRESS = "";
		String DNS_SERVER_ADDRESS = "";
		String DNS_TARGET_NAME_POSTFIX = "";
		String DNS_TARGET_ZONE_ID = "DNS_TARGET_ZONE_ID";
		Setting setting = null;
		
		setting = Setting.find("from Setting where name=?", _DNS_API_ADDRESS ).first();
		if(setting!=null)
			DNS_API_ADDRESS = setting.value;
		
		setting = Setting.find("from Setting where name=?", _DNS_SERVER_ADDRESS ).first();
		if(setting!=null)
			DNS_SERVER_ADDRESS = setting.value;
		
		setting = Setting.find("from Setting where name=?", _DNS_TARGET_NAME_POSTFIX ).first();
		if(setting!=null)
			DNS_TARGET_NAME_POSTFIX = setting.value;
		
		setting = Setting.find("from Setting where name=?", _DNS_TARGET_ZONE_ID ).first();
		if(setting!=null)
			DNS_TARGET_ZONE_ID = setting.value;
		
		
		target = Target.findById(tid);		
		
		if( target!=null ){
			oldName = target.name;
			oldRouteIP = target.routeip;
			//zoneId = target.zoneId;
			Binder.bind(target, "object", params.all() );
			
			//if targetName or routeIP changed, then the target's related DNS info must be updated(delete,recreate)
			if( !target.name.equals(oldName) || !target.routeip.equals(oldRouteIP) ){
				dnsService = new DnsService( DNS_API_ADDRESS );
				dnsService.deleteZone( String.valueOf( target.zoneId ) ); //delete zone
				
				//create zone and default 3 records
				Map<String, String> result = null;
				String newZoneId = null;
				String newRecordId = null;
				result = dnsService.createZone(target.name+DNS_TARGET_NAME_POSTFIX, "ns1."+target.name+DNS_TARGET_NAME_POSTFIX, "cloudpi"); //crerate zone by calling restAPI
				newZoneId = result.get("id");
				if(newZoneId==null){
					newZoneId="-1";
				}else{ //create 3 default records by calling restAPI
					dnsService.createRecord(newZoneId, "NS", "@", "ns1."+target.name+DNS_TARGET_NAME_POSTFIX, "cloudpi");
					dnsService.createRecord(newZoneId, "A", "ns1", DNS_SERVER_ADDRESS, "cloudpi");
					dnsService.createRecord(newZoneId, "A", "*", target.routeip, "cloudpi");
				}
				
				//delete corresponding record in the zone "cloudpi.org", and create new
				dnsService.deleteRecord( String.valueOf( target.recordId ) );				
				result = dnsService.createRecord(DNS_TARGET_ZONE_ID, "A", params.get("object.name"), target.routeip, "cloudpi");
				newRecordId = result.get("id");
				if( newRecordId==null )
					newRecordId = "-1";
				
				
				target.zoneId = Long.parseLong( newZoneId );
				target.recordId = Long.parseLong( newRecordId );
				target.save();
			}else{
				Binder.bind(target, "object", params.all() );
				target.save();
			}			
		}else{ //end if
			System.out.println("************ in Targets.updateTarget, target not found!");
		}
			
		if (request.format.equals("json")) {
			renderJSON( forwardJson("targets",
					String.format("/%s/list", "targets"),
					Messages.get("Target updated")) );
		} else {
			flash.success(Messages.get("Target updated") );
			redirect(request.controller + ".list");
		}
	} //end updateTarget
	*/
	
	public static void deleteTarget(){
		DnsService  dnsService = null;
		String []targetIds = params.getAll("ids");
		
		if( targetIds!=null && targetIds.length!=0 ){
			for(int i=0;i<targetIds.length;i++){
				long id = Long.parseLong( targetIds[i] );
				Target target = Target.findById( id );
				
				//mark the target deleted in db
				//target.state = BaseModel.DELETE;
				//target.removedAt = new Date( java.lang.System.currentTimeMillis() );
				//target.save();
				
				String viewRecords = target.recordIds;
				if( viewRecords!=null ){
					DNSService.deleteRecords(viewRecords);
				}
				target.delete();
			}			
		}  //end if
		
		if (request.format.equals("json")) {
			renderJSON( forwardJson("targets",
					String.format("/%s/list", "targets"),
					Messages.get("Target deleted")) );
		} else {
			flash.success(Messages.get("Target deleted") );
			redirect(request.controller + ".list");
		}
		
	} //end deleteTarget()
	
}
