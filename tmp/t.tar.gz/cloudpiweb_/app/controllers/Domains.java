package controllers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import models.Account;
import models.Cloudprovider;
import models.CloudproviderDetail;
import models.Domain;
import models.DomainCloudprovider;
import models.DomainTarget;
import models.Quota;
import models.Target;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;
import play.Logger;
import play.data.binding.Binder;
import play.modules.cas.annotation.Check;
import play.templates.Template;
import play.templates.TemplateLoader;
import service.admin.CloudstackAdmin;
import service.admin.OpenstackAdmin;
import service.pass.ApplicationService;
import utils.UserNameAnalyzer;

import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.UserInfo;

import flexjson.JSONSerializer;

@Path("/domains")
@Check("root")
public class Domains extends CRUD {

	 @GET
	 //@Produces("application/json")
	 @Produces("application/xml")
	 public String api_list(){
		 
		 List<Domain> domains = Domain.availables();
		 
		 if(request.format.equals("json")){
			 JSONSerializer postDetailsSerializer = new JSONSerializer().include(
	                "id","name","created_by.username").exclude("*");
			 return postDetailsSerializer.serialize(domains);
		 }else{
			 Template template = TemplateLoader.load("/Domains/api/list.html");
			 Map<String,Object> params = new HashMap();
			 params.put("domains", domains);
			 String rendered = template.render(params); 
			 
			 return rendered;
		 }
	 }
	 
	public static void create() throws Exception {
		
		Domain domain = new Domain();
		Binder.bind(domain, "object", params.all());
		domain.createdAt = new Date(java.lang.System.currentTimeMillis());
		domain.created_by = new Account(CurrentUser.current().id);
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		//domain._save();
		
		_create(domain);		
		
	}
    public static void save(String id) throws Exception {
    	Domain domain = Domain.findById(Long.parseLong(id));
    	Binder.bind(domain, "object", params.all());
    	
		List<Cloudprovider> allCloudstacks = Cloudprovider.cloudstacks();
		
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		for(Cloudprovider eachcsp : allCloudstacks){
			CloudstackAdmin csa = new CloudstackAdmin(eachcsp);
			
			DomainCloudprovider dcp = domain.getDomainCloudprovider(eachcsp.id.toString());
			
			if(dcp == null || dcp.impldomainId == null)
				continue;
			
			Map impldomain = csa.updateDomain(dcp.impldomainId, domain);
			if(impldomain == null){
				messages.add(String.format("Fail to update %s domain in %s CloudProvider",domain.name,eachcsp.name));
			}
		}
		
	    _save(domain);
	}
	 
	public static void delete(long id){
		
		Domain domain = Domain.findById(id);
		notFoundIfNull(domain);
		
		//call API to delete domain in all private cloud providers?
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		domain.name = String.format("%s_removed_%d", domain.name,System.currentTimeMillis());
		
		List<Cloudprovider> allCloudstacks = Cloudprovider.cloudstacks();
		for(Cloudprovider eachcsp : allCloudstacks){
		  try{
			 String providerId = eachcsp.id.toString();
			 CloudstackAdmin csa = new CloudstackAdmin(providerId);
			 if(csa.deleteDomain(domain) == null){
				messages.add(String.format("Fail to delete %s domain in %s CloudProvider",domain.name,eachcsp.name));
			 }
		  }catch(Exception e){
			 Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
		  }			  
		}
		_delete(domain);		
	}
   
	public static void deletes(String ids) {
    	 
		 String where = String.format("id in (%s)", ids);
		 List<Domain> domains = Domain.find(where).fetch();
		 
		 //call API to delete domain in all private cloud providers?
		 List<String> messages = new ArrayList<String>();
		 renderArgs.put("message",messages);
			
		 List<Cloudprovider> allCloudstacks = Cloudprovider.cloudstacks();
		 
		 for(Domain domain: domains){
			 
			 domain.name = String.format("%s_removed_%d", domain.name,System.currentTimeMillis());
			 
			 for(Cloudprovider eachcsp : allCloudstacks){
				try{
					String providerId = eachcsp.id.toString();
					CloudstackAdmin csa = new CloudstackAdmin(providerId);
					if(csa.deleteDomain(domain) == null){
						 messages.add(String.format("Fail to delete %s domain in %s CloudProvider",domain.name,eachcsp.name));
					}
					//delete
					//domain.deleteDomainCloudprovider(providerId);
				}catch(Exception e){
				   Logger.error("Fail to access %s cloudprovider: %s",eachcsp.name, e);
				   messages.add(String.format("Fail to delete %s domain in %s CloudProvider",domain.name,eachcsp.name));				   
			    }						
			}
		 }
		 _delete(domains);
		     
    }

	public static void selectcp() throws Exception {
		
		List<Cloudprovider> allcscps = Cloudprovider.cloudstacks();
		render(allcscps);

	}
	
	public static void syncdomains() throws Exception {
		
		try{
			Cloudprovider cp = Cloudprovider.findById(Long.parseLong(params.get("providerId")));
			CloudstackAdmin csa = new CloudstackAdmin(cp);
			List<Map> cs_domains = csa.queryDomains();
			if(cs_domains != null){
				for(Map impl_domain: cs_domains){
					Domain find_one = Domain.find("byName", impl_domain.get("name")).first();
					if(find_one != null){
						DomainCloudprovider dcp = DomainCloudprovider.domainProvider(find_one.id,cp.id);
						if(dcp != null){
							dcp.impldomainId = impl_domain.get("id").toString();
							dcp._save();
						}else{
							dcp = _savedcp(find_one,impl_domain.get("id").toString(),cp);
							find_one.domainCloudproviders.add(dcp);		
							find_one._save();							
						}
					}else{
						Domain new_one = new Domain();
						new_one.name = (String)impl_domain.get("name");
						new_one.created_by = new Account(CurrentUser.current().id);
						new_one.state = Domain.ACTIVE;
						new_one.save();
						
						DomainCloudprovider dcp = _savedcp(new_one,impl_domain.get("id").toString(),cp);
						new_one.domainCloudproviders.add(dcp);		
						new_one._save();
					}
				}
				renderJSON(jsonMessage("Success to import domains"));			
			}	
		}catch(Exception e){
			e.printStackTrace();
		}
		renderJSON(jsonError("Fail to import domains"));			
	}
	
	
	public static void listcps(long id) throws Exception {
		
		Domain domain = Domain.findById(id);
		notFoundIfNull(domain);
		
		List<Cloudprovider> allcps = Cloudprovider.availables();
		List<DomainCloudprovider> dcps = domain.domainCloudproviders;
		
		render(domain,dcps,allcps);
		
	}
	
	public static void updatecps(long id) throws Exception {
		
		Domain domain = Domain.findById(id);
		notFoundIfNull(domain);
		
		//delete all DomainCloudprovider
		for(DomainCloudprovider dcp: domain.domainCloudproviders){
			dcp.delete();
		}
		domain.domainCloudproviders.clear();
		domain._save();
		
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		boolean is_sync_account = params.get("is_sync_account") != null;
		
		List<Account> accounts_of_domain = null;
		if(is_sync_account){
			accounts_of_domain = Account.find("domain_id=? and state=?", domain.id,BaseModel.ACTIVE).fetch();
		}
		
		List<String> cpids = Arrays.asList(params.get("cpids").split(","));
		
		//TODO: sync all accounts user or project(in nova) for providers of the current domain
		for(String cpid : cpids){
			
			if("".equals(cpid))	continue;

			String domainimplid = null;
			
			Cloudprovider cp = Cloudprovider.findById(Long.parseLong(cpid));
			
			if(cp.isType(Cloudprovider.CloudType.CLOUDSTACK)){
				
				try{
					CloudstackAdmin csa = new CloudstackAdmin(cp);
					
					Map impldomain = csa.queryDomain(domain.name);
					
					if(impldomain == null){
						impldomain = csa.createDomain(domain);
						if(impldomain == null){
							messages.add(String.format("Fail to created %s domain in %s CloudProvider",domain.name, cp.name));
						}else{
							domainimplid = (String)impldomain.get("id");
						}
					}else{
						domainimplid = (String)impldomain.get("id");
					}
					
					if(domainimplid != null && is_sync_account && accounts_of_domain != null){
						_syncCloudstackAccounts(accounts_of_domain,cp,domainimplid,csa);
					}
					
				}catch(Exception e){
					e.printStackTrace();
				}
				
			}else if (cp.isType(Cloudprovider.CloudType.OPENSTACK)){
				OpenstackAdmin osa = new OpenstackAdmin(cp);
				if(is_sync_account && accounts_of_domain!= null){
					_syncOpenstackProjects(accounts_of_domain,osa);
				}
			}
			
			DomainCloudprovider dcp = _savedcp(domain,domainimplid,cp);
			domain.domainCloudproviders.add(dcp);
			
		}
		domain._save();
		
		renderJSON(jsonMessage("Success to update Cloud Providers"));
		
	}
    
    private static DomainCloudprovider _savedcp(Domain domain, String impldomainId, Cloudprovider cp){
    	DomainCloudprovider dcp = new DomainCloudprovider();
		dcp.domain = domain;
		dcp.impldomainId = impldomainId;
		dcp.cloudprovider = cp;
		dcp._save();	
		return dcp;
    }
    
    private static void _syncCloudstackAccounts(List<Account>accounts_of_domain, Cloudprovider cp,String impldomainId, CloudstackAdmin csa){
    	
    	for(Account object: accounts_of_domain){
    		
    		Map implaccount = csa.queryAccount(impldomainId, object);
    		
    		if(implaccount == null){
    			implaccount = csa.createAccount(impldomainId, object);
    		}else{
    		
    			List<Map> users = (List<Map>)implaccount.get("user");
    			Map first_user = users.get(0);
    			if(first_user.get("apikey") == null){
    				Map implkeys = csa.generateKeys(first_user.get("id").toString());
    		    	if(implkeys != null){
    		    		implaccount.put("apikey",implkeys.get("apikey"));
    		    		implaccount.put("secretkey",implkeys.get("secretkey"));
    		    	}    				
    			}else{
		    		implaccount.put("apikey",first_user.get("apikey"));
		    		implaccount.put("secretkey",first_user.get("secretkey"));    				
    			}
    		}
			
			if(implaccount != null){
				
				List<Map> users = (List<Map>)implaccount.get("user");
				Map first_user = users.get(0);
				
				CloudproviderDetail.delete("cloudprovider_id=? and account_id=?", cp.id,object.id);
				
				CloudproviderDetail endpointcpd = new CloudproviderDetail();
				endpointcpd.account = object;
				endpointcpd.cloudprovider = cp;
				endpointcpd.implaccountId = (String)implaccount.get("id");				
				endpointcpd.impluserId = (String)first_user.get("id");
				endpointcpd.name = "endpoint";
				endpointcpd.value = cp.detailshash().get("endpoint");
				endpointcpd.save();
				
				CloudproviderDetail apikeycpd = new CloudproviderDetail();
				apikeycpd.account = object;
				apikeycpd.cloudprovider = cp;
				apikeycpd.implaccountId = (String)implaccount.get("id");
				apikeycpd.impluserId = (String)first_user.get("id");
				apikeycpd.name = "apiSharedKey";
				apikeycpd.value = (String)implaccount.get("apikey");
				apikeycpd.save();
				
				CloudproviderDetail secretkeycpd = new CloudproviderDetail();
				secretkeycpd.account = object;
				secretkeycpd.cloudprovider = cp;
				secretkeycpd.implaccountId = (String)implaccount.get("id");
				secretkeycpd.impluserId = (String)first_user.get("id");
				secretkeycpd.name = "apiSecretKey";
				secretkeycpd.value = (String)implaccount.get("secretkey");
				secretkeycpd.save();     
			}
    	}
    }
    
    private static void _syncOpenstackProjects(List<Account>accounts_of_domain, OpenstackAdmin osa){
    	for(Account object: accounts_of_domain){
    		String implaccount = osa.queryProject(object.username);
    		if(implaccount == null){
        	 	osa.createProject(object.username);
    		}
    	}
    }
    
	public static void listquotas(long id) throws Exception {
		
		Domain domain = Domain.findById(id);
		notFoundIfNull(domain);
		
		List<DomainCloudprovider> dcps = domain.domainCloudproviders;
		
		render(domain,dcps);
	}
	
	public static void editquota(long id,long cpid) throws Exception {
		
		Domain domain = Domain.findById(id);
		Cloudprovider cp = Cloudprovider.findById(cpid);
		
		Quota object = Quota.cpquota(id,cpid);
		if(object == null){
			object = new Quota();
			object.domain = domain;
			object.cloudprovider = cp;
		}
		if(Cloudprovider.CloudType.CLOUDSTACK.toString().equals(cp.type) ||
				Cloudprovider.CloudType.OPENSTACK.toString().equals(cp.type) ){
		  render(domain,object);
		}
	}
	
	public static void savequota(long id) throws Exception {
		
		Domain domain = Domain.findById(id);
		notFoundIfNull(domain);
		
		Quota quota = null;
		if(params.get("quotaid") != null && !"".equals(params.get("quotaid"))){
			quota = Quota.findById(Long.parseLong(params.get("quotaid")));
		}else{
			quota = new Quota();
		}
		
		Binder.bind(quota, "object", params.all());
		quota.domain = domain;
		
		if(quota.cloudprovider.type.equals(Cloudprovider.CloudType.CLOUDSTACK.toString())){
			CloudstackAdmin csa = new CloudstackAdmin(quota.cloudprovider.id.toString());
			if(csa.setQuota(quota) == null){
				renderJSON(jsonError(String.format("Fail to set quota in %s domain of %s CloudProvider",domain.name,quota.cloudprovider.name)));
			}
		}else if(quota.cloudprovider.type.equals(Cloudprovider.CloudType.OPENSTACK.toString())){
			OpenstackAdmin osa = new OpenstackAdmin(quota.cloudprovider.id.toString());
			if(osa.setQuota(quota) == null){
				renderJSON(jsonError(String.format("Fail to set quota in %s domain of %s CloudProvider",domain.name,quota.cloudprovider.name)));
			}			
		}
		quota._save();
		renderJSON(jsonMessage("Success to save the Quota"));
	}	
	
	//by zwz
	public static void listtargets(long id){
		//Domain domain = Domain.findById(id);
		
		List targets = Target.find(" state=? ", BaseModel.ACTIVE).fetch();  //targets to be selected
		List<DomainTarget> domainTargets = null;
		Domain domain = Domain.findById(id);			

		notFoundIfNull(domain);
		
		domainTargets = domain.domainTargets;
		
		//to remove the domainTargets from targets
		//for(DomainTarget dt : domainTargets)
		//	targets.remove( dt.target );
		
		render(domain, targets, domainTargets);
	}
	//by zwz
	public static void saveDomainTargets(long id){
		Domain domain = Domain.findById(id);
		notFoundIfNull(domain); 
		List<String> targetids = null; //the target ids to be updated. (add, delete, retain)
		String ts = params.get("targetids");
		
		if( ts!=null && ts.length()!=0 )  //not null and selectids aren't empty
			targetids = Arrays.asList( ts.split(",") );
		else
			targetids = new ArrayList();
		
		//delete all first, then add new
		DomainTarget.delete("delete from DomainTarget dt where dt.domain.id=?", domain.id);
		
		//System.out.println("********* in Domains.saveDomainTargets, params.get(\"targetids\"):"+ts+ts.length() );
		//System.out.println("********* in Domains.saveDomainTargets, domainId:"+domain.id+", targetids:"+targetids);
		
		
		//add user to new target
		List<Account> domainUsers = new ArrayList<Account>();
		Where where = new Where(null);		
		where.addValue("domain_id=", domain.id);
		where.addValue("state=", BaseModel.ACTIVE);		
		domainUsers = Account.find(where.where(), where.paramsarr()).fetch();
		
		if( targetids.size()>0 )
			for(String s : targetids){
				long tid = Long.parseLong( s );
				Target tt = Target.findById(tid);
				notFoundIfNull(tt);
						
				//add user to new target
				CloudFoundryProxy proxy=ApplicationService.getCloudBeanProxy(tt.adminId, tt.adminPassword, tt.targetUrl);
				List<UserInfo> targetUsers=proxy.getUsers();
				List<String> emails=new ArrayList<String>();
				for(UserInfo info:targetUsers){
					emails.add(info.getEmail());
				}
				
				for(Account acc:domainUsers){
					String email=UserNameAnalyzer.analyzeUserName(acc.username, "cf");
					if(!emails.contains(email)){
						 //add for git and cloudfoundry user
						Logger.info(">> Add new target user: "+email+" ,target:"+tt.targetUrl);
						if (acc.role.name.equals("user")) {
							
							try {
								ApplicationService.createGitAccount(acc);
							} catch (Exception e) {
								Logger.error(">> Add new git account:"+acc.username+"has error!!",e);
							}
							
							try{
								ApplicationService.createCloudFoundryUser(acc.username,acc.passwordBase64,proxy);
							}catch (Exception e) {
								Logger.error(">> Add new cloudfoundry account:"+acc.username+"has error!!",e);
							}
						}
					}
				}
				
				
				
				//System.out.println("********* TargetID:"+ s );
				/* */
				
				DomainTarget dt = new DomainTarget();
				dt.domain = domain;
				dt.target = tt;
				dt.save();
			
			}		
		
		renderJSON(jsonMessage("Success to save the targets"));
		listtargets(domain.id);
	}
	    
}
