package controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jobs.AsyncJob;
import jobs.MessageJob;
import models.Account;
import models.Cloudprovider;
import models.Server;
import models.Snapshot;
import models.Volume;
import models.spec.CurrentUser;
import models.spec.Message;
import models.spec.Where;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.compute.SnapshotState;

import play.libs.F;
import play.mvc.Scope;
import service.compute.SnapshotService;

public class Snapshots extends CRUD {

	public static void list() {

		Where where = new Where(params);
		where.add("cloudType", "volume.cloudprovider.type=");
		where.add("snapshotName", "name like");

		CurrentUser cuser = CurrentUser.current();
		if (!cuser.isSuper()) {
			where.addValue("created_by_id=", cuser.id);
		}

		_list(where);

	}

	public static void blank() throws Exception {
		renderArgs.put("volumes",
				Volume.find(" type != ? and state != ?", "dataDisk", "Delete")
						.fetch());
		_blank();
	}

	/**
	 * 
	 * @description create snapshot function
	 */

	public static void create() {
		String name = params.get("snapshot.name");
		String volumeId = params.get("volume.id");
		if ("".endsWith(name) || "".endsWith(volumeId))
			renderJSON(jsonMessage("300", "please input or select !"));
		Snapshot s = Snapshot.find("name=? and state !=?", name, "Delete").first();
		if(s != null)
			renderJSON(jsonMessage("300",
					"the snapshot is exist ! please use another name"));			
		
		Volume volume = Volume.findById((long) Integer.parseInt(volumeId));
		String cloudId = volume.cloudprovider.id.toString();
		String description = "This snapshot created by "
				+ CurrentUser.current().name + " for " + volume.name;
		Snapshot snapshot = new Snapshot();
		try {
			SnapshotService snapshotService = new SnapshotService(cloudId);
			// added by liubs
			snapshotService.setProject(volume.created_by);
			if (volume.server != null) {
				snapshot.server = volume.server;
			}
			snapshot.cloudprovider = volume.cloudprovider;
			snapshot.volume = volume;
			snapshot.type = volume.type;
			snapshot.size = volume.size;
			snapshot.name = name;
			snapshot.state = SnapshotState.PENDING.toString();
			if ("AWS".equals(volume.cloudprovider.type))
				snapshot.hypervisorType = "XEN";
			else if ("CLOUDSTACK"
					.equals(volume.cloudprovider.type))
				snapshot.hypervisorType = "KVM";
			snapshot.created_by = new Account(CurrentUser.current().id);
			snapshot.createdAt = new Date(java.lang.System.currentTimeMillis());
			snapshot.save();	
 		    /**
 		     * commit the data for multi-threads operations.
 		     * */
			snapshot.em().getTransaction().commit();
			
			AsyncJob ajob = new AsyncJob(snapshotService, "createSnapshot",
					new F.Action<Map>() {
						public void invoke(Map param) {

							String session_key = (String) param
									.get(AsyncJob.session_key);
							Snapshot snapshot = Snapshot.findById((Long)param.get("snapshotId"));
							Map callresult = (Map) param
									.get(AsyncJob.result_key);
							String snapId = (String) callresult
									.get("snapshotId");
							if (null != snapId) {
								snapshot.implsnapshotId = snapId;
								snapshot.state = SnapshotState.AVAILABLE
										.toString();
								snapshot._save();
								
							}
							else{
								snapshot.state ="Delete";
								snapshot._save();
							}
							if (callresult.get(AsyncJob.event_key) != null) {
								MessageJob.publish(session_key,
										(Message) callresult
												.get(AsyncJob.event_key));
							} else {
								MessageJob.publish_info(session_key,
										String.format("Success to create %s snapshot",snapshot.name));
							}
						}
					});
			ajob.initParams(Scope.Session.current().getId());
			ajob.addParam("snapshotId", snapshot.id);

			ajob.addInParam("implvolumeId", volume.implvolumeId);
			ajob.addInParam("description", description);

			ajob.now();
			renderJSON(forwardJson("snapshots", "/Snapshots/list",
					"Your task is running in back!"));
		} catch (Exception e) {		
			e.printStackTrace();	
			renderJSON(jsonMessage("300", "Create " + name + " for "
					+ volume.name + " failed !"));
		}
	}

	/**
	 * 
	 * @description delete snapshot
	 * @param ids
	 *            snapshot id
	 */
	public static void delete(String ids) {

		String where = String.format("id in (%s)", ids);
		List<Snapshot> snapshots = Snapshot.find(where).fetch();

		List<String> messages = new ArrayList<String>();
		renderArgs.put("message", messages);

		Iterator<Snapshot> sit = snapshots.iterator();

		while (sit.hasNext()) {
			Snapshot snapshot = sit.next();

			Volume volume = Volume.findById((long) snapshot.volume.id);
			String cloudId = volume.cloudprovider.id.toString();
			SnapshotService snapshotService = null;
			try {
				snapshotService = new SnapshotService(cloudId);
				// added by liubs
				snapshotService.setProject(snapshot.created_by);

				if (snapshot.implsnapshotId == null) {
					messages.add(volume.name + ": Invalid snapshot Id");
				} else {
					snapshotService.removeSnapshot(snapshot.implsnapshotId);
				}
			} catch (Exception e) {
				e.printStackTrace();
				messages.add(e.getMessage().toString());
			}

		}

		if (!snapshots.isEmpty()) {
			_delete(snapshots);
		} else
			renderJSON(jsonMessage("300",
					"Please check you network is connected !"));
	}

	/**
	 * 
	 * @description show information about select snapshot
	 * @param ids
	 *            snapshot id
	 */

	public static void details(Long id) {
		Snapshot snapshot = Snapshot.findById(id);
		if (!"AVAILABLE".equals(snapshot.state)) {
			String cloudId = snapshot.cloudprovider.id.toString();
			try {
				SnapshotService snapshotService = new SnapshotService(cloudId);
				org.dasein.cloud.compute.Snapshot s = snapshotService
						.getSnapshot(snapshot.implsnapshotId);
				if (s != null) {
					snapshot.state = s.getCurrentState().toString();
					snapshot.save();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		render(snapshot);
	}

	/**
	 * 
	 * @Description simple method to sync the snapshot from remote clouds
	 *              tocloudpi db
	 * @param cloudId
	 */

	public static void syncSnapshot() {
		render();
	}

	/**
	 * 
	 * @Description simple method to sync the snapshot from remote clouds
	 *              tocloudpi db
	 * @param cloudId
	 */

	public static void syncSnapshotimpl() {

		String cloudId = params.get("cloudprovider.id");
		if ("".equals(cloudId) || cloudId == null)
			renderJSON(jsonMessage("300", "please cloose a cloud !"));

		SnapshotService snapshotService = null;
		try {
			snapshotService = new SnapshotService(cloudId);
			snapshotService.synchronizeSnapshots();
		} catch (Exception e) {
			e.printStackTrace();
			renderJSON(jsonMessage("300",
					"please check your's network whether is working !"));
		}
		renderJSON(forwardJson("snapshots", "/Snapshots/list",
				"sync snapshot successed !"));
	}

}
