package controllers;

import models.Account;
import models.spec.CurrentUser;
import play.Logger;
import play.cache.Cache;
import play.modules.cas.models.CASUser;
import play.mvc.Http;
import play.mvc.Scope;
import controllers.modules.cas.Security;

public class CasSecurity extends Security {

    public static boolean check(String profile) {
        Logger.debug("[CloudPiSecurity]: check :" + profile);
        CurrentUser cu = (CurrentUser)connected();
        return cu != null && profile.equals(cu.role);
    }
    
    public static void onAuthenticated(CASUser user) {
        Logger.debug("[CloudPiSecurity]: onAutenticated method");
                 
        Account acc = Account.find("byUsername", user.getUsername()).first();
        
        CurrentUser currentuser = (CurrentUser)Cache.get(Scope.Session.current().getId());
        
        if(currentuser == null){
        	 currentuser = new CurrentUser(acc.id,acc.username,acc.role.name,acc.passwordBase64);
        	 currentuser.setDomain(acc.domain.id, acc.domain.name);
        	 //Application.message_queue.withTimeout(60, TimeUnit.SECONDS).
        	 //		put(Scope.Session.current().getId(), new ArrayBlockingQueue<String>(10));
         }
         
        Cache.set(Scope.Session.current().getId(), currentuser, "60mn");
    }

    public static void onDisconnected() {
        Logger.debug("[CloudPiSecurity]: onAutenticated method");
        Cache.delete(Scope.Session.current().getId());
        Scope.Session.current().clear();
        
         //remove navtab information
        Http.Response.current().removeCookie("lastnavtab_id");
        Http.Response.current().removeCookie("lastnavtab_url");
        Http.Response.current().removeCookie("lastnavtab_title");
    }

    public static Object connected() {
        Logger.debug("[CloudPiSecurity]: onAutenticated method");
        Object obj = null;
        try{
        	obj = Cache.get(Scope.Session.current().getId());
	        if(obj != null){
	        	 Cache.set(Scope.Session.current().getId(), obj, "60mn"); 
	         }
        }catch(Exception e){
        	//e.printStackTrace();
        	play.Logger.warn("No a current user available");
        }
        return obj;
    }
    
    public static boolean isConnected() {
        return Cache.get(Scope.Session.current().getId()) != null;
    }    
    
}
