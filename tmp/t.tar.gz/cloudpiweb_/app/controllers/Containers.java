package controllers;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import models.Account;
import models.Cloudprovider;
import models.Container;
import models.Zone;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;

import play.i18n.Messages;
import service.storage.BlobStorageService;

import com.google.gson.Gson;

public class Containers extends CRUD {
	/**
	 * @description 
	 */
	public static void list(){
		Where where = new Where(params);
		where.add("bucketName", "name like");
		
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("created_by_id=",cuser.id);
  	 	}
		_list(where);
	}
	
	/**
	 * 
	 * @description get cloudprovider information form database
	 * @param cloud
	 *            type
	 */

	public static void selectType(String cloudtype) {
		Gson gson = new Gson();
		List<Cloudprovider> result = Cloudprovider.find(
				"type = ? and state != ?", cloudtype, "delete").fetch();
		List list = new ArrayList();
		for (Cloudprovider cloudprovider : result) {
			cloudprovider.cloudproviderDetails = null;
			list.add(cloudprovider);
		}
		String result2 = gson.toJson(list);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 
	 * @description get zone information form database
	 * @param cloudproviderId
	 *            cloud provier id
	 */
	public static void selectZone(String cloudproviderId) {
		Gson gson = new Gson();
		List<Zone> result = Zone.find("cloudprovider_id = ?",
				cloudproviderId).fetch();
		List list = new ArrayList();
		for (Zone zone : result) {
			zone.cloudprovider.cloudproviderDetails = null;
			list.add(zone);
		}
		String result2 = gson.toJson(list);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * @description show the create bucket page
	 */
	public static void blank(){
		
		render();
	}
	/**
	 * @description create an new bucket
	 * @param String region 
	 */
	public static void createContainer(){
		Container container = new Container();
		String containerName = params.get("container.name");
//		String zoneid = params.get("container.zone.id");
		String providerId = params.get("container.cloudprovider.id");
		try {
			if(containerName ==null||providerId ==null||"".equals(providerId)){
				renderJSON(jsonMessage("300", "Please  fill all the parameters correctly!"));
			}
			containerName = verifyName(containerName,true);
			BlobStorageService storageService = new BlobStorageService(providerId);
			/*Iterable<CloudStoreObject> buckets = storageService.listBuckets();
			for(Iterator i = buckets.iterator();i.hasNext();){
				CloudStoreObject cso = (CloudStoreObject) i.next();
				System.err.println(cso.getSize());
			}*/
			checkNetwork(storageService);
			String createName = null;
			if(!storageService.existsBucket(containerName)){
				createName = storageService.createBucket(containerName, true);
			}else{
				renderJSON(jsonMessage("300", "The bucket is exist!"));	
			}
			
			if(createName!=null){
				container.name = containerName;
				container.cloudprovider = new Cloudprovider(Long.parseLong(providerId));
				container.objectCount=0;
				container.bytesUsed=0;
				container.state=BaseModel.ACTIVE;
				container.created_by=new Account(CurrentUser.current().id);
				container.putTimestamp = new Date(java.lang.System.currentTimeMillis());
				container.createdAt = new Date(java.lang.System.currentTimeMillis());
				_create(container);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			renderJSON(jsonMessage("300", e.getMessage()));
		}
	}
	/**
	 * @descirption  The ajax function to load the bucket's detail message.
	 * @param bucketId
	 */
	public static void containerDetails(Long id){
		Container container = Container.findById(id);
		render(container);
		
	}
	/**
	 * @descirption  The ajax function to load the bucket's website message.
	 * @param bucketId
	 */
	public static void containerWebsite(String bucketId){
		render();
	}
	/**
	 * @descirption  The ajax function to load the bucket's permission message.
	 * @param bucketId
	 */
	public static void containerPermission(String bucketId){
		render();
	}
	/**
	 * 
	 */
	public static void deletes(String ids){
		String where = String.format("id in (%s)", ids);
		List<Container> containers = Container.find(where).fetch();

		List<String> messages = new ArrayList<String>();
		renderArgs.put("message", messages);
		Iterator<Container> v = containers.iterator();
		while (v.hasNext()) {
			Container container = v.next();
			String cloudId = container.cloudprovider.id.toString();
			BlobStorageService storageService = null;
			try {
				storageService = new BlobStorageService(cloudId);
				checkNetwork(storageService);
				if (container.name == null) {
//					containers.remove(container);
					messages.add(" Invalid container name");
				} else {
					if (storageService.existsBucket(container.name)) {
						storageService.deleteBucket(container.name);
						List<models.Object> objects = models.Object.find("byContainer_id", container.id).fetch();
						for(models.Object object : objects){
								object.state = BaseModel.DELETE;
								object.save();
						}						
//						containers.remove(container);
//						messages.add(Messages.get("container.delete.error",
//								container.name));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				messages.add(e.getMessage().toString());
//				containers.remove(container);
//				messages.add(Messages.get("container.delete.error", container.name));
			}
		}
		if (!containers.isEmpty()) {
			_delete(containers);
		}
	}
	private static void checkNetwork(BlobStorageService storageService) throws CloudException, InternalException{
		if(!storageService.isSubscribed()){
			renderJSON(jsonMessage("300", "Network error!"));	
		}
	}
	private static String verifyName(String name, boolean container) throws CloudException {
        if( name == null ) {
            return null;
        }
        name = name.toLowerCase().trim();
        if( name.length() > 255 ) {
            String extra = name.substring(255);
            int idx = extra.indexOf(".");
            
            if( idx > -1 ) {
                throw new CloudException("Azure names are limited to 255 characters.");
            }
            name = name.substring(0,255);
        }
        while( name.indexOf("--") != -1 ) {
            name = name.replaceAll("--", "-");         
        }
        StringBuilder str = new StringBuilder();

        for( int i=0; i<name.length(); i++ ) {
            char c = name.charAt(i);
            
            if( Character.isLetterOrDigit(c) || c == '-' ) {
                if( container ) {
                    if( i == 0 && !Character.isLetter(c) ) {
                        throw new CloudException("Azure container names must start with a letter.");
                    }
                }
                str.append(c);
            }
            else if( c == '.' ) {
                str.append(c);
            }
        }
        name = str.toString();
        
        if( name.length() < 1 ) { 
            return "000";
        }
        while( name.charAt(name.length()-1) == '-' ) {
            name = name.substring(0,name.length()-1);
            if( name.length() < 1 ) { 
                return "000";
            }
        }
        if( name.length() < 1 ) { 
            return "000";
        }
        else if( name.length() == 1 ) {
            name = name + "00";
        }
        else if ( name.length() == 2 ) {
            name = name + "0";
        }
        return name;
    }
	public static Timestamp getTimestamp(){
		Timestamp ret = null;
		try {
		Date date = new Date();
		long datelong = date.getTime();
		ret = new Timestamp(datelong);

		}
		catch (Exception e) {
		}
		return ret;
	}
}
