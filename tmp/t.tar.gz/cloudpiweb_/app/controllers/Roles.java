package controllers;

public class Roles extends CRUD {
	
}
