
package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import models.Account;
import models.Cloudprovider;
import models.Domain;
import models.DomainCloudprovider;
import models.Security;
import models.SecurityRule;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;

import org.dasein.cloud.network.Protocol;

import service.networking.FireWallService;

import com.google.gson.Gson;

public class Securitys extends CRUD {

    //added by liubs
	public static void list() {

		Where where = new Where(params);
		
		CurrentUser cuser = CurrentUser.current();
		if (!cuser.isSuper()) {
			where.addValue("created_by_id=", cuser.id);

			List<Long> cpids = new ArrayList<Long>();
			if(CurrentUser.current().isSuper()){
				renderArgs.put("cps", Cloudprovider.availables());
			}else{
				List<Cloudprovider> cps = new ArrayList<Cloudprovider>();
				for(DomainCloudprovider dcp:  DomainCloudprovider.domainProviders(CurrentUser.current().domainid)){
					cps.add(dcp.cloudprovider);	
					cpids.add(dcp.cloudprovider.id);
				}
				renderArgs.put("cps", cps);
			}
			where.in("cloudprovider_id",cpids);
		}
		where.add("name", "name like");
		
		if(!CurrentUser.current().isSuper()){
			where.add(String.format("ispublic = true or created_by_id = %d", CurrentUser.current().id));
		}
		
		_list(where);
	}
	//endadd
	
    public static void create() throws Exception {
    	Cloudprovider cloudprovider = Cloudprovider.findById(Long.parseLong(params.get("providerId")));
    	FireWallService fireWallService = new FireWallService(cloudprovider.id.toString());
    	Security security = new Security();
    	CurrentUser cuser = CurrentUser.current();
    	Account account = Account.findById(cuser.id);
    	Domain domain = Domain.findById(cuser.domainid);

    	String implsecurityId = fireWallService.createSecurityGroup(params.get("name"), params.get("description"));
    	
    	if(!"".equals(implsecurityId) && implsecurityId!=null){
    		security.accountId = cuser.id;
    		security.cloudprovider = cloudprovider;
    		security.created_by = account;
    		security.createdAt = new Date(java.lang.System.currentTimeMillis());
    		security.description = params.get("description");
    		security.domain = domain;
    		security.implsecurityId = implsecurityId;
    		security.ispublic = true;
    		security.name = params.get("name");
    		security.state = BaseModel.ACTIVE;
    		
    		_save(security);
    		
    	}else{
    		if (request.format.equals("json")) {
				renderJSON(forwardJson("300", "securitys",
						String.format("/%s/list", "securitys"), 
						"Could not create security group!"));
			} else {

				flash.error("Could not create security group!");
				redirect(request.controller + ".list");
			}
    	}
    	
    	
    	
    	
    	/*
    	ObjectType type = ObjectType.get(getControllerClass());
        notFoundIfNull(type);
        Constructor<?> constructor = type.entityClass.getDeclaredConstructor();
        constructor.setAccessible(true);
        Model object = (Model) constructor.newInstance();
        Security security = new Security();
        security.name = params.get("name");
        security.accountId =1;
        security.cloudprovider =new Cloudprovider();
        security.created_by = new Account();
        security.domain = new Domain();
        security.implsecurityId = "";
        security.ispublic = false;
        
        Binder.bind(object, "object", params.all());
        
    	validation.valid(object);
		if (validation.hasErrors()) {
			Logger.debug("Validation error: %s is %s",validation.errors().get(0).getKey(), validation.errors().get(0));
			if (request.format.equals("json")) {
				renderJSON(errorJMessage(Messages.get("crud.hasErrors")));
			} else {
				renderArgs.put("error", Messages.get("crud.hasErrors"));
				try {
					render(request.controller.replace(".", "/") + "/blank.html",
							type, object);
				} catch (TemplateNotFoundException e) {
					render("CRUD/blank.html", type, object);
				}
			}
		}
		object._save();
		
		if (request.format.equals("json")) {
			String typename = type.name.toLowerCase();
			renderJSON(forwardJson(typename,
					String.format("/%s/list", typename),
					Messages.get("crud.created", type.modelName)));
		} else {

			flash.success(Messages.get("crud.created", type.modelName));
			if (params.get("_save") != null) {
				redirect(request.controller + ".list");
			}
			if (params.get("_saveAndAddAnother") != null) {
				redirect(request.controller + ".blank");
			}
			redirect(request.controller + ".show", object._key());
		}  	
		*/
    }
	    
    /**
	 * @description prepare json for the dialogAjaxDone
	 * @param status 
	 * @param tabId
	 * @param url
	 * @param message
	 * @return json
	 */
	public static Map forwardJson(String status, String tabId,String url,String message){
        Map map = new HashMap();     
        map.put( "statusCode", status);     
        map.put( "navTabId", tabId);     
        map.put( "forwardUrl", url); 
        
        String allmessages = "";
        
        Object msgs = renderArgs.get("message");
        
        if(msgs != null){
        	if(msgs instanceof String){
        		allmessages = String.format("%s<br>%s", msgs,(message==null? "":message)); 
        	}else if(msgs instanceof List){
        		List msglist = (List)msgs;
        		
        		if(message != null){
        			msglist.add(message);
        		}
        		for(Object msg:msglist){
        			allmessages = String.format("%s<br>%s", allmessages,msg);
        		}
        	}
        }else{
        	 allmessages = message;
         }    
        if(!"".equals(allmessages))
          	 map.put( "message", allmessages);           
        
        return map;       
    }
    
    
    
	public static void delete(String ids){
		try{
		    Security security = Security.findById(Long.parseLong(ids));
		
		    FireWallService fireWallService = new FireWallService(security.cloudprovider.id.toString());
		    fireWallService.removeSecurityGroup(security.implsecurityId);
		    _delete(security);
		}catch(Exception e){
			
		}
	}
	
	public static void deleteRule(String id){
		try{
		SecurityRule sr = SecurityRule.findById(Long.parseLong(id));
		Security security = Security.findById(sr.securityId);
		FireWallService fireWallSerivece = new FireWallService(security.cloudprovider.id.toString());
		
		fireWallSerivece.removeSecurityGroupRules(security.implsecurityId, sr.allowedIpCidrs, Protocol.valueOf(sr.protocol), sr.startPort, sr.endPort);
		
		
		sr._delete();
		renderJSON(jsonMessage("Success to delete Rule!"));
		}catch(Exception e){
			
		}
	}
	
	
	public static void listcps(long id) throws Exception {
		Security security = Security.findById(id);
		List<SecurityRule> securityRules = SecurityRule.find("securityId=?", id).fetch();
		notFoundIfNull(security);
		notFoundIfNull(securityRules);
		
		
		render(security, securityRules);
	}
	
	public static void updatecps(long id) throws Exception{
		Security security = Security.findById(id);
		notFoundIfNull(security);
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message",messages);
		
		String startPortStr = null;
		String endPortStr = null;
		String protocolStr = params.get("protocol");
		String allowedIpCidrsStr = params.get("allowedIpCidrs");
		String protocolStr1=null;
		
		if ("TCP1".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr=params.get("startPort");
			endPortStr=params.get("endPort");
		}
		if ("UDP2".equals(protocolStr)) {
			protocolStr1="UDP";
			startPortStr=params.get("startPort");
			endPortStr=params.get("endPort");
		}
		if ("ICMP".equals(protocolStr)) {
			protocolStr1="ICMP";
			startPortStr="-1";
			endPortStr="-1";
		}
		
		if ("AllTCP".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="0";
			endPortStr="65535";
		}
		if ("AllUDP".equals(protocolStr)) {
			protocolStr1="UDP";
			startPortStr="0";
			endPortStr="65535";
		}
		
		if ("SSH".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="22";
			endPortStr="22";
		}
		if ("HTTP".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="80";
			endPortStr="80";
		}
		if ("HTTPS".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="443";
			endPortStr="443";
		}
		if ("SMTP".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="25";
			endPortStr="25";
		}
		if ("SMTPS".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="465";
			endPortStr="465";
		}
		if ("POP3".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="110";
			endPortStr="110";
		}
		if ("POP3S".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="995";
			endPortStr="995";
		}
		if ("IMAP".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="143";
			endPortStr="143";
		}
		if ("IMAPS".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="993";
			endPortStr="993";
		}
		if ("LDAP".equals(protocolStr)) {
			protocolStr1="TCP";
			startPortStr="389";
			endPortStr="389";
		}
		if ("DNS".equals(protocolStr)) {
			protocolStr1="UDP";
			startPortStr="53";
			endPortStr="53";
		}
		if ("MYSQL".equals(protocolStr)) {
			protocolStr1 ="TCP";
			startPortStr="3306";
			endPortStr="3306";
		}
		if ("RDP".equals(protocolStr)) {
			protocolStr1 = "TCP";
			startPortStr="3389";
			endPortStr="3389";
		}
		
		if(checkPort(startPortStr,endPortStr, id)){
			renderJSON(jsonError("The rule already exists!"));
		}else{
			SecurityRule securityRule = new SecurityRule();
			securityRule.allowedIpCidrs =allowedIpCidrsStr;
			securityRule.protocol=protocolStr1;
			if (startPortStr!=null && endPortStr!=null) {
				securityRule.startPort=Integer.parseInt(startPortStr);
				securityRule.endPort = Integer.parseInt(endPortStr);
			}
			securityRule.securityId=id;
			
			
			FireWallService fireWallService = new FireWallService(security.cloudprovider.id.toString());
			String implsecurityId = fireWallService.addSecurityGroupRules(security.implsecurityId, allowedIpCidrsStr, Protocol.valueOf(protocolStr1), Integer.parseInt(startPortStr), Integer.parseInt(endPortStr));
			
			securityRule.implsecurityruleId = implsecurityId;
			_save(securityRule);
		}
	}
	
	public static boolean checkPort(String startPort, String endPort, long securityId){
		List<SecurityRule> list = SecurityRule.find("startPort=? and endPort=? and securityId=?", Integer.parseInt(startPort),Integer.parseInt(endPort),securityId).fetch();
		if(list.size()>0){
			return true;
		}else{
			return false;
		}
	}
	
	public static void selectType(String type){
		try{
			Gson gson=new Gson();
	    	
	    	Where where = new Where(null);
	    
	    	CurrentUser cuser = CurrentUser.current();
	    	
	    	if(!cuser.isSuper()){
				List<DomainCloudprovider> dcps = DomainCloudprovider.domainProviders(CurrentUser.current().domainid);
		    	List<String> ids = new ArrayList();
		    	for(DomainCloudprovider dcp: dcps){
		    		ids.add(dcp.cloudprovider.id.toString());
		    	}
	    		where.in("id", ids);
			}
			
	    	where.addValue("type=",type);
	    	where.addValue("state=",BaseModel.ACTIVE);
	    	
	    	List<Cloudprovider> result = Cloudprovider.find(where.where(),where.paramsarr()).fetch();
	    	
			List list=new ArrayList();
			for(Cloudprovider provider:result){
				provider.cloudproviderDetails=null;
				list.add(provider);
			}
			
			String result2=gson.toJson(list);
			try {
				response.setContentTypeIfNotSet("application/json; charset=UTF-8");
				response.out.write(result2.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
	   }catch(Exception e){
		   e.printStackTrace();
	   }
	}
	
}
