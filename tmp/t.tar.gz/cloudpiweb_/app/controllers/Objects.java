package controllers;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jobs.AsyncJob;
import jobs.MessageJob;
import models.Account;
import models.Container;
import models.Object;
import models.Setting;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Message;
import models.spec.Where;

import org.apache.commons.codec.net.URLCodec;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.encryption.Encryption;
import org.dasein.cloud.storage.CloudStoreObject;
import org.dasein.cloud.storage.FileTransfer;

import play.Play;
import play.data.binding.Binder;
import play.i18n.Messages;
import play.jobs.Job;
import play.libs.F;
import play.libs.MimeTypes;
import play.libs.F.Promise;
import play.mvc.Http;
import play.mvc.Scope;
import service.storage.BlobStorageService;

public class Objects extends CRUD {
	
	private static final String ATTACHMENT_DISPOSITION_TYPE = "attachment";
	
	private static final String INLINE_DISPOSITION_TYPE = "inline";
	
	private static final String COPY_TYPE = "Copy";
	
	private static final String MOVE_TYPE = "Move";
	
	private static URLCodec encoder = new URLCodec();
	
	private static FileTransfer downLoadListener = null;
	
	public static void list(Long containerId){
		//String containerId = params.get("container.id");
		Where where = new Where(params);
		where.add("objectName", "name like");
		Container container = Container.findById(containerId);
		renderArgs.put("containerId", containerId);
		renderArgs.put("containerName", container.name);
		renderArgs.put("pending", BaseModel.PENDING);
		if(containerId==null||"".equals(containerId)){
			renderJSON(jsonMessage("300", "invalid container id!"));
		}else{
			where.addValue("container.id=",containerId);
		}
		_list(where);
	}
	
	/**
	 * @descirption   To load the upload files page.
	 * @param containerId
	 */
	public static void upload(Long containerId){
		renderArgs.put("containerId", containerId);
		render();
	}
	
	/**
	 * @descirption  To upload the files to AWS.
	 * 
	 */
	public static void uploadfiles(File Filedata){
		String containerId = params.get("containerId");
		String uploadFileName = Filedata.getName().trim();
		try {
			uploadFileName = verifyName(uploadFileName, false);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			renderJSON(jsonMessage("300",e.getMessage()));
		}
		List<Object> existObject = Object.find("name = ? and container_id = ? and state =?"
				,uploadFileName,containerId,BaseModel.ACTIVE).fetch();
		int renameMark = 1;
		while(existObject.size()!=0){
			String suffix = uploadFileName.substring(uploadFileName.lastIndexOf("."),uploadFileName.length());
			String firstName = uploadFileName.substring(0,uploadFileName.lastIndexOf("."));
			if(firstName.endsWith(".tar")){
				firstName = firstName.substring(0, firstName.lastIndexOf(".tar"));
				suffix = ".tar" + suffix;
			}
			Pattern pattern = Pattern.compile("\\u0028\\d+\\u0029\\u002E$");
			Matcher matcher = pattern.matcher(firstName+".");
			String renameSuffix= "";

			if(matcher.find()){
				renameSuffix = matcher.group();
				firstName += ".";
				firstName = firstName.substring(0,firstName.indexOf(renameSuffix));
				renameMark = Integer.parseInt(renameSuffix.substring(1, renameSuffix.length()-2))+1;
			}
			renameSuffix = "("+renameMark+")";
			uploadFileName = firstName + renameSuffix + suffix;
			existObject = Object.find("name = ? and container_id = ? and state <> ?"
					,uploadFileName,containerId,BaseModel.DELETE).fetch();
		}
		
		String uploadpath = Setting.value("uploadpath", "/tmp/uploads/");
		
		File file = new File(Play.applicationPath.getPath()+uploadpath+uploadFileName);
		
		FileInputStream is = null;
        FileOutputStream os = null;
        try {
            is = new FileInputStream(Filedata);
            os = new FileOutputStream(file);
            int read;
            byte[] buffer = new byte[1024*1024*8];
            while ((read = is.read(buffer)) > 0) {
                os.write(buffer, 0, read);
                os.flush();
            }
            
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                is.close();
            } catch (Exception ignored) {
            }
            try {
                os.close();
            } catch (Exception ignored) {
            }
        }
        await(500);
		uploadfiles(containerId,file);
		renderJSON(jsonMessage("200","upload success"));
	}
	
	private static void uploadfiles(String containerId,File file,boolean multipart,Encryption encryption){
		Container container = Container.findById(Long.parseLong(containerId));
		String providerId = container.cloudprovider.id.toString();
		try {
				BlobStorageService storageService = new BlobStorageService(providerId);
				String key = Scope.Session.current().getId();
				System.err.println("finish pid:"+Thread.currentThread().getId());
				AsyncJob ajob = new AsyncJob(storageService,"uploadJob",new F.Action<Map>()
						{
					     public void invoke(Map params)
					      {
					    	 String key = (String)params.get("key");
					    	 Map inparams = (Map)params.get("inparams");
					    	 long objectId = Long.parseLong(inparams.get("objectId").toString());
					    	 Map callresult = (Map)params.get(AsyncJob.result_key);
					    	 Object objectJob = Object.findById(objectId);
					    	 
					    	 if(callresult.get(AsyncJob.event_key) != null){
					    		
					    		 objectJob.state = "error";
					    		 objectJob.save();
					    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
					    	 }else{
					    		 File file = (File) callresult.get("file");
					    		 Container container = (Container) callresult.get("container");
					    		 objectJob.state = BaseModel.ACTIVE;
					    		 objectJob.createdAt = new Date(java.lang.System.currentTimeMillis());
								 Container container2 = Container.findById(container.id);
								 container2.bytesUsed += file.length();
								 container2.objectCount +=1;
								 container2.save();
								 objectJob.save();
					    		 MessageJob.publish_info(key,"Success to upload :"+file.getName());
					    	 }
					      }
					    });
					String filename = file.getName();
					Object object = new Object();
					object.name = filename;
					object.size = file.length();
					object.coutentType = filename.substring(filename.lastIndexOf(".")+1, filename.length());
					object.container = container;
					object.state = BaseModel.PENDING;
					object.created_by = Account.findById(CurrentUser.current().id);
					object.createdAt = new Date(java.lang.System.currentTimeMillis());
					object.save();
		 		    /**
		 		     * commit the data for multi-threads operations.
		 		     * */
					object.em().getTransaction().commit();
					
					ajob.initParams(key);
					ajob.addInParam("providerId", providerId);
					ajob.addInParam("fileName", file.getName());
					ajob.addInParam("container", container);
					ajob.addInParam("objectId", object.id);
					ajob.addInParam("encryption",encryption);
					ajob.addInParam("multipart",multipart);
					ajob.addInParam("storageService",storageService);
					ajob.now();
					
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			renderJSON(jsonMessage("300",e.getMessage()));
		}
		
	}
	
	public static void uploadfiles(String containerId,File file){
			Encryption encryption = null;
			boolean multipart = false;
			uploadfiles(containerId,file,multipart,encryption);
		
	}
	/**
	 * @descirption  To load the download page.
	 * @param objectIds
	 */
/*	public static void download(String id){
		Object object = Object.findById(Long.parseLong(id));
		render(object);
	}*/
	private static Promise<FileTransfer> pDownloadJob(final BlobStorageService storageService,final CloudStoreObject cloudfile,
			final File file) {
		  return new Job<FileTransfer>() { 
	            @Override 
	            public FileTransfer doJobWithResult() { 
	            	FileTransfer fileTransfer = new FileTransfer();
	            	try {
	            		fileTransfer =storageService.downLoad(cloudfile, file);
					} catch (Exception e) {
						e.printStackTrace();
						fileTransfer.setBytesTransferred(-99);
					}
	            	return fileTransfer; 
	            } 
	        }.now(); 
	}
	public static void download(String id){
		Object object = Object.findById(Long.parseLong(id));
		String path = Play.applicationPath.getPath()+"/tmp/";
		File file = null;
		FileTransfer  fileTransfer = null;
		try {
			BlobStorageService storageService = new BlobStorageService(object.container.cloudprovider.id.toString());
			CloudStoreObject cloudfile = new  CloudStoreObject();
			cloudfile.setDirectory(object.container.name);
			cloudfile.setName(object.name);
			cloudfile.setSize(object.size);
			
			file = new File(path+object.name);
			if(file.createNewFile()){
				Promise<FileTransfer> promise = pDownloadJob(storageService,cloudfile,file);
				downLoadListener = await(promise);
				if(downLoadListener.getBytesTransferred()==-99){
					
					renderArgs.put("error", "prepare download fail!");
				}
			}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			renderJSON(jsonMessage("300",e.getMessage()));
		}
		render(object);
	}
	
	public static void prepareDownload(String id){
		if(downLoadListener==null||downLoadListener.getBytesTransferred()==-99){
			renderJSON(jsonMessage("Error"));
		}else{
			if(downLoadListener!=null&&!downLoadListener.isComplete()){
				double progress = downLoadListener.getPercentComplete()*100;
				
				renderJSON(jsonMessage(Math.floor(progress*10)/10+""));
			}else{
				renderJSON(jsonMessage("Finished"));
			}
		}
		
	}
	
	public static void downloadfile(String id){
		Object object = Object.findById(Long.parseLong(id));
		String path = Play.applicationPath.getPath()+"/tmp/";
		File file = null;
		FileTransfer  fileTransfer = null;
		try {
			BlobStorageService storageService = new BlobStorageService(object.container.cloudprovider.id.toString());
			CloudStoreObject cloudfile = new  CloudStoreObject();
			cloudfile.setDirectory(object.container.name);
			cloudfile.setName(object.name);
			cloudfile.setSize(object.size);
			
			file = new File(path+object.name);
			if(file.createNewFile()){
				fileTransfer =storageService.downLoad(cloudfile, file);
				while(!fileTransfer.isComplete()){
					Thread.sleep(150);
				}
				
			}
			/*String mimetype = "application/octet-stream;charset=iso8859-1";  
			String downFileName = new String(file.getName().getBytes(),"iso8859-1");
			response.out.reset();
			response.setHeader("Content-Disposition", "attachment;filename=\""+downFileName+"\"");*/
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		S3(file,file.getName());
		//renderBinary(file,name);
	}
	private static void S3(File file,String name){
			boolean inline = false;
			BufferedInputStream is;
            if (name != null) {
            	response.setContentTypeIfNotSet(MimeTypes.getContentType(name));
            }
            String dispositionType;
            if(inline) {
                dispositionType = INLINE_DISPOSITION_TYPE;
            } else {
                dispositionType = ATTACHMENT_DISPOSITION_TYPE;
            }
            if (!response.headers.containsKey("Content-Disposition")) {
                if(name == null) {
                    response.setHeader("Content-Disposition", dispositionType);
                } else {
                    if(canAsciiEncode(name)) {
                        String contentDisposition = "%s; filename=\"%s\"";
                        response.setHeader("Content-Disposition", String.format(contentDisposition, dispositionType, name));
                    } else {
                        final String encoding = Http.Response.current().encoding;
                        String contentDisposition = "%1$s; filename*="+encoding+"''%2$s; filename=\"%2$s\"";
                        try {
							response.setHeader("Content-Disposition", String.format(contentDisposition, dispositionType, encoder.encode(name, encoding)));
						} catch (UnsupportedEncodingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
                    }
                }
            }
            if (file != null) {
            	try {
            		FileInputStream fis = new FileInputStream(file);
					is =  new BufferedInputStream(fis);
					byte[] buffer = new byte[1024*64];
	                int count = 0;
	                while ((count = is.read(buffer)) > 0) {
	                    response.out.write(buffer, 0, count);
	                    response.out.flush();
	                }
	                is.close();
	                fis.close();
	                file.delete();
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
            	
            } else {
            	throw new RuntimeException("file is null");
            }
	}
	/**
	 * @descirption  The ajax function to load the object's detail message.
	 * @param bucketId
	 */
	public static void details(Long id){
		Object object = Object.findById(id);
		render(object);
		
	}
	public static void rename(Long id,String newName){
		Object object = Object.findById(id);
		try {
			BlobStorageService storageService = new BlobStorageService(object.container.cloudprovider.id.toString());
			boolean overwrite = false;
			try {
				newName = verifyName(newName, false);
			} catch (CloudException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				renderJSON(jsonMessage("300",e.getMessage()));
			}
			if(storageService.existsFile(object.container.name, newName, false)!=0&&
					storageService.existsFile(object.container.name, newName, false)!=-1){
					overwrite = true;
			}
			
			storageService.renameFile(object.container.name, object.name, newName);
			
			if(overwrite){
				Object deleteObject = Object.find("name = ? and container_id =? and state <> ?", 
						newName,object.container.id,BaseModel.DELETE).first();
				deleteObject.state = BaseModel.DELETE;
				deleteObject.save();
			}
			object.name = newName;
			object.save();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			renderJSON(jsonMessage("300",e.getMessage()));
		}
		renderJSON(jsonMessage("operation success!"));
	}
	public static void deletes(String ids){

		String where = String.format("id in (%s)", ids);
		List<Object> objects = Object.find(where).fetch();

		List<String> messages = new ArrayList<String>();
		renderArgs.put("message", messages);
		long containerId = 0l;
		Iterator<Object> v = objects.iterator();
		while (v.hasNext()) {
			Object object = v.next();
			String cloudId = object.container.cloudprovider.id.toString();
			BlobStorageService storageService = null;
			try {
				storageService = new BlobStorageService(cloudId);
				if (object.name == null) {
//					objects.remove(object);
					messages.add(" Invalid object name");
				} else {
					if (storageService.existsFile(object.container.name, object.name, false)!=0l
							&&storageService.existsFile(object.container.name, object.name, false)!=-1l) {
						storageService.removeFile(object.container.name, object.name, false);
//						objects.remove(object);
//						messages.add(Messages.get("object.delete.error",
//								object.name));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				messages.add(e.getMessage().toString());
//				objects.remove(object);
//				messages.add(Messages.get("object.delete.error", object.name));
			}
		}
		if (!objects.isEmpty()) {
			_delete(objects);
		}
//		} else
//			renderJSON(jsonMessage("300",
//					"Please check you network is connected !"));
	
	}
	public static void move(String ids){
		String where = String.format("id in (%s)", ids);
		List<Object> objects = Object.find(where).fetch();
		List<Container> containers = Container.find("state = ? and id <>? and cloudprovider.type =?", 
					BaseModel.ACTIVE,objects.get(0).container.id,objects.get(0).container.cloudprovider.type).fetch();
		render(objects,containers,ids);
	}
	public static void moveObjects(){
		String ids = params.get("ids");
		String operationType = params.get("operationType");
		String targetContainer = params.get("targetContainer");
		String where = String.format("id in (%s)", ids);
		List<Object> objects = Object.find(where).fetch();
		Container container = Container.findById(Long.parseLong(targetContainer));
		
		List<String> messages = new ArrayList<String>();
		renderArgs.put("message", messages);
		long containerId = 0l;
		for (int i = 0; i < objects.size(); i++) {
			Object object = objects.get(i);
			containerId = object.container.id;
			String cloudId = object.container.cloudprovider.id.toString();
			BlobStorageService storageService = null;
			try {
				storageService = new BlobStorageService(cloudId);
				
				if (object.name == null) {
					objects.remove(object);
					messages.add(" Invalid object!");
				} else {
					long checkExist = storageService.existsFile(container.name, object.name, false);
					if(checkExist==0||checkExist==-1){
						if(MOVE_TYPE.equals(operationType)){
							storageService.moveFile(object.container.name, object.name, container.name);
							long checkMove = storageService.existsFile(container.name, object.name, false);
							if (checkMove==0l||checkMove==-1l) {
								objects.remove(object);
								messages.add(Messages.get("object.move.error",
										object.name));
							}else{
								object.container.bytesUsed -= object.size;
								object.container.objectCount -=1;
								object.container.save();
								object.container = container;
								object.createdAt = new Date(java.lang.System.currentTimeMillis());
								container.bytesUsed += object.size;
								container.objectCount +=1;
								container.save();
								
								object.save();
							}
						}else if(COPY_TYPE.equals(operationType)){
							CloudStoreObject copyObject =new CloudStoreObject();
							CloudStoreObject toDirectory =new CloudStoreObject();
							copyObject.setDirectory(object.container.name);
							copyObject.setName(object.name);
							copyObject.setContainer(false);
							toDirectory.setName(container.name);
							storageService.copy(copyObject,toDirectory,object.name);
							long checkMove = storageService.existsFile(container.name, object.name, false);
							if (checkMove==0l||checkMove==-1l) {
								objects.remove(object);
								messages.add(Messages.get("object.copy.error",
										object.name));
							}else{
								Object newObject = new Object();
								params.put("object.name", object.name);
								params.put("object.size", Long.toString(object.size));
								params.put("object.coutentType", object.coutentType);
								params.put("object.container.id", container.id.toString());
								params.put("object.state", BaseModel.ACTIVE);
								params.put("object.created_by.id", ""+CurrentUser.current().id);
								newObject.createdAt = new Date(java.lang.System.currentTimeMillis());
								Binder.bind(newObject, "object", params.all());
								container.bytesUsed += object.size;
								container.objectCount +=1;
								container.save();
								newObject.save();
							}
						}
					}else{
						renderJSON(jsonMessage("300",
								object.name + "is already exist in the target container!"));
					}
					
					
					
				}
			} catch (Exception e) {
				e.printStackTrace();
				objects.remove(object);
				renderJSON(jsonMessage("300",
						Messages.get("object.move.error", object.name)));
			}
		}
		renderJSON(forwardJson("objects","/objects/list?containerId="+containerId,"Move success!"));
	}
	public static void deleteTmpFile(String filename){
		File temp = null;
		temp = new File(filename);
		boolean result = false; 
		if (temp.isFile()) {
			   result =  temp.delete();
			   }
	}
/*	public static boolean delAllFile(String path){
		boolean flag = false;
		File file = new File(path);
		if (!file.exists()) {
		   return flag;
		}
		if (!file.isDirectory()) {
		   return flag;
		}
		String[] tempList = file.list();
		File temp = null;
		for (int i = 0; i < tempList.length; i++) {
		   if (path.endsWith(File.separator)) {
		    temp = new File(path + tempList[i]);
		   } else {
		    temp = new File(path + File.separator + tempList[i]);
		   }
		   if (temp.isFile()) {
		    temp.delete();
		   }
		   if (temp.isDirectory()) {
		    delAllFile(path + "/" + tempList[i]);
		    delFolder(path + "/" + tempList[i]);
		    flag = true;
		   }
		}
		return flag;
	}
	
	public static void delFolder(String folderPath) {
		try {
		   delAllFile(folderPath); // 删除完里面所有内容
		   String filePath = folderPath;
		   filePath = filePath.toString();
		   File myFilePath = new File(filePath);
		   myFilePath.delete(); // 删除空文件夹
		} catch (Exception e) {
		   e.printStackTrace();
		}
	}*/
	private static void checkNetwork(BlobStorageService storageService) throws CloudException, InternalException{
		if(!storageService.isSubscribed()){
			renderJSON(jsonMessage("300", "Network error!"));	
		}
	}
	private static boolean canAsciiEncode(String string) {
        CharsetEncoder asciiEncoder = Charset.forName("US-ASCII").newEncoder();
        return asciiEncoder.canEncode(string);
    }
	private static String verifyName(String name, boolean container) throws CloudException {
	        if( name == null ) {
	            return null;
	        }
	        StringBuilder str = new StringBuilder();
	        
	        name = name.toLowerCase().trim();
	        if( name.length() > 255 ) {
	            String extra = name.substring(255);
	            int idx = extra.indexOf(".");
	            
	            if( idx > -1 ) {
	                throw new CloudException("Azure names are limited to 255 characters.");
	            }
	            name = name.substring(0,255);
	        }
	        while( name.indexOf("--") != -1 ) {
	            name = name.replaceAll("--", "-");         
	        }
	        while( name.indexOf("..") != -1 ) {
	            name = name.replaceAll("\\.\\.", ".");         
	        }
	        while( name.indexOf(".-") != -1 ) {
	            name = name.replaceAll("\\.-", ".");         
	        }
	        while( name.indexOf("-.") != -1 ) {
	            name = name.replaceAll("-\\.", ".");         
	        }

	        for( int i=0; i<name.length(); i++ ) {
	            char c = name.charAt(i);
	            
	            if( Character.isLetterOrDigit(c) || c == '-' ) {
	                if( container ) {
	                    if( i == 0 && !Character.isLetter(c) ) {
	                        throw new CloudException("Azure container names must start with a letter.");
	                    }
	                }
	                str.append(c);
	            }
	            else if( c == '.'||c == '(' || c == ')' ) {
	                str.append(c);
	            }
	        }
	        name = str.toString();
	        
	        while( name.indexOf("..") != -1 ) {
	            name = name.replaceAll("\\.\\.", ".");         
	        }
	        
	        if( name.length() < 1 ) { 
	            return "000";
	        }
	        while( name.charAt(name.length()-1) == '-' ) {
	            name = name.substring(0,name.length()-1);
	            if( name.length() < 1 ) { 
	                return "000";
	            }
	        }
	        if( name.length() < 1 ) { 
	            return "000";
	        }
	        else if( name.length() == 1 ) {
	            name = name + "00";
	        }
	        else if ( name.length() == 2 ) {
	            name = name + "0";
	        }
	        return name;
	    }
}
