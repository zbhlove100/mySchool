package controllers;

import java.awt.Font;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.persistence.EntityManager;

import jobs.AsyncJob;
import jobs.MessageJob;
import models.Account;
import models.Cloudprovider;
import models.Cloudprovider.CloudType;
import models.Dnsrecord;
import models.Dnszone;
import models.Domain;
import models.IpAddress;
import models.Product;
import models.SSHKeypair;
import models.Security;
import models.Server;
import models.Setting;
import models.Template;
import models.Zone;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Message;
import models.spec.Where;

import org.apache.commons.lang.StringUtils;
import org.dasein.cloud.compute.MachineImage;
import org.dasein.cloud.compute.VirtualMachine;
import org.dasein.cloud.compute.VmState;
import org.dasein.cloud.compute.VmStatistics;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

import play.Logger;
import play.cache.Cache;
import play.libs.F;
import play.mvc.Scope;
import service.compute.DataCenterService;
import service.compute.ShellKeyService;
import service.compute.TemplateService;
import service.compute.VirtualMachineService;
import service.monitor.host.HostService;
import service.networking.DnsService;
import service.networking.FireWallService;

import com.google.gson.Gson;

public class Servers extends CRUD {
	
	//modified by liubs
	public static void Step(){
		
		//for step 1
		String cloudtype=params.get("cloudtype");
		if(cloudtype!=null&&!"".equals(cloudtype)){
			List<Cloudprovider> cloudproviderList = Cloudprovider.queryProviders(cloudtype);
			renderArgs.put("cloudproviderList",cloudproviderList);
		}
		String cloud =params.get("cloud");
		renderArgs.put("cloudtype",cloudtype);
		renderArgs.put("cloud",cloud);
		//for step 2
		String templateId=params.get("templateId");
		renderArgs.put("templateId",templateId);
		//for step 3
		String zoneId=params.get("dataCenterId");
		renderArgs.put("dataCenterId",zoneId);
		//for step 4
		String productId =params.get("productId");
		renderArgs.put("productId",productId);
		//for step 5
		String[] firewallId=params.getAll("firewallId");
		if(firewallId!=null&&firewallId.length>0){
			String temp=Arrays.toString(firewallId);
			if(temp!=null&&!"".equals(temp)){
				renderArgs.put("firewallId",temp.replaceAll("\\[", "").replaceAll("\\]", ""));
			}
		}
		//for step 6
		String name =params.get("name");
		String diskSizeInGb =params.get("diskSizeInGb");		
		String keypair =params.get("keypair");
		renderArgs.put("name",name);
		renderArgs.put("diskSizeInGb",diskSizeInGb);
		renderArgs.put("keypair",keypair);
		
		//for current step
		int step= params.get("step")==null? 0: Integer.parseInt(params.get("step"));
		
		try{
		  switch (step){
		    case 0:
			case 1:
				break;
			case 2:
				TemplateService templateService=new TemplateService(cloud);
				templateService.synchronizeTemplate();
				List<Template> templateList= Template.availables(cloud);	
				renderArgs.put("templateList",templateList);
				break;
			case 3:
				VirtualMachineService virtualMachineService=new VirtualMachineService(cloud);
				virtualMachineService.synchronizedProduct();
				Template tempate=Template.findById(Long.parseLong(templateId));
				List<Product> productList=virtualMachineService.listProductsFromDB(tempate.bits);
				renderArgs.put("productList",productList);
				break;
			case 4:
				DataCenterService dataCenterService=new DataCenterService(cloud);
				dataCenterService.synchronizeDataCenter();
				List<Zone> dataCenterList=dataCenterService.listDataCentersFromDB();
				renderArgs.put("dataCenterList",dataCenterList);
				break;
			case 5:
				List<Security>  firewallList = new ArrayList<Security>();
				try{
					FireWallService fireWallService=new FireWallService(cloud);
					fireWallService.synchronizeFireWall();
					firewallList=fireWallService.listFireWallFromDB();
				}catch(Exception e){
					// not supported?
					e.printStackTrace();
				}
				renderArgs.put("firewallList",firewallList);
				
				break;
			case 6:
				
				List<SSHKeypair> shellKeyList = new ArrayList<SSHKeypair>();
				try{
					ShellKeyService shellKeyService=new ShellKeyService(cloud);
					shellKeyList=shellKeyService.getKeypairFromDb();
				}catch(Exception e){
					// not supported?
					e.printStackTrace();
				}
				renderArgs.put("shellKeyList",shellKeyList);
				
				Zone zone = Zone.findById(Long.parseLong(zoneId));
				renderArgs.put("zone_name",zone.name);

				Template template = Template.findById(Long.parseLong(templateId));
				renderArgs.put("template_name",template.name);

				Product product = Product.findById(Long.parseLong(productId));
				renderArgs.put("product_name",product.name);
				
				break;
				
			case 7:
		  }
		}catch(Exception e){
			e.printStackTrace();			
			//show error message here
		}
		
		render("Servers/newserver_step"+step+".html");			

	}
	
	/**
	 * save the vituralmahine info,during the process of creating,just save the 
	 * virtualmachine info into cache;otherwise the virutal machine is saved into
	 * database and the create intferace will be invoked
	 */
	public static void save2(){
		
		Server server=new Server();
		String cloud=params.get("cloud");
		String cloudProviderId=null;
		if(cloud==null||"".equals(cloud)){
			cloudProviderId=""+server.cloudprovider.id;
		}else{
			cloudProviderId=cloud;
			server.cloudprovider=new Cloudprovider(Long.parseLong(cloud));
		}
		String zoneId=params.get("dataCenterId");
		if(zoneId!=null&&!"".equals(zoneId)){
			Zone zone=Zone.findById(Long.parseLong(zoneId));
			server.zone= zone;
		}
		
		String productId=params.get("productId");
		if(productId!=null&&!"".equals(productId)){
			Product product=Product.findById(Long.parseLong(productId));
			server.product=product;
		}
		String diskSizeInGb=params.get("diskSizeInGb");
		String keypair=params.get("keypair");
		if(keypair==null||"".equals(keypair)||"none".equals(keypair)){
			server.sshkeypair=null;
		}else{
			SSHKeypair sshKeypair=SSHKeypair.findById(Long.parseLong(keypair));
			server.sshkeypair=sshKeypair;
		}
		//server.cloudprovider=this.provider; cloudpi
		String name=params.get("name");
		if(name!=null&&!"".equals(name)){
			server.name=name;
		}
		String templateId=params.get("templateId");
		if(templateId!=null&&!"".equals(templateId)){
			server.templateId=Long.parseLong(templateId);
		}
		String firewallId=params.get("firewallId");
		String[] firewallArray=null;
		if(firewallId!=null&&!"".equals(firewallId)){
			
			firewallArray=firewallId.split(",");
			
			//added by liubs, why it is name rather id for nova EC2 api?
			Cloudprovider cp = Cloudprovider.findById(server.cloudprovider.id);
			
			if(Cloudprovider.CloudType.OPENSTACK.toString().equals(cp.type)){
				List<Security> securitys = Security.find("state !=? and cloudprovider=? and implsecurityId in (?)", Security.DELETE,cp, firewallId).fetch();
				for(int i=0; i < securitys.size(); i++){
					firewallArray[i] = securitys.get(i).name;
				}
			}
			//end
			
		}
		server.ismonitor = false;
		server.domain = new Domain(CurrentUser.current().domainid);
		server.created_by = new Account(CurrentUser.current().id);
		server.state = VmState.PENDING.name();

		EntityManager em = server.em();
		//em.getTransaction().begin();
		//em.persist(server);
		server.save();
		em.getTransaction().commit();
		
		
		String step=params.get("step");
		
		if(!"7".equals((step))){
			Map map2 = new HashMap();     
			map2.put( "statusCode", "200");     
			map2.put( "forwardUrl", "/Servers/addServer?step="+step+"&cloud="+cloudProviderId);  
			renderJSON(map2);
		}else{
			try{
				VirtualMachineService service=new VirtualMachineService(cloudProviderId);
				AsyncJob serverJob = new AsyncJob(service, "job_saveServer",
						new F.Action<Map>() {
							public void invoke(Map param) {
								
								String key = (String)param.get(AsyncJob.session_key);
						    	 
						    	Map callresult = (Map)param.get(AsyncJob.result_key);
						    	 
						    	 if(callresult.get(AsyncJob.event_key) != null){
						    	
						    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));

						    	 }else{
						    		
						    		 Server server = (Server)callresult.get("server");
						    		 
						    		 MessageJob.publish_info(key,String.format("Success to create %s instance",server.name));
						    		 
						    		 String publicIp = (String)callresult.get("publicIp");
						    		 
								     DnsService dnsService = new DnsService();
								     
								     String cpType = server.cloudprovider.type.toLowerCase();
								     String recordType = "A";
								     String ttl = "86400";
								     
						    		 if(server.privateIp != null){
						    			 
										//add by david Gao
								    	String zoneId1 = Setting.value("PRIVATE_DNSZONE_ID");
								    	String ip = StringUtils.replace(server.privateIp, ".", "-");
								        String host = ip + "." + cpType;
								    	
								        String privateview = Setting.value("PRIVATE_VIEW","Internal");
								    	Map<String,String> map = dnsService.createRecord(zoneId1, recordType, host, ttl, server.privateIp, privateview);
								    	
								    	/*
								    	System.out.println("====>"+DnsEndpoint);
								    	System.out.println("====>"+zoneId1);
								    	System.out.println("====>"+server.privateIp);
								    	System.out.println("====>"+privateview);
								    	System.out.println("====>"+map.get("id"));
								    	//*/
								    	
								    	String implrecordId = map.get("id");
								    	if(implrecordId != null){
								    		
									    	Dnsrecord dzr = new Dnsrecord();
									    	
									    	dzr.em().getTransaction().begin();
									    	
									    	dzr.createdById = server.created_by.id;
									    	dzr.dnszone = Dnszone.find("byName", cpType).first();
									    	dzr.name = host + "." +map.get("zone_name");
									    	dzr.state = BaseModel.ACTIVE;
									    	dzr.ttl = Integer.parseInt(ttl);
									    	dzr.type = recordType;
									    	dzr.value = server.privateIp;
									    	dzr.impldnsrecord_id = implrecordId;
									    	dzr.view = privateview;
									    	
									    	dzr.save();	
									    	
									    	dzr.em().getTransaction().commit();
									    	
								    	}else{
								    		Logger.error("Fail to created private dns");
								    	}
									}
						    		 
							    	//for rackspace instance public dns
							    	if(publicIp != null){
							    		
										String ip = StringUtils.replace(publicIp, ".", "-");
										
										List<String> publicviews = Setting.values("view");
										
										String implids = "";
										String zonename = null;
										
										for(String view: publicviews){
								    		Map<String,String> dns_result = dnsService.createRecord(Setting.value("PUBLIC_DNSZONE_ID"), 
								    				recordType, ip+ "."+cpType, 
								    				ttl, publicIp, view);
								    		implids += dns_result.get("id")+",";
								    		zonename = dns_result.get("zone_name");
										}
										if(!"".equals(implids) && zonename != null){
								    		Dnsrecord dzr = new Dnsrecord();
								    		dzr.em().getTransaction().begin();
								    		
								    		dzr.createdById = server.created_by.id;
								    		dzr.dnszone = Dnszone.find("byName", cpType).first();
									    	dzr.name = ip+ "."+cpType + "." +zonename;
									    	dzr.state = BaseModel.ACTIVE;
									    	dzr.ttl = Integer.parseInt(ttl);
									    	dzr.type = recordType;
									    	dzr.value = publicIp;
									    	dzr.impldnsrecord_id = implids;
									    	dzr.view = "All";
									    	dzr.save();
									    	
									    	dzr.em().getTransaction().commit();
										}

							    	}
						    	 }
							}
						});				
				
				serverJob.initParams(Scope.Session.current().getId());
				serverJob.addInParam("serverId", server.id);
				serverJob.addInParam("diskSizeInGB", diskSizeInGb);
				serverJob.addInParam("firewallId", firewallArray);
				
				serverJob.now();
				
//				//String ... protectedByFirewalls
//				AsyncJob ajob = new AsyncJob(service, "saveMetricId",
//						new F.Action<Map>() {
//							public void invoke(Map param) {
//							}
//						});
//				ajob.initParams(Scope.Session.current().getId());
//				ajob.addInParam("serverId", server.id+"");
//				ajob.now();

				renderJSON(forwardJson("servers","/servers/list"));

			}catch(Exception e){
				e.printStackTrace();				
				renderJSON(jsonError("Fail to create server:"+e.getMessage()));
				//show error messages
			}
		}
	}
	
	
	public static void clear(){
		Cache.delete(Scope.Session.current().getId()+"server");
		Cache.delete(Scope.Session.current().getId()+"diskSize");
		Cache.delete(Scope.Session.current().getId()+"keypair");
		Cache.delete(Scope.Session.current().getId()+"firewallId");
	}
	/**
	 * 
	 */
	public static void addServer(){
		String cloud=params.get("cloud");
		String step=params.get("step");
		
		//server.d
		int iStep=1;
		if(step!=null&&!"".equals(step)){
			iStep=Integer.parseInt(step);
		}
		 Server server=(Server)Cache.get(Scope.Session.current().getId()+"server");
		 if(server==null){
			 server=new Server();
			 server.cloudprovider=new Cloudprovider();
		 }
		 String diskSize=(String)Cache.get(Scope.Session.current().getId()+"diskSize");
		 if(diskSize==null){
			 diskSize=""; 
		 }
		try{
		  switch (iStep){
			case 1:
				render("Servers/newserver_step"+iStep+".html",server,diskSize);
				break;
			case 2:
				List<Template> templateList= Template.availables(cloud);//templateService.listAllFromDB();
				//if(templateList.size() == 0){
					TemplateService templateService=new TemplateService(cloud);
					//Iterable<MachineImage> templateList=templateService.listAllTemplate();
					templateService.synchronizeTemplate();			
					templateList= Template.availables(cloud);					
				//}
				render("Servers/newserver_step"+iStep+".html",templateList,server,diskSize);
				break;
			case 3:
				VirtualMachineService virtualMachineService=new VirtualMachineService(cloud);
				virtualMachineService.synchronizedProduct();
				//Iterable<VirtualMachineProduct> productList=virtualMachineService.listProducts(Architecture.I32);
				Template tempate=Template.findById(server.templateId);
				List<Product> productList=virtualMachineService.listProductsFromDB(tempate.bits);
				render("Servers/newserver_step"+iStep+".html",productList,server,diskSize);
				break;
			case 4:
				DataCenterService dataCenterService=new DataCenterService(cloud);
				dataCenterService.synchronizeDataCenter();
				List<Zone> dataCenterList=dataCenterService.listDataCentersFromDB();
				render("Servers/newserver_step"+iStep+".html",dataCenterList,server,diskSize);
				break;
			case 5:
				List<Security>  firewallList = new ArrayList<Security>();
				try{
					FireWallService fireWallService=new FireWallService(cloud);
					fireWallService.synchronizeFireWall();
					firewallList=fireWallService.listFireWallFromDB();
				}catch(Exception e){
					// not supported?
					e.printStackTrace();
				}
				render("Servers/newserver_step"+iStep+".html",
						firewallList,server,diskSize);
				break;
			case 6:
				String firewallId="";
				String[] firewallIds=(String[])Cache.get(Scope.Session.current().getId()+"firewallId");
				if(firewallIds!=null&&firewallIds.length>0){
					for(String temp:firewallIds){
						firewallId=firewallId+temp+",";
					}
					firewallId=firewallId.substring(0,firewallId.length()-1);
				}
				tempate=Template.findById(server.templateId);
				
				List<SSHKeypair> shellKeyList = new ArrayList<SSHKeypair>();
				try{
					ShellKeyService shellKeyService=new ShellKeyService(cloud);
					shellKeyList=shellKeyService.getKeypairFromDb();
				}catch(Exception e){
					// not supported?
					e.printStackTrace();
				}
				render("Servers/newserver_step"+iStep+".html",server,tempate,firewallId,diskSize,shellKeyList);
				break;
			default:
				render("Servers/newserver_step"+iStep+".html");
		  }
		}catch(Exception e){
			   e.printStackTrace();			
			//show error message here
		}
	}
	/**
	 * 
	 * @param ids the virutalmachine's id of cloudprovider 
	 */
	public static void startServer(String ids) {
	  try{
		if(ids!=null&&!"".equals(ids)){
			String[] idarra=ids.split(",");
			for(String id:idarra){
				VirtualMachineService service=VirtualMachineService.createServiceByServerId(id);
				service.boot(id);
			}
		}
		renderJSON(forwardJson("servers","/VirtualMachines/list"));
	  }catch(Exception e){
		   e.printStackTrace();		  
		//show error message here
	  }		
	}
	/**
	 * 
	 * @param ids the virutalmachine's id of cloudprovider 
	 */
	public static void stopServer(String ids) {
	   try{
			if(ids!=null&&!"".equals(ids)){
				String[] idarra=ids.split(",");
				for(String id:idarra){
					VirtualMachineService service=VirtualMachineService.createServiceByServerId(id);
					service.pause(id);
				}
			}
			renderJSON(forwardJson("servers","/servers/list"));
	   }catch(Exception e){
		   e.printStackTrace();		   
		 //show error message here
	   }
	}
	   
	/**
	 * 
	 * @param ids the virutalmachine's id of cloudprovider 
	 */
	public static void deleteServer(String ids) {
	  try{
		if(ids!=null&&!"".equals(ids)){
			String[] idarra=ids.split(",");
			
			for(String id:idarra){
				
				Server server = Server.findById(Long.parseLong(id));
				if(server == null)
					continue;
				if(server.implinstanceId ==null){
					server.delete();
					continue;
				}
				VirtualMachineService service=VirtualMachineService.createServiceByServerId(id);
				
				//add by david gao
				VirtualMachine virtualMachine = null;
				virtualMachine = service.getVirtualMachine(id);
				
				String privateview = Setting.value("PRIVATE_VIEW");
				Dnsrecord privateDnsrecord = Dnsrecord.find("value=? and view = ?", (virtualMachine.getPrivateIpAddresses()==null?"":virtualMachine.getPrivateIpAddresses()[0]),privateview).first();
				List<Dnsrecord> publicDnsrecords = Dnsrecord.find("value=? and view != ?", (virtualMachine.getPublicIpAddresses()==null?"":virtualMachine.getPublicIpAddresses()[0]),privateview).fetch();
		    	DnsService dnsService = new DnsService();
		    	if(privateDnsrecord!=null){
		    		dnsService.deleteRecord(privateDnsrecord.impldnsrecord_id);
		    		Dnsrecords.logicalDelete(privateDnsrecord, "models.Dnsrecord");
		    		//privateDnsrecord._delete();
		    	}
		    	if(publicDnsrecords!=null){
		    		for(Dnsrecord dnsrecord : publicDnsrecords){
		    			String []implrecordids = dnsrecord.impldnsrecord_id.split(",");
		    			for(String implrecordid: implrecordids){
		    				if(!"".equals(implrecordid)){
		    					dnsService.deleteRecord(implrecordid);
		    				}
		    			}	
			    		Dnsrecords.logicalDelete(dnsrecord, "models.Dnsrecord");
						//dnsrecord._delete();
			    	}
		    	}
				//
		    	server.state = VmState.PENDING.name();
		    	server._save();
		    	
				AsyncJob ajob = new AsyncJob(service, "terminate",
						new F.Action<Map>() {
							public void invoke(Map param) {
								String key = (String)param.get(AsyncJob.session_key);
								Map callresult = (Map)param.get(AsyncJob.result_key);
						    	if(callresult.get(AsyncJob.event_key) != null){
						    		MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
						    	}
						    		 
							}
						});
				ajob.initParams(Scope.Session.current().getId());
				ajob.addInParam("serverId",id);
				ajob.now();
			}
		}
		renderJSON(forwardJson("servers","/servers/list"));
	  }catch(Exception e){
		  e.printStackTrace();
	  }
	}
	/**
	 * 
	 * @param ids the virutalmachine's id of cloudprovider 
	 */
	public static void rebootServer(String ids) {
	  try{
		if(ids!=null&&!"".equals(ids)){
			String[] idarra=ids.split(",");
			for(String id:idarra){
				VirtualMachineService service=VirtualMachineService.createServiceByServerId(id);
				service.reboot(id);
			}
		}
		renderJSON(forwardJson("servers","/servers/list"));
	  }catch(Exception e){
		  e.printStackTrace();
	  }
	}
	public static void preSynchronize(String providerID) {
		render("Servers/syncVM.html");
	}
	public static void synchronize() {
		String providerID=params.get("cloudprovider.id");
		VirtualMachineService service;
		try {
			service = new VirtualMachineService(""+providerID);
			service.synchronizeVMState();
			renderJSON(forwardJson("servers","/servers/list"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void list(int pageNum, String search, String searchFields, String orderField, String order) {
		
		Where where = new Where(params);
		where.add("cloudType", "cloudprovider.type=");
		where.add("serverName", "name like");
		where.addValue("state!=", VmState.TERMINATED.toString());
		
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("created_by_id=",cuser.id);
  	 	}
	
		_list(where);

	}
	public static void  selecCloudType(String cloudtype){
	   try{
			Gson gson=new Gson();
	    	
	    	List<Cloudprovider> result = Cloudprovider.queryProviders(cloudtype);	    	

	    	List list=new ArrayList();
			for(Cloudprovider provider:result){
				provider.cloudproviderDetails=null;
				list.add(provider);
			}
			
			String result2=gson.toJson(list);
			try {
				response.setContentTypeIfNotSet("application/json; charset=UTF-8");
				response.out.write(result2.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
	   }catch(Exception e){
		   e.printStackTrace();
	   }
	}
	public static void  getTemplates(){
		TemplateService service=new TemplateService();
		Gson gson=new Gson();
		Iterable<MachineImage>  result=service.listAllTemplate();
		String result2=gson.toJson(result);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static void  getServer(String serverId){
	  try {		
			VirtualMachineService service=VirtualMachineService.createServiceByServerId(serverId);
			VirtualMachine virtualMachine = null;
			virtualMachine = service.getVirtualMachine(serverId);
			Dnsrecord privateDNS = null;
			Dnsrecord publicDNS = null;
			try{
				privateDNS = Dnsrecord.find("value =?", (virtualMachine.getPrivateIpAddresses()==null?"":virtualMachine.getPrivateIpAddresses()[0])).first();
				publicDNS = Dnsrecord.find("value =?", (virtualMachine.getPublicIpAddresses()==null?"":virtualMachine.getPublicIpAddresses()[0])).first();
			}catch(NullPointerException e){
				e.printStackTrace();
			}
			render("/Servers/overview.html",virtualMachine,privateDNS,publicDNS);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void  createKeyPair(){
	  try{

		//Server server=(Server)Cache.get(Scope.Session.current().getId()+"server");
		String cloudproviderId=params.get("cloud");
		String keypairname=params.get("keypairname");
		ShellKeyService shellKeyService=new ShellKeyService(cloudproviderId);
		SSHKeypair result=shellKeyService.createKeypair(keypairname);
		if(result!=null){
			String apppath = play.Play.applicationPath.getAbsolutePath();
			java.io.File file=new java.io.File (apppath+"/tmp/"+keypairname+System.currentTimeMillis()+".pem");
			java.io.FileOutputStream fos=null;
			try {
				fos=new java.io.FileOutputStream(file);
				fos.write(result.publicKey.getBytes());
			} catch (FileNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				if(fos!=null){
					try {
						fos.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			Gson gson=new Gson();
			Map map=new HashMap();
			result.cloudprovider=null;
			map.put("result", result);
			map.put("html", "<a href='/servers/download?fileName="+file.getName()+"' target='_blank'><font color=\"red\">"+keypairname+"&nbsp;&nbsp;[download]</font></a");
			String result2=gson.toJson(map);
			try {
				response.setContentTypeIfNotSet("Content-Disposition;attachment;filename="+keypairname);
				response.out.write(result2.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			Gson gson=new Gson();
			response.setContentTypeIfNotSet("Content-Disposition;attachment;filename="+keypairname);
			try {
				response.out.write(gson.toJson("fail").getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	  }catch(Exception e){
		  e.printStackTrace();
	  }
	}
	public static void  download(String serverId){
		String fileName=params.get("fileName");
		String apppath = play.Play.applicationPath.getAbsolutePath();
		FileInputStream fis=null;
		try {
			java.io.File file=new java.io.File(apppath+"/tmp/"+fileName);
			fis = new FileInputStream(file);
			byte[] buffer=new byte[fis.available()];
			fis.read(buffer);
	        response.setContentTypeIfNotSet("application/x-msdownload");
	        response.setHeader("Content-Length", ""+file.length());
	        response.setHeader("Content-Disposition","attachment;filename="+fileName);
	        response.out.write(buffer);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(fis!=null){
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	public static void  connectSever(String serverId){
	  try{
		  
		String result="";
		VirtualMachineService service=VirtualMachineService.createServiceByServerId(serverId);
		VirtualMachine virtualMachine = null;
		virtualMachine = service.getVirtualMachine(serverId);
		String publicDnsAddress=virtualMachine.getPublicDnsAddress();
		Server server=Server.findById(Long.parseLong(serverId));
		if(server.sshkeypair!=null&&"AWS".equals(server.cloudprovider.type)){
			result="ssh -i "+server.sshkeypair.name+".pem root@"+publicDnsAddress;
		}else{
			if(virtualMachine.getPublicIpAddresses()!=null&&virtualMachine.getPublicIpAddresses().length>0){
				result="ssh  root@"+virtualMachine.getPublicIpAddresses()[0];
			}
		}
		
		render(result,server,virtualMachine);
		/*Gson gson=new Gson();
		String result2=gson.toJson(result);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}*/
	  }catch(Exception e){
		  e.printStackTrace();
		  //show error message here
	  }
	}
	/**
	 * obtain the monitor information
	 * @param serverId
	 * @throws IOException 
	 */
	public static void  getMonitorInfo(String serverId,String interval) throws IOException{
		if(interval==null||"".equals(interval)){
			interval="1";
		}
		Server server=Server.findById(Long.parseLong(serverId));
		if(server.cloudprovider.type.equals(CloudType.AWS.name())){
			try {
				VirtualMachineService service=VirtualMachineService.createServiceByServerId(serverId);
				Calendar calendar = Calendar.getInstance(TimeZone
						.getTimeZone("UTC"));
				calendar.set(Calendar.MILLISECOND, 0);
				long lInterval=60*60*1000*Long.parseLong(interval);
				long endTimestamp = calendar.getTimeInMillis();
				long startTimestamp= endTimestamp-lInterval;
				Iterable<VmStatistics> statistics=service.getVMStatisticsForPeriod(server.implinstanceId, startTimestamp, endTimestamp);
				TimeSeriesCollection dataset1 = new TimeSeriesCollection();
				TimeSeries series1 = new TimeSeries("cpu", org.jfree.data.time.Minute.class);
				dataset1.addSeries(series1);
				TimeSeriesCollection dataset2 = new TimeSeriesCollection();
				TimeSeries series2 = new TimeSeries("disk read bytes", org.jfree.data.time.Minute.class);
				dataset2.addSeries(series2);
				TimeSeriesCollection dataset3 = new TimeSeriesCollection();
				TimeSeries series3 = new TimeSeries("disk write bytes", org.jfree.data.time.Minute.class);
				dataset3.addSeries(series3);
				TimeSeriesCollection dataset4 = new TimeSeriesCollection();
				TimeSeries series4 = new TimeSeries("maxinum network in", org.jfree.data.time.Minute.class);
				dataset4.addSeries(series4);
				TimeSeriesCollection dataset5 = new TimeSeriesCollection();
				TimeSeries series5 = new TimeSeries("maxinum network out", org.jfree.data.time.Minute.class);
				dataset5.addSeries(series5);
				for(VmStatistics sta:statistics){
					System.out.println(new Date(sta.getStartTimestamp())+":"+sta.getMaximumNetworkIn());
					series1.add(new Minute(new Date(sta.getStartTimestamp())),sta.getAverageCpuUtilization());
					series2.add(new Minute(new Date(sta.getStartTimestamp())),sta.getAverageDiskReadBytes());
					series3.add(new Minute(new Date(sta.getStartTimestamp())),sta.getAverageDiskWriteBytes());
					series4.add(new Minute(new Date(sta.getStartTimestamp())),sta.getMaximumNetworkIn());
					series5.add(new Minute(new Date(sta.getStartTimestamp())),sta.getMaximumNetworkOut());
				}
				String networkout="";
				String networkin="";
				String cpu="";
				String avgdiskwrite="";
				String avgdiskread="";
				TextTitle title=new TextTitle("");
				Font mf = new Font("TimesRoman",Font.BOLD,10);
				title.setFont(mf);
				
				JFreeChart chart = ChartFactory.createTimeSeriesChart("Max Network Out (Bytes)", null,null,
						dataset5, true, true, false);
				title.setText("Max Network Out (Bytes)");
				chart.setTitle(title);
				byte[] buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
				String image=(new sun.misc.BASE64Encoder()).encode(buffer);
				networkout=image;
				
				chart = ChartFactory.createTimeSeriesChart("Max Network In (Bytes)", null,null,
						dataset4, true, true, false);
				title.setText("Max Network In (Bytes)");
				chart.setTitle(title);
				buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
				image=(new sun.misc.BASE64Encoder()).encode(buffer);
				networkin=image;
				
				chart = ChartFactory.createTimeSeriesChart("CPU Utilization(percent)", null,null,
						dataset1, true, true, false);
				title.setText("CPU Utilization(percent)");
				chart.setTitle(title);
				buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
				image=(new sun.misc.BASE64Encoder()).encode(buffer);
				cpu=image;
				
				chart = ChartFactory.createTimeSeriesChart("AVG Disk Writes(Bytes)", null,null,
						dataset3, true, true, false);
				title.setText("AVG Disk Writes(Bytes)");
				chart.setTitle(title);
				buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
				image=(new sun.misc.BASE64Encoder()).encode(buffer);
				avgdiskwrite=image;
				
				chart = ChartFactory.createTimeSeriesChart("AVG Disk Reads(Bytes)", null,null,
						dataset2, true, true, false);
				title.setText("AVG Disk Reads(Bytes)");
				chart.setTitle(title);
				buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
				image=(new sun.misc.BASE64Encoder()).encode(buffer);
				avgdiskread=image;
				render("/Servers/monitoring.html",networkout,networkin,cpu,avgdiskwrite,avgdiskread,interval);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return;
		}else{
			if(server==null){
				return;
			}
			String[] metricIds=null;
			if(server.MetricId!=null){
				metricIds=server.MetricId.split(";");
			}
			Calendar calendar = Calendar.getInstance(TimeZone
					.getTimeZone("UTC"));
			calendar.set(Calendar.MILLISECOND, 0);
			long lInterval=60*60*1000*Long.parseLong(interval);
			long endTime = calendar.getTimeInMillis();
			String networkout="";
			String networkin="";
			String cpu="";
			String avgdiskwrite="";
			String avgdiskread="";
			String apppath = play.Play.applicationPath.getAbsolutePath();
			SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");
			String folderName=sdf.format(new Date());
			String fileName="";
			File file=new File(apppath+"/tmp/"+folderName);
			if(!file.exists()){
				file.mkdir();
			}
			HostService host=new HostService("176.34.30.24",7080,"hqadmin","hqadmin");
			fileName="/tmp/"+folderName+"/cpu"+System.currentTimeMillis()+".csv";
			cpu=host.getMetricData(metricIds[0].split(","), lInterval, endTime);
			FileOutputStream fos=new FileOutputStream(apppath+fileName);
			fos.write(cpu.getBytes());
			fos.close();
			cpu=fileName;
			
			fileName="/tmp/"+folderName+"/avgdiskwrite"+System.currentTimeMillis()+".csv";
			avgdiskwrite=host.getMetricData(metricIds[1].split(","), lInterval, endTime);
			fos=new FileOutputStream(apppath+fileName);
			fos.write(avgdiskwrite.getBytes());
			fos.close();
			avgdiskwrite=fileName;
			
			fileName="/tmp/"+folderName+"/avgdiskread"+System.currentTimeMillis()+".csv";
			avgdiskread=host.getMetricData(metricIds[2].split(","), lInterval, endTime);
			fos=new FileOutputStream(apppath+fileName);
			fos.write(avgdiskread.getBytes());
			fos.close();
			avgdiskread=fileName;
			
			fileName="/tmp/"+folderName+"/networkout"+System.currentTimeMillis()+".csv";
			networkout=host.getMetricData(metricIds[3].split(","), lInterval, endTime);
			fos=new FileOutputStream(apppath+fileName);
			fos.write(networkout.getBytes());
			fos.close();
			networkout=fileName;
			
			fileName="/tmp/"+folderName+"/networkin"+System.currentTimeMillis()+".csv";
			networkin=host.getMetricData(metricIds[4].split(","), lInterval, endTime);
			fos=new FileOutputStream(apppath+fileName);
			fos.write(networkin.getBytes());
			fos.close();
			networkin=fileName;
			
		/*	TextTitle title=new TextTitle("");
			Font mf = new Font("TimesRoman",Font.BOLD,10);
			title.setFont(mf);
			
			
			JFreeChart chart = ChartFactory.createTimeSeriesChart("CPU Utilization(percent)", null,null,
					host.getMetricData(metricIds[0].split(","), lInterval, endTime), true, true, false);
			title.setText("CPU Utilization(percent)");
			chart.setTitle(title);
			byte[] buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
			String image=(new sun.misc.BASE64Encoder()).encode(buffer);
			cpu=image;
			

			chart = ChartFactory.createTimeSeriesChart("AVG Disk Writes(Bytes)", null,null,
					host.getMetricData(metricIds[1].split(","), lInterval, endTime), true, true, false);
			title.setText("AVG Disk Writes(Bytes)");
			chart.setTitle(title);
			buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
			image=(new sun.misc.BASE64Encoder()).encode(buffer);
			avgdiskwrite=image;
			
			chart = ChartFactory.createTimeSeriesChart("AVG Disk Reads(Bytes)", null,null,
					host.getMetricData(metricIds[2].split(","), lInterval, endTime), true, true, false);
			title.setText("AVG Disk Reads(Bytes)");
			chart.setTitle(title);
			buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
			image=(new sun.misc.BASE64Encoder()).encode(buffer);
			avgdiskread=image;
			
			chart = ChartFactory.createTimeSeriesChart("Max Network Out (Bytes)", null,null,
					host.getMetricData(metricIds[3].split(","), lInterval, endTime), true, true, false);
			title.setText("Max Network Out (Bytes)");
			chart.setTitle(title);
			buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
			image=(new sun.misc.BASE64Encoder()).encode(buffer);
			networkout=image;
			
			chart = ChartFactory.createTimeSeriesChart("Max Network In (Bytes)", null,null,
					host.getMetricData(metricIds[4].split(","), lInterval, endTime), true, true, false);
			title.setText("Max Network In (Bytes)");
			chart.setTitle(title);
			buffer=ChartUtilities.encodeAsPNG(chart.createBufferedImage(400, 300));
			image=(new sun.misc.BASE64Encoder()).encode(buffer);
			networkin=image;*/
			render("/Servers/monitoring.html",networkout,networkin,cpu,avgdiskwrite,avgdiskread,interval);
		}
	}
	
	public static void  rdp(String id){
		System.out.println("rdp is running ....");
		System.out.println(id);
		String query ="from IpAddress where server_id =?";
		IpAddress ipAddress = IpAddress.find(query, (long) Integer.parseInt(id)).first();
		
		if(ipAddress != null && ipAddress.publicIpAddress !=null){
			renderArgs.put("ip", ipAddress.publicIpAddress);
		}
		
		render("/Servers/rdp.html");
	}
	public static void vnc(String id){
		System.out.println("vnc is running ...");
		System.out.println(id);
		//String query ="from IpAddress where server_id =?";
		//IpAddress ipAddress = IpAddress.find(query, (long) Integer.parseInt(id)).first();
		
		//if(ipAddress != null && ipAddress.publicIpAddress !=null){
		//	renderArgs.put("ip", ipAddress.publicIpAddress);
		//}
		
                try{
                        VirtualMachineService service = VirtualMachineService.createServiceByServerId(id);
                        VirtualMachine virtualMachine = service.getVirtualMachine(id);
                        String publicIpAddress = virtualMachine.getPublicIpAddresses()[0];

                        System.out.println(publicIpAddress);
                        renderArgs.put("ip", publicIpAddress);

                } catch(Exception e) {
                        e.printStackTrace();
                }
		
		render("/Servers/vnc.html");
	
	}
}
