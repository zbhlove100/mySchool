package controllers;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import jobs.AsyncJob;
import jobs.MessageJob;

import models.Account;
import models.Cloudprovider;
import models.DomainCloudprovider;
import models.Server;
import models.Snapshot;
import models.Template;
import models.spec.CurrentUser;
import models.spec.Message;
import models.spec.Where;

import org.dasein.cloud.compute.MachineImage;
import org.dasein.cloud.compute.VmState;

import play.libs.F;
import play.mvc.Scope;
import play.db.jpa.Model;
import play.exceptions.TemplateNotFoundException;
import play.i18n.Messages;
import service.compute.TemplateService;
import flexjson.JSONSerializer;

public class Templates extends CRUD {
	
	public static void mylist() throws Exception {

		List<Long> cpids = new ArrayList<Long>();
		if(CurrentUser.current().isSuper()){
			renderArgs.put("cps", Cloudprovider.availables());
		}else{
			List<Cloudprovider> cps = new ArrayList<Cloudprovider>();
			for(DomainCloudprovider dcp:  DomainCloudprovider.domainProviders(CurrentUser.current().domainid)){
				cps.add(dcp.cloudprovider);	
				cpids.add(dcp.cloudprovider.id);
			}
			renderArgs.put("cps", cps);
		}
		
		Where where = new Where(params);
		where.in("cloudprovider_id",cpids);
		where.add("cpid","cloudprovider_id=");
		
		if(!CurrentUser.current().isSuper()){
			where.add(String.format("ispublic = true or created_by_id = %d", CurrentUser.current().id));
		}
		_list(where);
	}
	

	public static void syncAlltemplates() {
		
		List<Cloudprovider> allcps = Cloudprovider.availables();
		for(Cloudprovider cp:allcps){
			try{
				TemplateService templateService=new TemplateService(cp.id.toString());
				templateService.synchronizeTemplate();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		renderJSON(forwardJson("templates", "/Templates/list",
				"sync all templates successed !"));
	}	
	
	public static void permissions(String ids){
		ObjectType type = ObjectType.get(getControllerClass());
		notFoundIfNull(type);
		Constructor<?> constructor;
		try {
			constructor = type.entityClass.getDeclaredConstructor();
			constructor.setAccessible(true);
			Model object = (Model) constructor.newInstance();
			Template template = Template.findById((long) Integer.parseInt(ids));
			System.out.println("template.cloudprovider.id ="+template.cloudprovider.id);
			TemplateService templateService = new TemplateService((template.cloudprovider.id).toString());
			//added by liubs
			templateService.setProject(template.created_by);
			List<String> list = templateService.getTemplatShare(template.impltemplateId );
			renderArgs.put("templete",template);
			render("Templates/permissions.html", type, object,template,list);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void changepermissions(Long id){
		try {
			System.out.println("get id count="+id);
			Template template = Template.findById(id);
			
			String publics=params.get("ispublic");
			if("true".equals(publics)){
				TemplateService templateService = new TemplateService((template.cloudprovider.id).toString());

				//added by liubs
				templateService.setProject(template.created_by);

				templateService.makeTemplatePublic(params.get("impltemplateId"));
				template.ispublic = true;
				
			}else{
				TemplateService templateService = new TemplateService((template.cloudprovider.id).toString());

				//added by liubs
				templateService.setProject(template.created_by);

				templateService.makeTemplatePrivate(params.get("impltemplateId"));
				if(params.get("accountNumber")!=null && !"".equals(params.get("accountNumber"))){
					templateService.addTemplateShare(params.get("impltemplateId"),params.get("accountNumber"));
				}
				template.ispublic = false;
			}
			template._save();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	 public static void blank() throws Exception {
		 	ObjectType type = ObjectType.get(getControllerClass());
			notFoundIfNull(type);
			Constructor<?> constructor = type.entityClass.getDeclaredConstructor();
			constructor.setAccessible(true);
			Model object = (Model) constructor.newInstance();
			try {
	            render(type, object);
	        } catch (TemplateNotFoundException e) {
	            render("CRUD/blank.html", type, object);
	        }
	 }
	 
	 public static void getServers() throws Exception{
		 CurrentUser cuser = CurrentUser.current();
		 List<Server> servers =new ArrayList<Server>();
		 if(params.get("providerId")!=null && !"".equals(params.get("providerId"))){
			 servers =Server.find("cloudprovider_id=?", params.get("providerId")).fetch();
		 }else if(cuser.domainid!=null && !"".equals(cuser.domainid)){
			 servers =Server.find("cloudprovider_id=? and domain_id=?", params.get("providerId"),cuser.domainid).fetch();
		 }
		 JSONSerializer jss = new JSONSerializer().include("id","name").exclude("*");
		 
		 //renderJSON(jss.serialize(servers));
		 if(servers.size()>0){
			 response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			 response.out.write(jss.serialize(servers).getBytes());
		 }else{
			 response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			 response.out.write("[{\"id\":0,\"name\":\"no data\"}]".getBytes());
		 }
		 
	 }
	 public static void create() throws Exception {
	    ObjectType type = ObjectType.get(getControllerClass());
        notFoundIfNull(type);
        Constructor<?> constructor = type.entityClass.getDeclaredConstructor();
        constructor.setAccessible(true);
        Model object = (Model) constructor.newInstance();
        CurrentUser cuser = CurrentUser.current();
        Account account = Account.findById(cuser.id);
        Cloudprovider cloudprovider = Cloudprovider.findById(Long.parseLong(params.get("providerId")));
        Server server = Server.findById(Long.parseLong(params.get("servername")));
        
        Template template = new Template();
        template.ispublic =false;
        template.cloudprovider =cloudprovider;
        template.name=params.get("name");

        template.format = "XEN";
        if (server.hypervisorType!=null && !"".equals(server.hypervisorType)) {
        	template.hypervisorType=server.hypervisorType;
		}else{
			template.hypervisorType="XEN";
		}
        
        template.bits = 32;
        template.state = template.PENDING;
        template.created_by=account;
        
        /**
         * commit the data to database when execute save()
         * */
        EntityManager em = template.em();
        template.save();
        em.getTransaction().commit();
        
        String serverId =server.implinstanceId;
        String machineImageName = params.get("name");
        String description = params.get("description");
        
        System.out.println("serverId="+serverId+"machineImageName="+machineImageName+"description="+description);
        if ("".endsWith(machineImageName) || "".endsWith(description))
			renderJSON(jsonMessage("300", "please input or select!"));
		
        TemplateService templateService = new TemplateService(params.get("providerId"));
        AsyncJob ajob = new AsyncJob(templateService, "createTemplate", new F.Action<Map>() {
        	
			public void invoke(Map param) {
				
				Map result = (Map)param.get(AsyncJob.result_key);
				String session_key = (String) param.get(AsyncJob.session_key);
				
				Template template = Template.findById(param.get("templateId"));
				   
				if (result.get(AsyncJob.event_key) != null) {
					MessageJob.publish(session_key,(Message) result.get(AsyncJob.event_key));
					template.delete();
				} else {
			        MachineImage machineImage = (MachineImage)result.get("mi");
			        if(machineImage == null){
			        	MessageJob.publish_error(session_key,"Fail to create template");
			        	template.delete();
			        }else{
				     
				        template.name=machineImage.getName();
		
				        if(machineImage.getPlatform()!=null){
				        	template.platform = machineImage.getPlatform().name();
				        }
				        template.impltemplateId =machineImage.getProviderMachineImageId();
				        template.bits = Template.getBits(machineImage.getArchitecture().toString());
				        template.state = machineImage.getCurrentState().toString();
				        template._save();
				        MessageJob.publish_info(session_key, String.format("Success to create template %s",template.name));
				        System.out.println("finished createTemplate...");
			        }
				}
			}
        	
        });
        
        ajob.initParams(Scope.Session.current().getId());
        
        ajob.addParam("templateId", template.id);
        
		ajob.addInParam("serverId", serverId);
		ajob.addInParam("machineImageName", machineImageName);
		ajob.addInParam("description", description);
		
		ajob.now();
		
		renderJSON(jsonMessage("Your task has submitted to the job server!"));
		
/*        
        MachineImage machineImage = templateService.createTemplate(serverId, machineImageName, description);
        Template template = new Template();
        template.ispublic =false;
        template.cloudprovider =cloudprovider;
        template.name=machineImageName;

        if(machineImage.getPlatform()!=null){
        	template.platform = machineImage.getPlatform().name();
        }
        template.format = "XEN";
        if (server.hypervisorType!=null && !"".equals(server.hypervisorType)) {
        	template.hypervisorType=server.hypervisorType;
		}else{
			template.hypervisorType="XEN";
		}
        template.impltemplateId =machineImage.getProviderMachineImageId();
        template.bits = Template.getBits(machineImage.getArchitecture().toString());
        template.state = machineImage.getCurrentState().toString();
        template.created_by=account;
        template._save();forwardJson
        String typename = type.name.toLowerCase();
		renderJSON(forwardJson(typename,
		String.format("/%s/mylist", typename),
		Messages.get("crud.created", type.modelName)));
*/		
	 }
	 
	 public static void delete(String id) {
	    	
	        ObjectType type = ObjectType.get(getControllerClass());
	        notFoundIfNull(type);
	        Model object = type.findById(id);
	        Template template = Template.findById(id);
	        String providerMachineImageId = template.impltemplateId;
	        try {
				TemplateService templateService = new TemplateService(params.get("providerId"));
				//added by liubs
				templateService.setProject(template.created_by);
				
				templateService.removeTemplate(providerMachineImageId);
			} catch (Exception e) {
				e.printStackTrace();
			}
	        _delete(object);
	 }
	 
	 public static void deletes(String ids) {
	    	
		 ObjectType type = ObjectType.get(getControllerClass());
	     notFoundIfNull(type);
	     
	     String where = String.format("id in (%s)", ids);
		 
		 List<Model> objects = type.find(where);
		 String[] str =ids.split(",");
		 for(int i=0;i<str.length;i++){
			 Template template = Template.findById(Long.parseLong(str[i]));
		        String providerMachineImageId = template.impltemplateId;
		       
		        try {
		        	System.out.println("providerId="+params.get("providerId"));
					TemplateService templateService = new TemplateService(""+template.cloudprovider.id);
					templateService.setProject(template.created_by);
					templateService.removeTemplate(providerMachineImageId);
				} catch (Exception e) {
					e.printStackTrace();
				}
		 }
		 _delete(objects,type);
		     
   }
	 
}