package controllers;

public class EntrytoJson {
	public String name;
	public String value;
}
