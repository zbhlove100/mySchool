package controllers;

import java.io.ByteArrayInputStream;

import models.SSHKeypair;
import models.spec.CurrentUser;
import models.spec.Where;
import controllers.CRUD.For;

@For(SSHKeypair.class)
public class Keypairs extends CRUD{
	
	public static void list() {	

		Where where = new Where(params);
		where.add("search", "name like");
   	 	
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("created_by_id=",cuser.id);
		}
		
		_list(where);
		
    }    
	
	public static void download(Long id){
		SSHKeypair keypair = SSHKeypair.findById(id);
		if(keypair == null || keypair.publicKey == null){
			renderText("The keypair is not found!");
		}else{
			//response.setContentTypeIfNotSet(picture.contentType);
			ByteArrayInputStream bais = new ByteArrayInputStream(keypair.publicKey.getBytes());
			renderBinary(bais, String.format("%s-%s.pem", keypair.name,keypair.created_by.username));
		}
	}
}
