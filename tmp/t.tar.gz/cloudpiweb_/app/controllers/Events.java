package controllers;

import play.modules.cas.annotation.Check;

@Check("root")
public class Events extends CRUD{
    
}
