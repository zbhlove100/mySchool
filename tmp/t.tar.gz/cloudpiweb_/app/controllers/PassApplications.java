package controllers;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import models.Account;
import models.AppAutoScale;
import models.AppEnvironment;
import models.DNS;
import models.Domain;
import models.DomainTarget;
import models.PassApplication;
import models.Project;
import models.ProjectEvent;
import models.Target;
import models.spec.CurrentUser;
import models.spec.Where;
import play.Logger;
import play.data.binding.Binder;
import play.i18n.Messages;
import play.mvc.After;
import play.mvc.Before;
import play.mvc.Scope;
import service.pass.ApplicationService;
import service.pass.ProjectService;
import utils.PassEventWriter;
import utils.ZipUtil;

import com.google.gson.Gson;
import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.CloudApplication;
import com.samsung.cloudpi.client.cf.lib.CloudService;
import com.samsung.cloudpi.client.cf.lib.InstanceStats;
import com.samsung.cloudpi.client.git.GitAccount;

public class PassApplications extends CRUD {

	@After
	static void afterApplication() {

		Long appId = (Long) renderArgs.get("appId");
		
		if (appId != null) {
			PassApplication app = PassApplication.findById(appId);
			session.current().put("appId", appId);
			session.current().put("proId", app.project.id);

		}		
	}

	@After
	static void afterProject() {
		Long proId = (Long) renderArgs.get("proId");
		
		if (proId != null) {
			session.current().put("proId", proId);			
		}

	}

	public static void list(Long proId, Long userId) {

		if (proId == null) {
			proId = Long.valueOf(session.current().get("proId"));

		}

		Project p = Project.findById(proId);

		int pageNum = Integer.parseInt(params.get("pageNum") == null ? "1"
				: params.get("pageNum"));
		List<PassApplication> apps = PassApplication
				.find("byProject.id", proId).fetch(pageNum, getPageSize());

		for (PassApplication app : apps) {
			String status = "ERROR";

			try {
				Account account = Account.findById(app.accountId);
				CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
						account.username, account.passwordBase64,
						app.target.targetUrl);

				status = ApplicationService.getApplicationStatusByAppName(
						proxy, app.name);
			} catch (Exception e) {
				Logger.error(">>>> Getting app:" + app.name + " status has error!!", e);
			}
			app.status = status;
		}

		Long totalCount = PassApplication.count("byProject.id", proId);
		int numPerPage = getPageSize();

		renderArgs.put("proName", p.name);
		renderArgs.put("proId", proId);
		render(apps, totalCount, numPerPage, pageNum, params);

	}

	public static void deletes(String ids) {

		String idArr[] = ids.split(",");
		String event = "";

		try {
			for (int i = 0; i < idArr.length; i++) {
				String deleteInfo[] = idArr[i].split(":");

				Long appId = Long.valueOf(deleteInfo[1]);
				PassApplication app = PassApplication.findById(Long
						.valueOf(appId));

				ApplicationService.deleteApplicationByAppId(app.id);

				event = "Delete appliction: " + app.name + "!";
				PassEventWriter.writeEvent(CurrentUser.current().id,
						app.target.name, app.name, app.project.id,
						ProjectEvent.INFO, event);
			}
		} catch (Exception e) {
			Logger.error(">>>Deleteing PASS Applictions has error!!!", e);
		}
		renderJSON(forwardJson("passapplications", "/passapplications/list",
				Messages.get("crud.deleted", "Application")));

	}

	public static void blank(Long proId) throws Exception {
		Long domainId = CurrentUser.current().domainid;
		Domain domain = Domain.findById(domainId);
		Project project = Project.findById(proId);
		List<DomainTarget> domainTargets = domain.domainTargets;

		// get branchs
		GitAccount gitAccount = ProjectService.getGitAccount(
				CurrentUser.current().name, CurrentUser.current().password,
				ProjectService.getGitServerURL());
		List<String> branchs = ProjectService.getBranchsByProjectName(
				gitAccount, project.name);

		// get tags
		List<String> tags = ProjectService.getTagsByProjectName(gitAccount,
				project.name);

		renderArgs.put("proId", proId);
		render(proId, domainTargets, branchs, tags);
	}

	public static void create(Long proId) throws Exception {

		Project pro = Project.findById(proId);

		String targetName = params.get("targetName");
		Target target = Target.find("byName", targetName).first();
		String appName = params.get("appName");

		PassApplication app = new PassApplication();
		app.name = appName;
		app.instances = Integer.valueOf(params.get("instance"));
		app.project = pro;
		app.url = params.get("userUrl").toLowerCase() + params.get("url");
		String tag = params.get("tag");
		if (tag.contains("latest")) {
			app.tag = "";
		} else {
			app.tag = tag;
		}
		app.branch = params.get("branch");
		app.memory = Integer.valueOf(params.get("mem"));
		app.target = target;
		app.accountId = Long.valueOf(params.get("accountId"));
		app.createdAt = new Date();

		// create and deploy application

		CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
				CurrentUser.current().name, CurrentUser.current().password,
				target.targetUrl);
		ApplicationService.createApplication(proxy, app, pro);

		String event = "Create new appliction: " + appName + "!";
		PassEventWriter.writeEvent(CurrentUser.current().id, targetName,
				appName, proId, ProjectEvent.INFO, event);

		renderArgs.put("proId", proId);
		renderJSON(forwardJson("passapplications", "/passapplications/list",
				Messages.get("crud.created", "Application")));

	}

	public static void edit(String proName) {

	}

	public static void appoverview(Long appId, Long targetId) {
		// tmpAppId = appId;
		// tmpTargetId = targetId;

		PassApplication appDB = PassApplication.findById(appId);
		Project project = appDB.project;

		Account account = Account.findById(appDB.accountId);
		CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
				account.username, account.passwordBase64,
				appDB.target.targetUrl);

		CloudApplication app = ApplicationService.getCFApplicationByAppName(
				proxy, appDB.name);

		renderArgs.put("appId", appDB.id);
		render(project, app);

	}

	public static void sessionset(Long appId, Long targetId) {
		render(appId, targetId);

	}

	public static void urlmaplist(Long appId, Long targetId) {

		if (null == appId) {
			appId = Long.valueOf(session.current().get("appId"));
		}

		List<String> urls = ApplicationService
				.getApplicationMapedURLListByAppId(appId);

		renderArgs.put("appId", appId);
		render(urls, appId, targetId);

	}

	public static void savemapurl(Long appId, Long targetId) {

		ApplicationService.mapURLToApplicationByAppId(appId,
				Arrays.asList(params.getAll("ids")));

		renderArgs.put("appId", appId);

		renderJSON(forwardJson("passapplications", "/passapplications/list"));

	}

	public static void unmapurl(String ids) {

		Long appId = Long.valueOf(session.current().get("appId"));

		ApplicationService.unmapURLToApplicationByAppId(appId,
				Arrays.asList(params.getAll("ids")));

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));
	}

	public static void mapurl(String appInfo) {

		String copyInfo[] = appInfo.split(":");
		Long targetId = Long.valueOf(copyInfo[0]);
		Long appId = Long.valueOf(copyInfo[1]);

		List<DNS> urls = ApplicationService.getAllUsableURLListByAppId(appId,
				CurrentUser.current().id);

		renderArgs.put("appId", appId);
		render(urls, targetId, appId);

	}

	public static void envirsetting(Long appId, Long targetId) {

		List<AppEnvironment> envs = ApplicationService
				.getAllEnviromentListByAppId(appId);

		renderArgs.put("appId", appId);
		render(envs, appId);
	}

	public static void addenvir(String appInfo) {

		String copyInfo[] = appInfo.split(":");
		Long targetId = Long.valueOf(copyInfo[0]);
		Long appId = Long.valueOf(copyInfo[1]);

		renderArgs.put("appId", appId);
		render(targetId, appId);

	}

	public static void deleteenvir(String ids) {
		Long appId = Long.valueOf(session.current().get("appId"));

		ApplicationService.deleteEnviromentsByAppId(appId,
				Arrays.asList(ids.split(",")));

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));

	}

	public static void saveenvir(Long appId, Long targetId) {
		String name = params.get("envname");
		String value = params.get("envvalue");

		ApplicationService.addEnviromentByAppId(appId, name + "=" + value);

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));

	}

	public static void monitor(Long appId, Long targetId, String minute) {

		if (minute.equals("undefined") || minute.equals(""))
			minute = "5";

		List<InstanceStats> monitors = ApplicationService
				.getMonitorInfoListByAppId(appId, minute);

		renderArgs.put("appId", appId);
		render(monitors, minute, appId, targetId);

	}

	public static void graph(String appInfo) {
		String copyInfo[] = appInfo.split(":");
		Long targetId = Long.valueOf(copyInfo[0]);
		Long appId = Long.valueOf(copyInfo[1]);

		String apppath = play.Play.applicationPath.getAbsolutePath();

		String period = params.get("period");
		int mini = 60;
		if (period == null) {
			period = "";
		}
		if (period.equalsIgnoreCase("day")) {
			mini = 1 * 24 * 60;
		} else if (period.equalsIgnoreCase("week")) {
			mini = 7 * 24 * 60;
		} else if (period.equalsIgnoreCase("month")) {
			mini = 30 * 24 * 60;
		} else if (period.equalsIgnoreCase("year")) {
			mini = 365 * 24 * 60;
		} else if (period.equalsIgnoreCase("hour")) {
			mini = 60;
		}

		PassApplication app = PassApplication.findById(appId);
		StringBuffer paasDir = new StringBuffer();
		paasDir.append(apppath).append(File.separator).append("public")
				.append(File.separator).append("paas").append(File.separator);
		String tmpFileName = paasDir.toString() + "tmp" + File.separator
				+ CurrentUser.current().name + "_" + app.name + ".zip";
		try {
			File tmpFile = new File(tmpFileName.toString());
			if (!tmpFile.getParentFile().exists()) {
				tmpFile.getParentFile().mkdir();
				Logger.info(">>> Make dir:" + tmpFile.getParent());
			}
			if (!tmpFile.exists()) {
				tmpFile.createNewFile();
				Logger.info(">>> Create new File:" + tmpFileName);
			}

			// ===============================================

			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					CurrentUser.current().name, CurrentUser.current().password,
					app.target.targetUrl);

			proxy.getApplicationStatsGraph(app.name, String.valueOf(mini),
					"190", "150", tmpFile);
			Logger.info(">>> Get app graph:" + app.name);
			// ==============================================================

			String userFileName = paasDir + CurrentUser.current().name;
			ZipUtil.decompress(tmpFileName, userFileName);
			Logger.info(">>> Unzip file:" + userFileName);

		} catch (Exception e) {
			Logger.error(">>> Getting application graph has error!", e);
		}

		// Logger.info(">>>>>"+zipFile.getAbsolutePath());
		renderArgs.put("username", CurrentUser.current().name);
		renderArgs.put("appname", app.name);
		renderArgs.put("random", Math.random());
		renderArgs.put("appId", appId);

		render(appInfo);

	}

	public static void logs(Long appId, Long targetId) {

		PassApplication app = PassApplication.findById(appId);

		Account account = Account.findById(app.accountId);
		CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
				account.username, account.passwordBase64, app.target.targetUrl);

		List<String> logs = ApplicationService.getLogByAppNameAndInstNum(
				app.name, app.instances, proxy);
		Logger.info(app.name + targetId + ">>>logs size" + logs.toString());

		renderArgs.put("appId", appId);
		render(logs, appId, targetId);
	}

	public static void start(Long appId, Long targetId) {

		try {

			PassApplication appDB = PassApplication.findById(appId);
			Account account = Account.findById(appDB.accountId);
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					appDB.target.targetUrl);

			ApplicationService.startApplicationByAppName(proxy, appDB.name);

			String event = "Start appliction: " + appDB.name + "!";
			PassEventWriter.writeEvent(CurrentUser.current().id,
					appDB.target.name, appDB.name, appDB.project.id,
					ProjectEvent.INFO, event);

		} catch (Exception e) {
			e.printStackTrace();

		}

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));
	}

	public static void stop(Long appId, Long targetId) {

		try {

			PassApplication appDB = PassApplication.findById(appId);

			Account account = Account.findById(appDB.accountId);
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					appDB.target.targetUrl);
			ApplicationService.stopApplicationByAppName(proxy, appDB.name);

			String event = "Stop appliction: " + appDB.name + "!";
			PassEventWriter.writeEvent(CurrentUser.current().id,
					appDB.target.name, appDB.name, appDB.project.id,
					ProjectEvent.INFO, event);
		} catch (Exception e) {
			e.printStackTrace();

		}

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));
	}

	public static void rollback(Long proId, Long appId, Long targetId) {

		// get tags
		Project project = Project.findById(proId);

		GitAccount gitAccount = ProjectService.getGitAccount(
				CurrentUser.current().name, CurrentUser.current().password,
				ProjectService.getGitServerURL());

		List<String> tags = ProjectService.getTagsByProjectName(gitAccount,
				project.name);

		renderArgs.put("appId", appId);
		render(tags, appId, targetId);

	}

	public static void saverollback(Long appId, Long targetId) {
		String tag = params.get("tag");
		try {

			PassApplication appDB = PassApplication.findById(appId);

			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					CurrentUser.current().name, CurrentUser.current().password,
					appDB.target.targetUrl);

			ApplicationService.upgradeApplicationByApp(proxy, appDB, tag);
			String event = appDB.name + " has upgraded to " + tag + " !";
			PassEventWriter.writeEvent(CurrentUser.current().id,
					appDB.target.name, appDB.name, appDB.project.id,
					ProjectEvent.INFO, event);

		} catch (Exception e) {
			e.printStackTrace();

		}

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));

	}

	public static void autoscale(Long appId, Long targetId) {
		PassApplication app = PassApplication.findById(appId);
		AppAutoScale autoScale = new AppAutoScale();
		if (app.autoScale != null) {
			autoScale = app.autoScale; // TODO
		}

		renderArgs.put("appId", appId);
		render(autoScale, appId, targetId);
	}

	public static void saveautoscale(Long appId) {

		PassApplication app = PassApplication.findById(appId);
		AppAutoScale scale = null;

		if (app.autoScale == null) {
			scale = new AppAutoScale();
		} else {
			scale = app.autoScale;
		}

		Binder.bind(scale, "", params.all());
		scale.application = app;
		scale.save();

		renderArgs.put("appId", appId);
		renderJSON(jsonMessage("Success to save!"));

	}

	public static void scale(Long appId, Long targetId) {
		renderArgs.put("appId", appId);
		render(appId, targetId);
	}

	public static void savescale(Long appId, Long targetId) {

		int instance = Integer.valueOf(params.get("instance"));
		try {

			PassApplication app = PassApplication.findById(appId);

			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					CurrentUser.current().name, CurrentUser.current().password,
					app.target.targetUrl);

			ApplicationService.scaleApplicationByApp(proxy, app, instance);

			String event = "Changed " + app.name + "'s instance to " + instance
					+ "!";
			PassEventWriter.writeEvent(CurrentUser.current().id,
					app.target.name, app.name, app.project.id,
					ProjectEvent.INFO, event);

		} catch (Exception e) {
			e.printStackTrace();
		}

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));

	}

	public static void binded(String appInfo) {

		String copyInfo[] = appInfo.split(":");
		Long targetId = Long.valueOf(copyInfo[0]);
		Long appId = Long.valueOf(copyInfo[1]);

		List<CloudService> services = ApplicationService
				.getAllUsableServiceListByAppId(appId);

		renderArgs.put("appId", appId);
		render(services, targetId, appId);
	}

	public static void unbinded(String ids) {

		Long appId = Long.valueOf(session.current().get("appId"));

		ApplicationService.unbindServiceLIstToApplicationByAppId(appId,
				Arrays.asList(ids.split(",")));

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));
	}

	public static void savebinded(Long appId, Long targetId) {

		ApplicationService.bindServiceListToApplicationByAppId(appId,
				Arrays.asList(params.getAll("ids")));

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list"));

	}

	public static void servicelist(Long appId, Long targetId) {
		if (null == appId) {
			appId = Long.valueOf(session.current().get("appId"));
		}

		List services = ApplicationService.getAllBindServiceListByAppId(appId);

		renderArgs.put("appId", appId);
		render(services);

	}

	public static void cloneapp(Long proId, String appInfo) {

		String copyInfo[] = appInfo.split(":");

		Long domainId = CurrentUser.current().domainid;
		Domain domain = Domain.findById(domainId);

		List<DomainTarget> domainTargets = domain.domainTargets;

		renderArgs.put("proId", proId);
		renderArgs.put("targetId", copyInfo[0]);
		renderArgs.put("appId", copyInfo[1]);

		render(domainTargets);

	}

	public static void saveclone() {
		Long appId = Long.valueOf(params.get("appId"));
		String newAppName = params.get("newAppName");
		String newTargetName = params.get("newTargetName");
		ApplicationService.cloneApplication(CurrentUser.current().id, appId,
				newAppName, newTargetName);

		renderArgs.put("appId", appId);
		renderJSON(forwardJson("passapplications", "/passapplications/list",
				Messages.get("crud.created", "Deploy Details")));

	}

	public static void verifyapp(String appName, String targetName) {

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", CurrentUser.current().id);

		PassApplication application = PassApplication.find(where.where(),
				where.paramsarr()).first();
		String result = "true";
		if (application != null) {
			result = "false";
		}
		Gson gson = new Gson();

		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(gson.toJson(result).getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
