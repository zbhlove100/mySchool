package controllers;

import java.util.ArrayList;
import java.util.List;

import models.Cloudprovider;
import models.CloudproviderDetail;
import models.DomainCloudprovider;
import models.spec.CurrentUser;
import models.spec.Where;
import play.Logger;
import play.data.binding.Binder;
import play.db.jpa.Model;
import play.exceptions.TemplateNotFoundException;
import play.i18n.Messages;
import service.compute.DataCenterService;
import service.compute.VirtualMachineService;

public class Cloudproviders extends CRUD {
	public static void index() {
	}

	public static void list() {
		Where where = new Where(params);
		where.add("cloudtype", "type=");
		where.bool("ispublic");
		_list(where);
	}

	public static void create() throws Exception {

		Cloudprovider object = new Cloudprovider();
		String type = params.get("object.type");
		if ("SWIFT".equals(type)) {
			Binder.bind(object, "object", params.all());
			Binder.bind(object.cloudproviderDetails.toArray()[0],
					"object.cloudproviderDetails[0]", params.all());
			object._save();
			for (CloudproviderDetail cpd : object.cloudproviderDetails) {
				cpd.cloudprovider = object;
				cpd._save();
			}
			_create(object);
		} else {
			Binder.bind(object, "object", params.all());
			// List<CloudproviderDetail> cloudproviderDetails = new
			// ArrayList<CloudproviderDetail>();
			Binder.bind(object.cloudproviderDetails.toArray()[0],
					"object.cloudproviderDetails[0]", params.all());
			object._save();
			for (CloudproviderDetail cpd : object.cloudproviderDetails) {
				cpd.cloudprovider = object;
				cpd._save();
			}

			// System.out.println("map:" + object.cloudproviderDetails);
			// System.out.println("map2:" + object.detailshash());
			DataCenterService dcs = new DataCenterService(object);
			dcs.synchronizeDataCenter();
			VirtualMachineService virtualMachineService = new VirtualMachineService(
					"" + object.id);
			//virtualMachineService.createMonitorServer();
			_create(object);
		}
	}

	public static void mylist() {

		List<DomainCloudprovider> dcps = DomainCloudprovider
				.domainProviders(CurrentUser.current().domainid);
		System.out.println("dcps size =" + dcps.size());
		List<String> ids = new ArrayList();
		for (DomainCloudprovider dcp : dcps) {
			ids.add(dcp.cloudprovider.id.toString());
		}

		Where where = new Where(params);
		where.in("id", ids);
		where.bool("ispublic");
		where.add("cloudtype", "type=");
		
		_list(where);

	}

	public static void save(long id) throws Exception {
		Cloudprovider object = Cloudprovider.findById(id);
		notFoundIfNull(object);

		for (int i = 0; i < object.details().size(); i++) {
			CloudproviderDetail cpd = object.cloudproviderDetails.get(i);
			Binder.bind(cpd, "object.cloudproviderDetails[" + i + "]",
					params.all());
			// cpd.cloudprovider = object;
			cpd._save();
		}

		Binder.bind(object, "object", params.all());
		object._save();
		_save(object);
	}

	private static void _save(Model object, ObjectType type) throws Exception {
		validation.valid(object);
		if (validation.hasErrors()) {

			Logger.debug("Validation error: %s is %s",
					validation.errors().get(0).getKey(), validation.errors()
							.get(0));

			if (request.format.equals("json")) {
				renderJSON(jsonError(Messages.get("crud.hasErrors")));
			} else {
				renderArgs.put("error", Messages.get("crud.hasErrors"));
				try {
					render(request.controller.replace(".", "/") + "/show.html",
							type, object);
				} catch (TemplateNotFoundException e) {
					render("CRUD/show.html", type, object);
				}
			}
		}

		object._save();
		if (request.format.equals("json")) {
			String typename = type.name.toLowerCase();
			renderJSON(forwardJson(typename,
					String.format("/%s/list", typename),
					Messages.get("crud.saved", type.modelName)));
		} else {
			flash.success(Messages.get("crud.saved", type.modelName));
			if (params.get("_save") != null) {
				redirect(request.controller + ".list");
			}
			redirect(request.controller + ".show", object._key());
		}
	}

	public static void supported(long id) {
		Cloudprovider cp = Cloudprovider.findById(id);
		notFoundIfNull(cp);
		List features = cp.features();
		render(cp, features);
	}
}
