package controllers;

import models.ScalrSetting;
import play.data.binding.Binder;
import play.i18n.Messages;
import play.modules.cas.annotation.Check;

@Check("root")
public class ScalrSettings extends CRUD{
	
	public static void manager() {
		
		ScalrSetting setting = ScalrSetting.all().first();
		String type = "edit";
		if (null == setting) {
			type = "new";
		}
		
		render(setting, type);

	}

	public static void savescalrsetting() {

		ScalrSetting setting = new ScalrSetting();
		String type = params.get("type");
		String id = params.get("id");

		if (type.equals("new")) {
			Binder.bind(setting, "se", params.all());
		} else {
			setting = ScalrSetting.findById(Long.valueOf(id));
			Binder.bind(setting, "se", params.all());

		}

		validation.valid(setting);
		if (validation.hasErrors()) {
			renderJSON(jsonError(Messages.get("crud.hasErrors")));

		}

		setting.save();
		
		renderJSON(forwardJson("ScalrSetting", "/scalrsetting/manager",
				Messages.get("crud.created", "ScalrSetting")));
		

	}

}
