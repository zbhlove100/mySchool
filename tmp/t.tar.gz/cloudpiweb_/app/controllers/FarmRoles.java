package controllers;

import java.util.LinkedList;
import java.util.List;

import com.samsung.cloudpi.client.scalr.bean.FarmItem;
import com.samsung.cloudpi.client.scalr.bean.FarmsListResponse;
import com.samsung.cloudpi.client.scalr.bean.RoleItem;
import com.samsung.cloudpi.client.scalr.bean.RolesListRequest;
import com.samsung.cloudpi.client.scalr.bean.RolesListResponse;
import com.samsung.cloudpi.client.scalr.bean.ScalrApiWithoutParmsRequest;
import com.samsung.cloudpi.client.scalr.client.RESTClient;

import models.Setting;

public class FarmRoles extends CRUD {
	//private static final String SCALR_KEY_ID = "95294cfe4e7049fe";
	//private static final String SCALR_KEY = "LFMQRC1tdmkBwfaocLT55eiIfD3wFHGmG6ipZim17ufVGnm1DlJJz/ZHvsbG8OErYD8tYxT9NddLqJXIS8pDxkBIwWwrAwS5JnQq+Yh+6IQ2MzWT1J5ZNCFhesXXThFiuG5CR9QVaAAx2l/JeqBuH0N/aDE3JXBcQAOHTTO9oic=";
	//private static final String SCALR_API_URL = "http://scalr.cloudpi.org/api/api.php";
	
	private static final String _SCALR_KEY_ID = "SCALR_KEY_ID";
	private static final String _SCALR_KEY = "SCALR_KEY";
	private static final String _SCALR_API_URL = "SCALR_API_URL";
	
	public static void listFarm(){
		ScalrApiWithoutParmsRequest request = null;
		RESTClient client = null;
		FarmsListResponse response = null;
		List<FarmItem> list = null;
		List<Farm> farms = null;
		
		/**/
		String SCALR_KEY_ID = "";
		String SCALR_KEY = "";
		String SCALR_API_URL = "";
		Setting setting = null;
		
		setting = Setting.find("from Setting where name=?", _SCALR_KEY_ID ).first();
		if(setting!=null)
			SCALR_KEY_ID = setting.value;
		
		setting = Setting.find("from Setting where name=?", _SCALR_KEY ).first();
		if(setting!=null)
			SCALR_KEY = setting.value;
		
		setting = Setting.find("from Setting where name=?", _SCALR_API_URL ).first();
		if(setting!=null)
			SCALR_API_URL = setting.value;
		
		
		request = new ScalrApiWithoutParmsRequest();
		request.setApi_Url(SCALR_API_URL);
		request.setApi_key(SCALR_KEY_ID);
		request.setApi_Secret(SCALR_KEY);
		client = new RESTClient();
		
		
		try {
			response = client.listFarms(request);
			list = response.getFarmSet();
			
			farms = new LinkedList<Farm>();
			for (FarmItem item : list){
				//System.out.println(item.getId()+" - "+item.getName()+" - "+item.getStatus()+ " - "+item.getComments());
				farms.add( new Farm(item.getId(), item.getName(), item.getStatus(), item.getComments() ) );
			}
		} catch (Exception e) {
		}
		
		render(farms);
	}
	
	public static void listRole(){
		RolesListRequest request2 = null;
		RESTClient client = null;
		RolesListResponse response = null;
		List<RoleItem> list = null;
		List<Role> roles = null;
		
		
		/**/
		String SCALR_KEY_ID = "";
		String SCALR_KEY = "";
		String SCALR_API_URL = "";
		Setting setting = null;
		
		setting = Setting.find("from Setting where name=?", _SCALR_KEY_ID ).first();
		if(setting!=null)
			SCALR_KEY_ID = setting.value;
		
		setting = Setting.find("from Setting where name=?", _SCALR_KEY ).first();
		if(setting!=null)
			SCALR_KEY = setting.value;
		
		setting = Setting.find("from Setting where name=?", _SCALR_API_URL ).first();
		if(setting!=null)
			SCALR_API_URL = setting.value;
		
		
		request2 = new RolesListRequest();
		request2.setApi_Url(SCALR_API_URL);
		request2.setApi_key(SCALR_KEY_ID);
		request2.setApi_Secret(SCALR_KEY);		
		
		client = new RESTClient();
		
		try {
			response = client.listRoles(request2);
			list = response.getRoleSet();
			
			roles = new LinkedList<Role>();
			for (RoleItem item : list){				
				//System.out.println(item.getName()+" - "+item.getOwner()+" - "+item.getPlatform()+ " - "+item.getCategory());
				roles.add( new Role(item.getName(), item.getOwner(), item.getCategory(), item.getPlatform(), item.getImageID(), item.getArchitecture(), item.getBuildDate() ) );
			}
		} catch (Exception e) {
		}
		
		render(roles);
	}
	
	public static class Farm{
		public String id;
		public String name;
		public String status;
		public String comments;
		
		public Farm(){}

		public Farm(String id, String name, String status, String comments) {
			super();
			this.id = id;
			this.name = name;
			this.status = status;
			this.comments = comments;
		}		
	}
	
	public static class Role{
		public String name;
		public String owner;
		public String category;
		public String platform;
		public String imageID;
		public String architecture;
		public String buildDate;
		
		public Role(){}

		public Role(String name, String owner, String category,
				String platform, String imageID, String architecture,
				String buildDate) {
			super();
			this.name = name;
			this.owner = owner;
			this.category = category;
			this.platform = platform;
			this.imageID = imageID;
			this.architecture = architecture;
			this.buildDate = buildDate;
		}
		
	}
}
