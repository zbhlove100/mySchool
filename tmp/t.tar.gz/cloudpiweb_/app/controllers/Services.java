package controllers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import models.Account;
import models.Domain;
import models.DomainTarget;
import models.PassApplication;
import models.PassApplicationService;
import models.Service;
import models.SystemService;
import models.Target;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import play.Logger;
import play.i18n.Messages;

import com.google.gson.Gson;
import com.samsung.cloudpi.client.cf.CloudBean;
import com.samsung.cloudpi.client.cf.CloudFoundryException;
import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.CloudService;



public class Services extends CRUD{
	private final static int SHOWALLINDICATOR=-1; 
	
	public static void index(){		
		boolean showDedicatedService = false;
		
		//List<SysService> sys_services= null;  //the system service for the current user
		//List<DedService> ded_services=null;  // the dedicated service the current user has		
		
		String targetName = null;
		String targetId= params.get("targetId");  //sys service search condition
		String accountName = null;
		String accountId = params.get("accountId");
		String domainName = null;
		String domainId = params.get("domainId");
		
		String ss_type=params.get("ss_type");  //system service type
		String ds_type=params.get("ds_type");  //dedicated service type
		//boolean system_request = false;  //if true:  indicate the request comes from system-service tab
		
		
		Account account = null;
		account = Account.findById( CurrentUser.current().id );
		
		//System.out.println("in Services.index(), account info, id:"+account.id+"  name:"+account.username);
		
		//to decide which tabs to show
		if( params.get("showDedicatedService")!=null )
			showDedicatedService=true;
		else if( session.get("showDedicatedService")!=null ){
			showDedicatedService=true;
			session.remove("showDedicatedService");
			
			ds_type = session.get("ds_type");
			session.remove("ds_type");
		}else if( session.get("targetId")!=null ){ //if request comes from createSystemService
			targetId = session.get("targetId");
			session.remove( "targetId" );
		}
		
				
		// for pagination: 
		int pageNum=1; //String s="<option value=\"-1\">All targets</option>";
		String s_pageNum = params.get("pageNum");
		try{
			pageNum=Integer.parseInt(s_pageNum);
		}catch(Exception e){
			pageNum=1;
		} /**/
		
		
		/*
		 * 	if root, no matter which tab to turn, cache all domains.
		 * 	if domain-admin, no matter which tab to turn, cache accounts belonged to the same domain as the domain-admin,
		 * 			and cache all the targets belong to the domain-admin's domain (because all the listed accounts belongs
		 * 			to the same domain, and an account can use all the targets in the domain to which he belongs) .
		 * 	if user, no matter which tab to turn, cache all the targets belong to the user's domain.
		 */
		renderArgs.put("account", account);
		if( "root".equalsIgnoreCase(account.role.name) ){
			List<Domain> domains = null;
			domains = Domain.find("from Domain where state=?", BaseModel.ACTIVE).fetch();
			renderArgs.put("domains", domains);
		}
		if( "domainadmin".equalsIgnoreCase(account.role.name) ){
			List<Accounts> accounts = null;
			accounts = Account.find("from Account where domain=?", account.domain).fetch();
			renderArgs.put("accounts", accounts);
		}		
		if( "user".equalsIgnoreCase(account.role.name) || "domainadmin".equalsIgnoreCase(account.role.name) ){
			List<Target> targets = null;
			targets = new LinkedList<Target>();
			for( DomainTarget dt : account.domain.domainTargets ){
				if( dt.target.state.equals( BaseModel.ACTIVE ) ){
					targets.add( dt.target );				
				}
			}
			renderArgs.put("targets", targets);
		}
		
		
		
		/* for system service: 
		 * 		if root: only list all domains, by selecting domain dynamically change account-list, 
		 * 				by select account dynamically change target-list.
		 * 		if domain-admin: show all account belonged to the same domain as the domain-admin,
		 * 				and all the targets belong to the domain-admin's domain.
		 * 		if user: just show all the targets belong to the user's domain.
		 * 
		 * */		
		if( !showDedicatedService ){
			Target _target = null;
			Account _account = null;
			Domain _domain = null;
			long _targetId = 0;
			long _accountId = 0;
			long _domainId = 0;
			
			try{
				_targetId = Long.parseLong( targetId );
			}catch(Exception e){
				_targetId = SHOWALLINDICATOR;
				if( targetId==null )
					targetId="-1";
			}
			try{
				_accountId = Long.parseLong( accountId );
			}catch(Exception e){
				_accountId = SHOWALLINDICATOR;
			}
			try{
				_domainId = Long.parseLong( domainId );
			}catch(Exception e){
				_domainId = SHOWALLINDICATOR;
			}
			
			_target = Target.findById(_targetId);
			_account = Account.findById(_accountId);
			_domain = Domain.findById(_domainId);
			
			
			if( _target!=null ){
				targetName = _target.name;
			}
			if( _account!=null ){
				accountName = _account.username;
			}
			if( _domain!=null ){
				domainName = _domain.name;
			}
			//Logger.info("********* int Services.index(), targetID:"+targetId+", targetName:"+targetName+",  ss_type:"+ss_type+"  ds_type:"+ds_type);
			renderArgs.put("showDedicatedService",showDedicatedService);
			//renderArgs.put("targets",targets);
			renderArgs.put("targetName",targetName);
			renderArgs.put("targetId",targetId);
			renderArgs.put("accountName",accountName);
			renderArgs.put("accountId", accountId);
			renderArgs.put("domainName", domainName);
			renderArgs.put("domainId", domainId);
			
			renderArgs.put("ss_type",ss_type);	
			
			if(_domain!=null){ //if a domain is specified, then render the domain's accounts and targets
				//Logger.info("^^^^^^^^^^^^^^^");
				List<Accounts> accounts = null;
				accounts = Account.find("from Account where domain=?", _domain).fetch();
				renderArgs.put("accounts", accounts);
				
				List<Target> targets = null;
				targets = new LinkedList<Target>();
				for( DomainTarget dt : _domain.domainTargets ){
					if( dt.target.state.equals( BaseModel.ACTIVE ) ){
						targets.add( dt.target );				
					}
				}
				renderArgs.put("targets", targets);
			}
			
			
			//Logger.info("*********** in Services.index, targetId:"+targetId+", targetName:"+targetName+"" +
			//								", accountId:"+accountId+", accountName:"+accountName+"" +
			//								", domainId:"+domainId+", domainName:"+domainName+", Role:"+account.role.name);
			
			if( "user".equalsIgnoreCase(account.role.name) ){
				
				if( _targetId==SHOWALLINDICATOR )  //target search filed: all
					__list_zwz(SystemService.class, "owned_by_account=?", account); //account: current user
				else   //target search filed: specified a target
					__list_zwz(SystemService.class, "owned_by_account=? and owned_by_target=?", account, _target); 
				
			}else if( "domainadmin".equalsIgnoreCase(account.role.name) ){
				
				if( _accountId==SHOWALLINDICATOR ){  //account search filed: all
					
					if( _targetId==SHOWALLINDICATOR ) //target search filed: all
						__list_zwz(SystemService.class, "owned_by_domain=?", account.domain);
					else  //target search filed: specified a target
						__list_zwz(SystemService.class, "owned_by_domain=? and owned_by_target=?", account.domain, _target);
					
				}else{  //account search filed: specified an account
					
					if( _targetId==SHOWALLINDICATOR ) //target search filed: all
						__list_zwz(SystemService.class, "owned_by_account=?", _account); //account: current user
					else  //target search filed: specified a target
						__list_zwz(SystemService.class, "owned_by_account=? and owned_by_target=?", _account, _target); 
				}
				
			}else if( "root".equalsIgnoreCase(account.role.name) ){
				
				if( _domainId == SHOWALLINDICATOR){ //domain search filed: all
					
					if( _accountId==SHOWALLINDICATOR ){  //account search filed: all
						
						if( _targetId==SHOWALLINDICATOR ) //target search filed: all
							__list_zwz(SystemService.class, "");
						else  //target search filed: specified a target
							__list_zwz(SystemService.class, "owned_by_target=?", _target);
						
					}else{  //account search filed: specified an account
						
						if( _targetId==SHOWALLINDICATOR ) //target search filed: all
							__list_zwz(SystemService.class, "owned_by_account=?", _account); 
						else  //target search filed: specified a target
							__list_zwz(SystemService.class, "owned_by_account=? and owned_by_target=?", _account, _target); 
					}
					
				}else{  //domain search filed: specified a domain
					
					if( _accountId==SHOWALLINDICATOR ){  //account search filed: all
						
						if( _targetId==SHOWALLINDICATOR ) //target search filed: all
							__list_zwz(SystemService.class, "owned_by_domain=?", _domain);
						else  //target search filed: specified a target
							__list_zwz(SystemService.class, "owned_by_domain=? and owned_by_target=?", _domain, _target);
						
					}else{  //account search filed: specified an account
						
						if( _targetId==SHOWALLINDICATOR ) //target search filed: all
							__list_zwz(SystemService.class, "owned_by_domain=? and owned_by_account=?", _domain, _account);
						else  //target search filed: specified a target
							__list_zwz(SystemService.class, 
									"owned_by_domain=? and owned_by_account=? and owned_by_target=?", _domain, _account, _target);
					}

				}
			}
			
		}
		
		/* for dedicated service: */
		if( showDedicatedService ){
			if(ds_type==null)
				ds_type = "dedicate_service_all";
			
			renderArgs.put("showDedicatedService",showDedicatedService);
			renderArgs.put("ds_type", ds_type);
			
			if( ds_type.equalsIgnoreCase("dedicate_service_all") )				
				_list(pageNum, "", "", "", ""," owned_by_id=? or used_by_id=?", account.id ,account.id );
			else
				_list(pageNum, "", "", "", ""," type=? and (owned_by_id=? or used_by_id=?)", ds_type, account.id ,account.id ); //
		}
		
		render();
		//render(showDedicatedService, sys_services,targets, targetName,targetId, ss_type /*,totalCount,numPerPage,pageNum*/ );
	}
	
	//show the page to create a system service
	public static void showCreateSystemService(){
		
		List<Target> targets = null;
		Account account = null;
		String accountName = null;
		account = Account.findById( CurrentUser.current().id );
		accountName = account.username;
		
		targets = new LinkedList<Target>();
		for( DomainTarget dt : account.domain.domainTargets ){
			if( dt.target.state.equals( BaseModel.ACTIVE ) )
				targets.add( dt.target );
		} /**/
		
		render(targets, accountName);
	}
	
	//to create a system service
	public static void createSystemService(){
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		String vendor=params.get("s_vendor");
		String serviceName = params.get("s_serviceName");
		String serviceName_prefix = params.get("hidden_prefix");
		String targetId = params.get("s_targetId");
		Target target = null;
		String tempName = null;
		String version = null;
		String type = null;
		Account account = null;
		Domain domain = null;
		account = Account.findById( CurrentUser.current().id );
		serviceName = serviceName_prefix + serviceName;
		//System.out.println("********* in Services.createService():"+vendor+" "+serviceName+" "+targetId);
		
		if(vendor!=null){
			type = service.pass.SystemService.getServiceTypeByVendor(vendor);
			version = service.pass.SystemService.getServiceVersionByVendor(vendor);
		}
		
		
		target = Target.findById(Long.parseLong(targetId));
		if( SystemService.find("owned_by_account=? and owned_by_target=? and name=?",account, target, serviceName).first()==null ){ //service name must unique, if the name doesn't exist
			if (version != null) {
				try {
					SystemService ss = null;
					
					tempName = account.username + "@samsung.com";
					cloudBean = new CloudBean(tempName, account.passwordBase64,
							target.targetUrl);
					cf = new CloudFoundryProxy(cloudBean);

					CloudService service = new CloudService();
					service.setName(serviceName);
					service.setTier("free");
					service.setType(type);
					service.setVendor(vendor);
					service.setVersion(version);
					cf.createService(service); // call rest api

					ss = new SystemService(serviceName, type, version, "free");
					ss.owned_by_account = account;
					domain = Domain.findById( CurrentUser.current().domainid );
					ss.owned_by_domain = domain;
					ss.owned_by_target = target;
					ss.save();

					session.put("targetId", target.id);

				} catch (Exception e) {
					// System.out.println("###########  in Services.createService, got CloudFoundryException:");
					e.printStackTrace();
					if (request.format.equals("json")) {
						renderJSON( forwardJson_error("Services",
								String.format("/%s/index", "Services"),
								Messages.get("Creatation failed.") ) );
					} else {
						flash.error(Messages.get("Creatation failed."));			

						redirect(request.controller + ".index");
					}
				}
			}
		}
		else{ //if service name exists
			if (request.format.equals("json")) {
				renderJSON( forwardJson_error("Services",
						String.format("/%s/index", "Services"),
						Messages.get("The service name, "+serviceName+", already exists!", "Services") ) );
			} else {
				flash.error(Messages.get("The service name, "+serviceName+", already exists!", "Services"));			

				redirect(request.controller + ".index");
			}
		}	
		
		
		if (request.format.equals("json")) {
			renderJSON(forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get("crud.created", "Services")));
		} else {
			flash.success(Messages.get("crud.created", "Services"));			

			redirect(request.controller + ".index");
		}
		
	}
	
	
	//to delete system services
	public static void deleteService( String targetId ){
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		//Target target = null;
		String []ids = params.getAll("ids");
		String tempName = null;
		Account account = null;
		account = Account.findById( CurrentUser.current().id );
		
		//Logger.info("********* in Services.deleteService, targetId:"+targetId);		
				
		if( ids!=null && ids.length>0 ) {
			try{				
				for(int i=0;i<ids.length;i++){
					SystemService ss = SystemService.findById( Long.parseLong(ids[i]) );
					Target target = ss.owned_by_target;
					tempName = account.username + "@samsung.com";
					//Logger.info("********* in Services.deleteService, service targetId:"+target.id+",  serviceName:"+ss.name );	
					cloudBean = new CloudBean(tempName, account.passwordBase64, target.targetUrl);
					cf = new CloudFoundryProxy(cloudBean);
					
					cf.deleteService( ss.name ); //call rest api to delete
					ss.delete(); //delete in db
					
					//Logger.info("********* in Services.deleteService, test1");
					//SystemService.delete("delete from SystemService where name=? and owned_by_account=? and owned_by_target=?", names[i], account, target );
					//Logger.info("********* in Services.deleteService, test2");
				}
				
				session.put("targetId", targetId);
			}catch (Exception e) {
				// System.out.println("###########  in Services.deleteService, got CloudFoundryException:");
				 e.printStackTrace();
			}
			
		}	
		

		if (request.format.equals("json")) {
			renderJSON(forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get("Service deleted", "Services")));
		} else {
			flash.success(Messages.get("Service deleted", "Services"));			

			redirect(request.controller + ".index");
		}
	}
	
	
	//to show the dialog page to export a url in the dedicated-service page
	public static void showExportURL(String s_id){
		String url = null;  //dynamic generated url to be exported
		String serviceName = null;  //dedicated service name got from the page
		//String urlSuffix=null;
		Service ser = null;
		long id = -1;
		double suffix = 0.0;
				
		try{
			id = Long.parseLong(s_id);
		}catch(Exception e){
			id=0;
		}
		
		ser = Service.findById(id);
		
		if(ser!=null){
			serviceName = ser.name;
			url = "http://"+request.host+"/services/analyzeMe/";
			suffix = id/1000.0;
			suffix *=25;
			url+=String.valueOf(suffix);
		}
		
		//serviceName = params.get("s_name");
		//System.out.println("********* in Services.showExportURL, s_id:"+s_id);
		
		render(url,serviceName);
	}
	/* 
	 * to display the connection info of the service specified by the key.
	 * need to write in routes: 
	 * 	"*		/services/analyzeMe/{s_key}						Services.showAnalyzedExportedURL"
	 */
	public static void showAnalyzedExportedURL(String s_key){
		Service s = null;
		long id = 0;
		double d_id =0.0;
		boolean malURL = false;
		String desc = "test_desc";
		
		
		try{
			d_id = Double.parseDouble(s_key);
			d_id /= 25;
			d_id *= 1000;
		}catch(Exception e){
			malURL = true;
			render(malURL);
		}
				
		id = (long)d_id;
		//System.out.println("*********** in Services.showAnalyzedExportedURL, get the key:"+s_key+"  d_id:"+d_id+"  id:"+id);
		s = Service.findById(id);
		
		if(s==null){  //not found
			malURL = true;
			render(malURL);
		}
		
		desc = s.bak;
		render(desc);
	}
	
	
	
	//to show the dialog page to import a url in the dedicated-service page
	public static void showImportURL(){
		render();
	}
	
	/*
	 * to process the import url request.
	 * function: insert a new service record into db, the new service info is the same as the url
	 * 		specified except the user-id changed
	 */
	public static void importURL(){		
		Service s = null;   //the service to be exported(to be used by another user)
		String url = null;
		long id = 0;
		double d_id=0.0;		
		String message = null;
		Account account = null;
		account = Account.findById( CurrentUser.current().id );
		
		
		url = params.get("url");
		
		//System.out.println("***in Services.importURL, url:"+url );
		session.put("showDedicatedService", true);		
		try{
			//get the service from the input url
			d_id = Double.parseDouble( url.substring( url.lastIndexOf("/")+1 ) ); 
			d_id /= 25;
			d_id *= 1000;
			//System.out.println("###in Services.importURL, url:"+url+"   got id:"+d_id);
			id = (long)d_id;
			s = Service.findById(id);
			
			if(s==null){  //not found
				//malURL = true;
				message = "Invalid url";
				throw new Exception();
			}/**/
		}catch(Exception e){
			
			if (request.format.equals("json")) {
				renderJSON( forwardJson_error("Services",
						String.format("/%s/index", "Services"),
						Messages.get("Invalid url", "Services")) );
				
			} else {
				//flash.success(Messages.get("crud.created", "Services"));			
				flash.error("Invalid url");
				redirect(request.controller + ".index");
			}
		}
		
		
		session.put("ds_type", s.type);
		/*
		 * if the current user export a url and import the url by himself, then do nothing
		 */
		if( s.owned_by.id != account.id ){
			
			Service ns = new Service();
			ns.bak = s.bak;
			ns.name = s.name;
			ns.registered = 0;
			ns.type = s.type;
			ns.owned_by = s.owned_by;  //owner doesn't change
			ns.used_by = account;      //user is the current account
			ns.version = s.version;
			ns.save();
			message = "Service imported.";
		}else{
			message = "You cannot import your own service.";
			//System.out.println("###### in Services.importURL, exporter and importer cannot be the same one!");
		}
		
		if (request.format.equals("json")) {
			renderJSON( forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get(message, "Services")) );
			
		} else {
			flash.success(message);			

			redirect(request.controller + ".index");
		}
		
	}
	
	
	//Register selected dedicated services to all the current user's targets
	public static void registerService(){
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		String tempName = null;
		String []ids = params.getAll("ids");
		String in_clause = null;
		List<Service> sl = null;
		Iterator si = null;
		String ds_type = null;  //dedicated service type, for index() use
		Account account = null;
		account = Account.findById( CurrentUser.current().id );
		
		//System.out.println("in Services.registerService, ids:");
		tempName = account.username + "@samsung.com";
		in_clause = "(";
		if( ids!=null&&ids.length>0) {
			for(int i=0;i<ids.length;i++){
				//System.out.println( ids[i] );
			
				in_clause+=ids[i];
				if( i<(ids.length-1) )
					in_clause += ",";
			}
		}
		in_clause += ")";
		//System.out.println("######### in Services.registerService, in_clause:"+in_clause);
		sl = Service.find("from Service where id in "+in_clause).fetch();
		//System.out.println("######### in Services.registerService, service list:"+sl);
		si = sl.iterator();
		
		
		while(si.hasNext() ){  
			Service st = (Service)si.next();
			String url = null;
			double suffix = 0.0;
			
			//change db service's registered-indicator.			 
			ds_type = st.type;
			if( st.registered==1 )
				continue;
			st.registered = 1;
			st.save(); 
			
			// for every target which belongs to the current-user's domain, call rest-api to register the selected service			
			for (DomainTarget dt : account.domain.domainTargets) {
				if (dt.target.state.equals(BaseModel.ACTIVE)) {
					try {
						cloudBean = new CloudBean(tempName, account.passwordBase64,
								dt.target.targetUrl);
						cf = new CloudFoundryProxy(cloudBean);
						cf.registerDedicatedService(st.bak);
					} catch (Exception e) {
						Logger.info("###########  in Services.registerService, got Exception when register service:");
						e.printStackTrace();
					}
				}
			} //end for
		} //end while
		
		session.put("showDedicatedService", true);
		session.put("ds_type", ds_type);
		if (request.format.equals("json")) {
			renderJSON(forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get("Service registered", "Services")));
		} else {
			flash.success(Messages.get("Service registered", "Services"));			

			redirect(request.controller + ".index");
		}
	}
	
	/* 
	 * to show the dialog page to bind service, in the dedicated-service page.
	 * Note: this function is removed from the dedicated-service page.
	 */
	public static void showBindService(){
		int pageNum=1;
		String s_pageNum = params.get("pageNum");
		try{
			pageNum=Integer.parseInt(s_pageNum);
		}catch(Exception e){
			pageNum=1;
		}
		
		renderArgs.put("showDedicatedService",true);
		_list(pageNum, "", "", "name", "asc","");
		
		
	}	
	/*
	 * to process the requst to bind services in the dedicated service page.
	 * Note: this function is removed from the dedicated-service page
	 */
	public static void bindService(){
		String []ids = params.getAll("ids");
		
		if(ids!=null ){
			Logger.info("*********** in Services.bindService, ids:");
			for(int i=0;i<ids.length;i++)
				Logger.info( ids[i] );
		}
		
		
		session.put("showDedicatedService", true);  //to show the dedicated service tab
		//renderArgs.put("showDedicatedService",true);
		if (request.format.equals("json")) {
			renderJSON( forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get("crud.created", "Services")) );
			
		} else {
			flash.success(Messages.get("crud.created", "Services"));			

			redirect(request.controller + ".index");
		}
	}
	
	public static void selectAccounts(String domainId){
		//System.out.println("********* in Services.selectAccounts, got domainId:"+domainId);
		List<Account> accounts = null;
		List<Account> t_accounts = null;
		Domain domain = null;
		long _domainId = -1000;
		Gson gson=new Gson();
		
		try{
			_domainId = Long.parseLong(domainId);
		}catch(Exception e){
			_domainId=-1000;
			e.printStackTrace();
		}
		domain = Domain.findById(_domainId);		
		
		if(domain!=null ){  //|| _domainId==SHOWALLINDICATOR
			//if(_domainId==SHOWALLINDICATOR)
			//	accounts = Account.find("from Account where state=?", BaseModel.ACTIVE ).fetch() ;
			//else
				accounts = Account.find("from Account where domain=? and state=?", domain, BaseModel.ACTIVE ).fetch() ;
			
			t_accounts = new ArrayList<Account>();			
			if(accounts!=null)
				for(Account acc : accounts)
					t_accounts.add( new Account(acc.id, acc.username) );
			
			String result=gson.toJson( t_accounts );
			
			try{
				response.setContentTypeIfNotSet("application/json; charset=UTF-8");
				response.out.write(result.getBytes());
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
	}
	
	public static void selectTargets(String domainId){
		//System.out.println("********* in Services.selectTargets, got domainId:"+domainId);
		List<Target> targets = null;
		List<Target> t_targets = null;
		Domain domain = null;
		long _domainId = -1000;
		Gson gson=new Gson();
		
		try{
			_domainId = Long.parseLong(domainId);
		}catch(Exception e){
			_domainId=-1000;
			e.printStackTrace();
		}
		domain = Domain.findById(_domainId);
		
		
		if(domain!=null ){  //|| _domainId==SHOWALLINDICATOR
			//if(_domainId==SHOWALLINDICATOR){
				targets = Target.find("from Target where state=?", BaseModel.ACTIVE).fetch();
			//}else{
				targets = new ArrayList<Target>();
				for (DomainTarget dt : domain.domainTargets) {
					if (dt.target.state.equals(BaseModel.ACTIVE)) {
						targets.add( dt.target );
					}
				}
			//}
			
			t_targets = new ArrayList<Target>();
			for(Target tar : targets)
				t_targets.add( new Target(tar.id, tar.name) );
			
			String result=gson.toJson( t_targets );
			
			try{
				response.setContentTypeIfNotSet("application/json; charset=UTF-8");
				response.out.write(result.getBytes());
			}catch(Exception e){
				e.printStackTrace();
			}			
		}
		 
	}
	
	public static void showCreateDedicatedService(){
		
		render();
	}
	
	public static void createDedicatedService(){
		//String data = null;		
		//data = params.get("data");
		
		//System.out.println("****************** in Services.createDedicatedService, data:"+data);
		
		session.put("showDedicatedService", true);	
		
		if (request.format.equals("json")) {
			renderJSON( forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get("Service created")) );
			
		} else {
			flash.success("Service created");			

			redirect(request.controller + ".index");
		}
	}
	
	public static void showSystemServiceBindedApps(long sid){
		SystemService service = null;
		List<PassApplication> apps = null;
		List<PassApplicationService> app_services = null;
		//System.out.println("############# in Services.showBindedApps, serviceId:"+sid);
		
		service = SystemService.findById(sid);
		
		
		/*int pageNum = 1;
		String s_pageNum = params.get("pageNum");
		try{
			pageNum=Integer.parseInt(s_pageNum);
		}catch(Exception e){
			pageNum=1;
		}
		renderArgs.put("service", service);
		__list_zwz(PassApplication.class, "services in (from PassApplicationService where serviceName=?)", service.name);
		*/
		
		 
		if( service!=null ){
			apps = new ArrayList<PassApplication>();
			app_services = PassApplicationService.find("from PassApplicationService where serviceName=?", service.name ).fetch();
			
			for(PassApplicationService pas : app_services){
				apps.add( pas.application );
			}
		}
		
		render(service,apps); 
	}
	
	public static void showDedicateServiceBindedApps(long sid){
		Service service = null;
		List<PassApplication> apps = null;
		List<PassApplicationService> app_services = null;
		//System.out.println("############# in Services.showBindedApps, serviceId:"+sid);
		
		service = Service.findById(sid);
		
		if( service!=null ){
			apps = new ArrayList<PassApplication>();
			app_services = PassApplicationService.find("from PassApplicationService where serviceName=?", service.name ).fetch();
			
			for(PassApplicationService pas : app_services){
				apps.add( pas.application );
			}
			
		}
		
		render(service,apps);	
	}
	
	public static void deleteDedicatedService(long sid){
		Account account = null;
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		String tempName = null;
		String []ids = params.getAll("ids");
		String in_clause = "";
		List<Service> sl = null;
		
		account = Account.findById( CurrentUser.current().id );		
		tempName = account.username + "@samsung.com";
		
		in_clause = "(";
		if( ids!=null&&ids.length>0) {
			for(int i=0;i<ids.length;i++){
				in_clause+=ids[i];
				if( i<(ids.length-1) )
					in_clause += ",";
			}
		}
		in_clause += ")";
		sl = Service.find("from Service where id in "+in_clause).fetch();
		
		for(Service service : sl){
			if( service.registered==1 ){
				for (DomainTarget dt : account.domain.domainTargets) { //delete service in all registered target
					if (dt.target.state.equals(BaseModel.ACTIVE)) {
						try {
							cloudBean = new CloudBean(tempName, account.passwordBase64,	dt.target.targetUrl);
							cf = new CloudFoundryProxy(cloudBean);
							cf.deleteService( service.name );
						} catch (Exception e) {
							Logger.info("###########  in Services.deleteDedicatedService, got Exception:");
							e.printStackTrace();
						}
					}
				} //end for
			}
			service.delete();
		}		
		
		session.put("ds_type", "dedicate_service_all" );
		session.put("showDedicatedService", true);	
		
				
		if (request.format.equals("json")) {
			renderJSON( forwardJson("Services",
					String.format("/%s/index", "Services"),
					Messages.get("Service deleted")) );
			
		} else {
			flash.success("Service deleted");
			redirect(request.controller + ".index");
		}
	}
	
	
	
	/*
	private static List<Target> tl;
	static{
		tl = new LinkedList<Target>();
		Target t1 = new Target(1);
		t1.name="t1";
		Target t2 = new Target(2);
		t2.name="t2";
		Target t3 = new Target(3);
		t3.name="t3";
		Target t4 = new Target(4);
		t4.name="t4";
		tl.add(t1);
		tl.add(t2);
		tl.add(t3);
		tl.add(t4);
	}
	private static List<Target> getTargets(){		
		return Target.findAll();
	}*/
	public static class SysService{ //system service
		public String name;
		public String tier;
		public String type;
		public String vendor;
		public String version;
		public String service_type;
		
		public SysService(){}

		public SysService(String name, String tier, String type, String vendor,
				String version, String service_type) {
			super();
			this.name = name;
			this.tier = tier;
			this.type = type;
			this.vendor = vendor;
			this.version = version;
			this.service_type = service_type;
		}		
	}
	
	private static List<SysService> getSysServices(Account account,String url){
		
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		String tempName = null;
		Target t = null;
		String targetUrl = url;
		List<CloudService> cloudServices = null;		
		List<SysService> sysServices = null;
		
		tempName = account.username+"@samsung.com";
		//System.out.println("###########  in Services.getSysServices, name:"+tempName+",  url:"+url);
		cloudBean = new CloudBean(tempName,account.passwordBase64,targetUrl);
		try {
			cf = new CloudFoundryProxy(cloudBean);
		} catch (CloudFoundryException e) {
			//System.out.println("###########  in Services.getSysServices, got CloudFoundryException:");
			//e.printStackTrace();
		}
		
		sysServices = new ArrayList<SysService>();
		try{
			cloudServices = cf.getServices(); 
		}catch(Exception e){
			Logger.info("###########  in Services.getSysServices, got Exception.");
			e.printStackTrace();
			return sysServices;
		}
		
		for(CloudService cs : cloudServices){
			if( "system".equalsIgnoreCase( cs.getService_type() ) )
				sysServices.add( new SysService(cs.getName(), cs.getTier(), cs.getType(), cs.getVendor(),
					cs.getVersion(), cs.getService_type()) );
		}
		
		Logger.info("###########  in Services.getSysServices, got services:"+sysServices);
		return sysServices; /**/
		
	}
	
	public static class DedService{ //dedicated service
		public long id;
		public String name;
		public String type;
		public String version;
		public long ownerId;
		public String ownerName;
		public DedService(){}
		public DedService(long id, String name, String type, String version,
				long ownerId, String ownerName) {
			super();
			this.id = id;
			this.name = name;
			this.type = type;
			this.version = version;
			this.ownerId = ownerId;
			this.ownerName = ownerName;
		}		
	}
	private static List<DedService> dsl = null;
	static{
		dsl = new LinkedList<DedService>();
		DedService d1 = new DedService(1,"s1","mysql","1.1",1,"zwz");
		DedService d2 = new DedService(2,"s2","mysql","1.1",1,"zwz");
		DedService d3 = new DedService(3,"s3","mysql","1.1",2,"mycoy");
		DedService d4 = new DedService(4,"s4","mysql","1.1",2,"mycoy");
		dsl.add(d1);
		dsl.add(d2);
		dsl.add(d3);
		dsl.add(d4);
	}
	private static List<DedService> getDedServices(String type){
		return dsl;
	}
	
}


