package controllers;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.LinkedList;

import javax.persistence.Column;

import models.DomainTarget;
import models.Account;
import models.DNS;
import models.DNSTarget;
import models.Setting;
import models.Target;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import play.Logger;
import play.data.validation.MaxSize;
import play.i18n.Messages;
import service.pass.DNSService;

import com.samsung.cloudpi.client.dns.DnsService;

public class DNSs  extends CRUD{
	public static final String _DNS_PUBLIC_DOMAIN_NAME_POSTFIX = "DNS_PUBLIC_DOMAIN_NAME_POSTFIX";
	//public static final String _DNS_API_ADDRESS = "DNS_API_ADDRESS";
	//public static final String _DNS_ZONE_ID = "DNS_ZONE_ID";
	
	public static void index(){
		
		int pageNum=1;
		String s_pageNum = params.get("pageNum");
		try{
			pageNum=Integer.parseInt(s_pageNum);
		}catch(Exception e){
			pageNum=1;
		}
		
		Account account = null;
		account = Account.findById( CurrentUser.current().id );
		
		_list(pageNum, "", "", "", ""," userID=? " , account.id);
		
		render();
	}
	
	public static void showCreateDNS(){
		Account account = null;
		account = Account.findById( CurrentUser.current().id );
		List<Setting> views = null;
		List<Target> targets = null;
		
		targets = new LinkedList<Target>();		
		for(DomainTarget dt : account.domain.domainTargets){
			if( dt.target.state.equals( BaseModel.ACTIVE ) ){
				targets.add( dt.target );				
			}
		}
		views = Setting.find(" name=?" , "view").fetch();
		
		render(targets, views);
	}
	
	public static void createDNS(){
		//DnsService  dnsService = null; 
		String t_ids[] = null;  //target ids
		String name = null; //dns name
		String desc = null; //dns desc
		DNS dns = null;
		Account account = null;
		
		
		String DNS_PUBLIC_DOMAIN_NAME_POSTFIX = "";
		//String DNS_API_ADDRESS = "";
		//String DNS_ZONE_ID = "";
		Setting setting = null;
		
		setting = Setting.find("from Setting where name=?", _DNS_PUBLIC_DOMAIN_NAME_POSTFIX ).first();
		if(setting!=null)
			DNS_PUBLIC_DOMAIN_NAME_POSTFIX = setting.value;
		
		//setting = Setting.find("from Setting where name=?", _DNS_API_ADDRESS ).first();
		//if(setting!=null)
		//	DNS_API_ADDRESS = setting.value;
		
		//setting = Setting.find("from Setting where name=?", _DNS_ZONE_ID ).first();
		//if(setting!=null)
		//	DNS_ZONE_ID = setting.value;
		
		
		account = Account.findById( CurrentUser.current().id );
		
		name = params.get("name");
		desc = params.get("desc");
		t_ids = params.getAll("ids");
		/* System.out.println("in DNSs.createDNS, target ids selected:");
		for(int i=0;i<t_ids.length;i++)
			System.out.println( t_ids[i] );  */
		
		if( DNS.find("from DNS where name=?", name+ DNS_PUBLIC_DOMAIN_NAME_POSTFIX ).first()==null ){
			dns = new DNS();
			dns.userID = account.id;
			dns.name = name + DNS_PUBLIC_DOMAIN_NAME_POSTFIX;
			dns.bak = desc;
			dns.createdOn = getLocalDate();

			if (t_ids != null && t_ids.length != 0) {
				//dnsService = new DnsService( DNS_API_ADDRESS );
				
				for (int i = 0; i < t_ids.length; i++) {
					Target t = Target.findById(new Long(t_ids[i]));
					String []viewNames = null;
					String viewNameString = "";
					String recordIDList = "";
					if( t!=null ){
						//Map<String, String> result = dnsService.createRecord(DNS_ZONE_ID, "A", name, t.routeip, "cloudpi");
						//long recordId = 0;
						viewNames = params.getAll(t.id+"_viewnames");
						
						if (viewNames!=null && viewNames.length>0){
							for(int j=0;j<viewNames.length;j++){
								viewNameString += viewNames[j] + ";";
								recordIDList += DNSService.createARecordInOneView(name+".apps", t.routeip,viewNames[j]) + ";";								
							}
						}
						
						dns.dnsTargets.add( new DNSTarget(t.name, t.targetUrl,
								t.routeip, "", t.createdAt, recordIDList, viewNameString ) );
															
					}
				}
			}
			dns.save();			
		}else{
			if (request.format.equals("json")) {
				renderJSON(forwardJson_error("DNSs",
						String.format("/%s/index", "DNSs"),
						Messages.get("The name, "+ name+DNS_PUBLIC_DOMAIN_NAME_POSTFIX + ", already exists!", "DNSs") )) ;
			} else {
				flash.error(Messages.get("The name, "+ name+DNS_PUBLIC_DOMAIN_NAME_POSTFIX +", already exists!", "DNSs"));			

				redirect(request.controller + ".index");
			}
		}
		

		if (request.format.equals("json")) {
			renderJSON(forwardJson("DNSs",
					String.format("/%s/index", "DNSs"),
					Messages.get("crud.created", "DNSs")));
		} else {
			flash.success(Messages.get("crud.created", "DNSs"));			

			redirect(request.controller + ".index");
		}
	}
	
	/*
	 * show a certain DNS's DNSTargets detailed info in the sub-tab
	 */
	public static void dnsTargetDetail(String dnsId){
		long id = 0;
		DNS dns = null;
		List<DNSTarget> dnstargets = null;
		
		//System.out.println("in DNSs.dnsDetail, dnsId:"+dnsId);
		
		try{
			id = Long.parseLong(dnsId);
		}catch(Exception e){
			render();
		}
		dns = DNS.findById( id );
		dnstargets = dns.dnsTargets;
		
		render(dns, dnstargets);
		
	}
	
	public static void deleteDNS(){
		//DnsService  dnsService = null; 
		String []ids = null;
		long id = 0;
		DNS dns = null;
		//Setting setting = null;
		//String DNS_API_ADDRESS = "";
		
		//setting = Setting.find("from Setting where name=?", _DNS_API_ADDRESS ).first();
		//if(setting!=null)
		//	DNS_API_ADDRESS = setting.value;
		
		ids = params.getAll("ids");
		
		if( ids!=null && ids.length>0 ){
			//dnsService = new DnsService( DNS_API_ADDRESS );
			
			for (int i = 0; i < ids.length; i++) {
				id = 0;
				try { //parse id
					id = Long.parseLong(ids[i]);
					dns = DNS.findById( id );
					if(dns!=null) {
						for(DNSTarget dt : dns.dnsTargets){  //delete dns-zone-record by calling restAPI
							String viewRecords = dt.recordIds;
							DNSService.deleteRecords( viewRecords );
						}	
						
						dns.delete();
					}
				} catch (Exception e) {
					id = 0;
				}				
			}
		}
		
		if (request.format.equals("json")) {
			renderJSON(forwardJson("DNSs",
					String.format("/%s/index", "DNSs"),
					Messages.get("DNS deleted", "DNSs")));
		} else {
			flash.success(Messages.get("DNS deleted.", "DNSs"));			

			redirect(request.controller + ".index");
		}
	}
	
	public static void editDNS(){
		String t_ids[] = null;  //target ids
		String name = null; //dns name
		String desc = null; //dns desc
		DNS dnsToDel = null;
		DNS dnsToCreate = null;
		String dnsId = null;
		Account account = null;
		
		String DNS_PUBLIC_DOMAIN_NAME_POSTFIX = "";
		Setting setting = null;
		
		setting = Setting.find("from Setting where name=?", _DNS_PUBLIC_DOMAIN_NAME_POSTFIX ).first();
		if(setting!=null)
			DNS_PUBLIC_DOMAIN_NAME_POSTFIX = setting.value;
		
		
		account = Account.findById( CurrentUser.current().id );
		
		name = params.get("name");
		desc = params.get("desc");
		dnsId = params.get("dnsId");
		t_ids = params.getAll("ids");
		
		dnsToDel = DNS.findById( Long.parseLong(dnsId) );
		
		
		//delete original dns related info
		dnsToCreate = new DNS();
		if(dnsToDel!=null) {
			for(DNSTarget dt : dnsToDel.dnsTargets){  //delete dns-zone-record by calling restAPI
				String viewRecords = dt.recordIds;
				DNSService.deleteRecords( viewRecords );
			}	
			
			dnsToCreate.createdOn = dnsToDel.createdOn;
			dnsToDel.delete();
		}
		
		
		//create new
		dnsToCreate.userID = account.id;
		dnsToCreate.name = name + DNS_PUBLIC_DOMAIN_NAME_POSTFIX;
		dnsToCreate.bak = desc;
		if (t_ids != null && t_ids.length != 0) {
			for (int i = 0; i < t_ids.length; i++) {
				Target t = Target.findById(new Long(t_ids[i]));
				String []viewNames = null;
				String viewNameString = "";
				String recordIDList = "";
				if( t!=null ){
					viewNames = params.getAll(t.id+"_viewnames");
					
					if (viewNames!=null && viewNames.length>0){
						for(int j=0;j<viewNames.length;j++){
							viewNameString += viewNames[j] + ";";
							recordIDList += DNSService.createARecordInOneView(name+".apps", t.routeip,viewNames[j]) + ";";								
						}
					}
					
					dnsToCreate.dnsTargets.add( new DNSTarget(t.name, t.targetUrl,
							t.routeip, "", t.createdAt, recordIDList, viewNameString ) );
														
				}
			}
		}
		dnsToCreate.save();
		
		if (request.format.equals("json")) {
			renderJSON(forwardJson("DNSs",
					String.format("/%s/index", "DNSs"),
					Messages.get("DNS edited", "DNSs")));
		} else {
			flash.success(Messages.get("DNS edited.", "DNSs"));			

			redirect(request.controller + ".index");
		}
	}
	
	public static void showEditDNS(long id){
		DNS dns = null;
		String dnsName_prefix = null;
		Account account = null;
		List<Target> targets = null;
		List<DNSTargetForEdit> dnsTargetsForEdit = null;
		List<Setting> views = null;
		
		//Logger.info("########## in DNSs.showEditDNS, got dns id:"+id);
		
		dns = DNS.findById(id);
		
		if( dns!=null ){
			views = Setting.find(" name=?" , "view").fetch();
			dnsName_prefix = dns.name.substring(0, dns.name.indexOf("."));
			account = Account.findById(CurrentUser.current().id);

			targets = new LinkedList<Target>();
			for (DomainTarget dt : account.domain.domainTargets) {
				if (dt.target.state.equals(BaseModel.ACTIVE)) {
					targets.add(dt.target);
				}
			}

			dnsTargetsForEdit = composeDNSTargetForEdit(targets, dns.dnsTargets);
			render(dns, dnsTargetsForEdit, dnsName_prefix,views);
		}
		
	}
	
	private static Date getLocalDate(){
		return Calendar.getInstance(TimeZone.getDefault(), Locale.CHINA).getTime();
	}
	
	private static List<DNSTargetForEdit> composeDNSTargetForEdit(List<Target> targets, List<DNSTarget> dnsTargets){
		List<DNSTargetForEdit> dnsTargetForEdits = new LinkedList<DNSTargetForEdit>();
		
		for(Target t : targets){
			DNSTargetForEdit tt = new DNSTargetForEdit(t.id, t.name, t.targetUrl, t.routeip, t.state, t.createdAt);
			
			for(DNSTarget dt : dnsTargets){
				if( dt.name.equals(tt.name) ){
					tt.bindedToDNS=1;
					
					if( dt.viewNames.contains("USA") )
						tt.view_USA = 1;
					if( dt.viewNames.contains("China") )
						tt.view_China = 1;
					if( dt.viewNames.contains("Korea") )
						tt.view_Korea = 1;
					if( dt.viewNames.contains("Singapore") )
						tt.view_Singapore = 1;
					if( dt.viewNames.contains("Others") )
						tt.view_Others = 1;
				}
			}
			dnsTargetForEdits.add(tt);
		} //
		
		return dnsTargetForEdits;
	}
	public static class DNSTargetForEdit{
		public long id;
		public String name; //target name
		public String url;
		public String routeIP;
		public String state;
	    public Date createdon;
	    
	    public String bak;
	    public String recordIds;  //view record ids
	    public String viewNames; 
	    public int bindedToDNS;
	    
	    public int view_USA = 0;
	    public int view_China = 0;
	    public int view_Korea = 0;
	    public int view_Singapore = 0;
	    public int view_Others = 0;
	    
		public DNSTargetForEdit(long id, String name, String url, String routeIP,
				String state, Date createdon) {
			super();
			this.id = id;
			this.name = name;
			this.url = url;
			this.routeIP = routeIP;
			this.state = state;
			this.createdon = createdon;
			bindedToDNS =0 ;
		}
	    
	}
	
}
