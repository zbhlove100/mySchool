package controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import models.Account;
import models.Domain;
import models.Project;
import models.ProjectEvent;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;
import play.Logger;
import play.data.binding.Binder;
import play.i18n.Messages;
import service.pass.ProjectService;
import utils.PassEventWriter;

import com.google.gson.Gson;
import com.samsung.cloudpi.client.git.CommitsInfo;
import com.samsung.cloudpi.client.git.GitAccount;
import com.samsung.cloudpi.client.git.ProjectInfo;

public class Projects extends CRUD {

	
	public static void overview(Long projectId) {
		
		Project p = new Project();

		try {
			p = ProjectService.getProjectBaseInfoByProjectId(projectId);
		} catch (Exception e) {
			renderArgs.put("error", Messages.get("crud.hasErrors"));
			Logger.info(">> Getting project overview information has error!!",e);
		}

		render(p);

	}

	public static void branch(Long projectId, Long userId) {

		String name = ProjectService.getProjectBaseInfoByProjectId(projectId).name;
		Account account = Account.findById(userId);
		
		List<String> branchs=new ArrayList<String>();
		List<String> tags=new ArrayList<String>();
		GitAccount gitAccount = ProjectService.getGitAccount(account.username,
				account.passwordBase64, ProjectService.getGitServerURL());		
		
		try{
			// get branchs
			 branchs= ProjectService.getBranchsByProjectName(gitAccount, name);

			// get tags
			 tags= ProjectService.getTagsByProjectName(gitAccount, name);
		}catch(Exception e){
			renderArgs.put("error", Messages.get("crud.hasErrors"));
			Logger.info(">> Getting project tag and branch information has error!!",e);
		}
		
		render(branchs, tags, name);

	}

	public static void queryresult(Long proId, Long userId, String value,
			String type) {

		List<CommitsInfo> result = new ArrayList<CommitsInfo>();

		Project project = Project.findById(proId);
		Account account = Account.findById(userId);
		try {

			GitAccount gitAccount = ProjectService.getGitAccount(account.username,
					account.passwordBase64, ProjectService.getGitServerURL());

			// list by tag
			if (type.equals("tag")) {
				result = ProjectService.queryCommitInfoByTag(gitAccount, project.name,
						value);
			} else {
				// list by branch
				result = ProjectService.queryCommitInfoByBranch(gitAccount,
						project.name, value);
			}
		} catch (Exception e) {
			renderArgs.put("error", Messages.get("crud.hasErrors"));
			Logger.info(">> Getting query result has error!!",e);
		}

		render(value, type, result);

	}

	public static void events(Long projectId) {

		List<ProjectEvent> events = ProjectService.getEventsByProjectId(projectId);
		render(events);

	}

	public static void list() {

		String roleType = CurrentUser.current().role;
		List<Account> users = new ArrayList<Account>();
		List<Domain> domains = new ArrayList<Domain>();
		Where searchWhere = new Where(params);
		Where where = new Where(null);

		if (roleType.equals("root")) { // root user
			// get page domain list
			domains = Domain.availables();

			// get page user list
			String domainId = params.get("domainid");
			if (domainId != null && !domainId.equals("")) {
				where.addValue("domain_id=", domainId);
			}
			where.addValue("state=", BaseModel.ACTIVE);
			users = Account.find(where.where(), where.paramsarr()).fetch();

			// search info
			searchWhere.add("domainid", "domain_id=");
			searchWhere.add("userid", "account_id=");

		} else if (roleType.equals("domainadmin")) {// domain admin user

			// get page user list
			where.addValue("state=", BaseModel.ACTIVE);
			where.addValue("domain_id=", CurrentUser.current().domainid);
			where.addValue("username!=", "root");
			users = Account.find(where.where(), where.paramsarr()).fetch();

			// search info
			searchWhere.addValue("domain_id=", CurrentUser.current().domainid);
			searchWhere.add("userid", "account_id=");

		} else { // domain user

			searchWhere.addValue("account_id=", CurrentUser.current().id);
		}

		renderArgs.put("domains", domains);
		renderArgs.put("users", users);
		renderArgs.put("roleType", roleType);

		_list(searchWhere);

	}

	public static void create() throws Exception {

		// get page info
		String projectName = params.get("object.name");
		ProjectInfo projectInfo = new ProjectInfo();
		projectInfo.setProjectName(projectName);
		projectInfo.setFramework(params.get("object.framework"));
		projectInfo.setRuntime(params.get("object.runtime"));

		// create project
		Account account = Account.findById(CurrentUser.current().id);

		GitAccount gitAccount = ProjectService.getGitAccount(account.username,
				account.passwordBase64, ProjectService.getGitServerURL());
		String gitURL = ProjectService.createGitRepo(gitAccount, projectInfo);
		params.put("object.gitUrl", gitURL);

		// save info to db
		Project project = new Project();
		Binder.bind(project, "object", params.all());

		validation.valid(project);
		if (validation.hasErrors()) {
			Logger.debug("Validation error: %s is %s",
					validation.errors().get(0).getKey(), validation.errors()
							.get(0));
			renderJSON(jsonMessage(Messages.get("crud.hasErrors")));
		}

		project.save();

		// write log
		Where where = new Where(null);
		where.addValue("name=", projectName);
		where.addValue("account_id=", CurrentUser.current().id);

		Project p = Project.find(where.where(), where.paramsarr()).first();
		String event = "Create new project: " + projectName + "!";
		PassEventWriter.writeEvent(account.id,"", "", p.id, ProjectEvent.INFO, event);

		renderJSON(forwardJson("projects", "/projects/list",
				Messages.get("crud.created", "Project")));

	}

	public static void deletes(String ids) {

		String idArr[] = ids.split(",");
		for (int i = 0; i < idArr.length; i++) {
			ProjectService.deleteProjectByProjectId(Long.valueOf(idArr[i]),
					CurrentUser.current().name, CurrentUser.current().password);
		}

		renderJSON(forwardJson("projects", "/projects/list",
				Messages.get("crud.deleted", "Project")));

	}

	public static void getdomainuser(Long domainId) {
		Where where = new Where(null);
		where.addValue("state=", BaseModel.ACTIVE);

		if (domainId != null) {
			where.addValue("domain_id=", domainId);
		}

		List<Account> users = Account.find(where.where(), where.paramsarr())
				.fetch();
		List results = new ArrayList();
		for (Account a : users) {
			results.add(new Account(a.id, a.username));
		}

		Gson gson = new Gson();
		String result = gson.toJson(results);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void verifyproject(String proName){
		Where where = new Where(null);
		where.addValue("name=", proName);
		where.addValue("account_id=", CurrentUser.current().id);
		
		Project project=Project.find(where.where(), where.paramsarr()).first();
		String result="true";
		if(project!=null){
			result="false";
		}
		Gson gson = new Gson();
		
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(gson.toJson(result).getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}		
		
	}
}
