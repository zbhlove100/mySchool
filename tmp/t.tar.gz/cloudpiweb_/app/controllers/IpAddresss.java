package controllers;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;

import jobs.AsyncJob;
import jobs.MessageJob;
import models.Account;
import models.Cloudprovider;
import models.Dnszone;
import models.Dnsrecord;
import models.Domain;
import models.FirewallRule;
import models.Server;
import models.Setting;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Message;
import models.spec.Where;

import org.dasein.cloud.InternalException;
import org.dasein.cloud.compute.VmState;
import org.dasein.cloud.network.IpAddress;
import org.springframework.util.StringUtils;

import play.db.jpa.Model;
import play.libs.F;
import play.mvc.Scope;
import service.networking.DnsService;
import service.networking.IpAddrService;

import com.google.gson.Gson;


public class IpAddresss extends CRUD {

	/**
	 * @description 
	 * @param 
	 * @return 
	 */
	
	
	public static void allocate(){
		
		render();
	}
	
	/**
	 * @description allocate a public ip and insert into database 
	 * @param name cloudprovider ID
	 * @return 
	 */
	public static void create(String providerId){
        
		//String providerId = name;
		//Cloudprovider cloudprovider = Cloudprovider.findById(Long.parseLong(providerId));
		IpAddrService ipAddrService = null;
		//IpAddress ipAddress = null;
		//String message = "";
		String conName = "ipaddresss";
		try {
			ipAddrService = new IpAddrService(providerId);
			
			String key = Scope.Session.current().getId();
			
			ipAddrService.setProject((Account)Account.findById(CurrentUser.current().id));
			
			models.IpAddress ipAddress1 = new models.IpAddress();
 		    ipAddress1.cloudprovider = new Cloudprovider(Long.parseLong(providerId));
			ipAddress1.account = new Account(CurrentUser.current().id);
 		    ipAddress1.domain = new Domain(CurrentUser.current().domainid); 			 
 		    ipAddress1.sourceNat = 0;
 		    ipAddress1.publicIpAddress = "Waiting..."; 
 		    ipAddress1.allocated = new Date(System.currentTimeMillis()); 
 		    ipAddress1.state = VmState.PENDING.name();
			
 		    ipAddress1.save();
 		    /**
 		     * commit the data for multi-thread operations.
 		     * */
 		    //ipAddress1.em().getTransaction().commit();
			
			AsyncJob ajob = new AsyncJob(ipAddrService,"getPublicAddress",new F.Action<Map>()
					{
				     public void invoke(Map params)
				      {
				    	 String key = (String)params.get(AsyncJob.session_key);
				 		 models.IpAddress ipAddress1 = models.IpAddress.findById(params.get("ipAddressId"));
				    	 
				    	 Map callresult = (Map)params.get(AsyncJob.result_key);
				    	 
				    	 if(callresult.get(AsyncJob.event_key) != null){
				    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
				    		 ipAddress1.delete();
				    	 }else{
				 			 IpAddress ip = (IpAddress)callresult.get("address");
				 			 ipAddress1.publicIpAddress = ip.getAddress();
				 			 ipAddress1.providerIpAddressId = ip.getProviderIpAddressId();
				 			 ipAddress1.allocated = new Date(java.lang.System.currentTimeMillis());
				 			 ipAddress1.state = (ip.isAssigned()?"allocated":"available");
                             
				 			 DnsService dnsService = (DnsService)params.get("dnsService");
				 			 String ip1 = StringUtils.replace(ipAddress1.publicIpAddress, ".", "-");
					    	 String cpType = ipAddress1.cloudprovider.type.toLowerCase();
					    	 String ttl = "86400";
					    	 String recordType = "A";
					         String implid = null;
							 String zonename = null;
					    	 List<String> publicviews = Setting.values("view");
							 for(String view: publicviews){
					    		Map<String,String> dns_result = dnsService.createRecord(Setting.value("PUBLIC_DNSZONE_ID"), 
					    				recordType, ip1+ "."+cpType, 
					    				ttl, ipAddress1.publicIpAddress, view);
					    		
					    		zonename = dns_result.get("zone_name");
					    		if(implid==null){
					    			implid = dns_result.get("id");
					    		}else{
					    			implid = implid + "," + dns_result.get("id");
					    		}
							 }
							 if(implid != null && zonename != null){
					    		Dnsrecord dzr = new Dnsrecord();
					    		dzr.createdById = ipAddress1.account.id;
					    		dzr.dnszone = Dnszone.find("byName", cpType).first();
						    	dzr.name = ip1+ "."+cpType + "." +zonename;
						    	dzr.state = BaseModel.ACTIVE;
						    	dzr.ttl = Integer.parseInt(ttl);
						    	dzr.type = recordType;
						    	dzr.value = ipAddress1.publicIpAddress;
						    	dzr.impldnsrecord_id = implid;
						    	dzr.view = "All";
						    	dzr.save();
							 }
				 			 
				 			 ipAddress1._save();
				 			 
				    		 MessageJob.publish_info(key,"Success to allocate IP address!");
				    	 }
				      }
				    });
			DnsService dnsService = new DnsService();
			
			ajob.initParams(key);
			ajob.addParam("ipAddressId", ipAddress1.id);
			ajob.addParam("dnsService", dnsService);
			ajob.now();
			//ajob.getResult();
			//ipAddress = ipAddrService.getAddress(ipAddrService.requestPublicIP());
			
			renderJSON(forwardJson(conName,
					String.format("/%s/list", conName),
					"Please wait for allocating ip address."));
			
		} catch (InternalException e) {
			//message = "Raise exception:"+e.getMessage();
		} catch (Exception e) {
			//message += "Raise exception:"+e.getMessage();
		}
		
	}
	
	/**
	 * @description select all from IpAddress by pages
	 * @param pageNum current page number
	 * @param search search key words
	 * @param searchFields 
	 * @param orderField
	 * @param order
	 * @param search2 the type of IpAddress's cloudprovider
	 * @return List<IpAddress>
	 */
	public static void list() {	

		Where where = new Where(params);
		where.add("search2", "cloudprovider.type=");
		where.add("search", "cloudprovider.name like");
   	 	
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("account_id=",cuser.id);
		}
		
		_list(where);
		
    }
	
	public static boolean logicalDelete(Model object, String clzName){
		
		//ObjectType type = (ObjectType)renderArgs.get("type");
		
		try {
			Class entityclass = Class.forName(clzName);

			boolean islogicdelete = false;        
	        if (BaseModel.class.isAssignableFrom(entityclass)){
	        	islogicdelete = true;
	         }
	        
	        if (islogicdelete) {
				Field statefield = getField(entityclass,"state");
				if (statefield != null) {
					setField(statefield,object, BaseModel.DELETE);
					Field rdfield = getField(entityclass,"removedAt");
					if (rdfield != null)
						setField(rdfield,object, new Date(java.lang.System.currentTimeMillis()));
					object._save();
					return true;
				}

			} else {
				object._delete();
				return true;
			}
	        return true;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return true;
		}
		
		
	}
	
	/**
	 * @description release the ip address
	 * @param id the id of ip address which want to release
	 * @return 
	 */
	
	public static void release(String ipAddrId){
		String conName = "ipaddresss";
		models.IpAddress ip = models.IpAddress.findById(Long.parseLong(ipAddrId));
		
		//boolean released = false;
		String message = null;
		IpAddress ipAddress = null;
		
		try{
		    IpAddrService ipAddrService = new IpAddrService(ip.cloudprovider.id.toString());
			 
		    //added by liubs
		    ipAddrService.setProject(ip.account);
		    
		    String key = Scope.Session.current().getId();
			
		    //ipAddress = ipAddrService.getAddress(ip.publicIpAddress);
		    
			    if(ip.cloudprovider.type.equals("AWS") || ip.cloudprovider.type.equals("OPENSTACK") || ip.cloudprovider.type.equals("RACKSPACE")){
				    
			    	AsyncJob ajob = new AsyncJob(ipAddrService,"releasePublicIP",new F.Action<Map>(){
						public void invoke(Map params) {
						    String key = (String)params.get(AsyncJob.session_key);
					    	 
					    	Map callresult = (Map)params.get(AsyncJob.result_key);
					    	 
					    	if(callresult.get(AsyncJob.event_key) != null){
					    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
					    	}else{
					    		models.IpAddress ip = models.IpAddress.findById(Long.parseLong((String)params.get("ipAddrId")));
					    		DnsService dnsService = (DnsService)params.get("dnsService");
					    		
					        	List<Dnsrecord> dnszoneRecords = null;
					        	dnszoneRecords = Dnsrecord.find("value=?", ip.publicIpAddress).fetch();
					        	if(dnszoneRecords != null){
					        		for(Dnsrecord dnszoneRecord : dnszoneRecords){
					        			String []implrecordids = dnszoneRecord.impldnsrecord_id.split(",");
					        			for(String implrecordid: implrecordids){
					        				dnsService.deleteRecord(implrecordid);
					        			}	
							        	dnszoneRecord._delete();
					        		}
					        	}
					    		String ipaddr = ip.publicIpAddress;
					    		ip._delete();
					    		MessageJob.publish_info(key, String.format("Success to release IP %s address!",ipaddr));
					    	}
						}
			    	});
			        ajob.initParams(key);
			        ajob.addInParam("publicIpAddr", ip.publicIpAddress);
			        ajob.addParam("ipAddrId", ipAddrId);
			        DnsService dnsService = new DnsService();
			        ajob.addParam("dnsService", dnsService);
			        ajob.now();
			 
			    	
			        //released = ipAddrService.releasePublicIP(ip.publicIpAddress);
			    
			    }else if(ip.cloudprovider.type.equals("CLOUDSTACK")){
				
			    	AsyncJob ajob = new AsyncJob(ipAddrService,"releasePublicIPForCS",new F.Action<Map>(){
						public void invoke(Map params) {
						    String key = (String)params.get(AsyncJob.session_key);
					    	 
					    	Map callresult = (Map)params.get(AsyncJob.result_key);
					    	 
					    	if(callresult.get(AsyncJob.event_key) != null){
					    		
					    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
					    	}else{
					    		models.IpAddress ip = models.IpAddress.findById(Long.parseLong((String)params.get("ipAddrId")));
					    		DnsService dnsService = (DnsService)params.get("dnsService");
					    		List<Dnsrecord> dnszoneRecords = null;
					        	dnszoneRecords = Dnsrecord.find("value=?", ip.publicIpAddress).fetch();
					        	if(dnszoneRecords != null){
					        		for(Dnsrecord dnszoneRecord : dnszoneRecords){
					        			String []implrecordids = dnszoneRecord.impldnsrecord_id.split(",");
					        			for(String implrecordid: implrecordids){
					        				dnsService.deleteRecord(implrecordid);
					        			}	
							        	dnszoneRecord._delete();
					        		}
					        	}
					        	
					    		String ipaddr = ip.publicIpAddress;
					    		System.out.println(">>>>>>>>>>>>>>"+(Boolean)callresult.get("result"));
					    		List<FirewallRule> firewallRules = FirewallRule.find("ip_address.id=?", ip.id).fetch();
								if(firewallRules != null){
									for(FirewallRule firewallRule : firewallRules){
										logicalDelete(firewallRule, "models.FirewallRule");
									}
								}
					    		ip._delete();
					    		MessageJob.publish_info(key, String.format("Success to release IP %s address!",ipaddr));
					    	}
						}
			    	});
			        ajob.initParams(key);
			        ajob.addInParam("providerIpAddressId", ip.providerIpAddressId);
			        ajob.addParam("ipAddrId", ipAddrId);
			        DnsService dnsService = new DnsService();
			        ajob.addParam("dnsService", dnsService);
			        ajob.now();
					//released = ipAddrService.releasePublicIP(ipAddress.getProviderIpAddressId());
			    }
		    
		    
		} catch (InternalException e) {
			message = e.getMessage();
		} catch (Exception e) {
			message += "<br>"+e.getMessage();
		}
		renderJSON(forwardJson(conName,
				String.format("/%s/list", conName),
				"Please wait for releasing the ip."));
		/*
		if(released){
			
			logicalDelete(ip, "models.IpAddress");
			
			if (request.format.equals("json")) {
				renderJSON(forwardJson(conName,
						String.format("/%s/list", conName),
						Messages.get("ipAddress.released", ip.publicIpAddress)));
			} else {

				flash.success(Messages.get("ipAddress.released", ip.publicIpAddress));
				redirect(request.controller + ".list");
			}
		}else{
			if (request.format.equals("json")) {
				renderJSON(forwardJson("300", conName,
						String.format("/%s/list", conName), 
						String.format("Could not release ip:%s!<br>ERROR:%s", ip.publicIpAddress, message)));
			} else {

				flash.error(String.format("Could not release ip:%s!<br>ERROR:%s", ip.publicIpAddress, message));
				redirect(request.controller + ".list");
			}
		}
		*/
	}
	
	
	/**
	 * @description show all available servers to users to select
	 * @param id server'id
	 * @return List<Server>
	 */
	public static void associate(String id){
		String state = "RUNNING";
		models.IpAddress ipAddress = new models.IpAddress();
		ipAddress = models.IpAddress.findById(Long.parseLong(id));
		String type = ipAddress.cloudprovider.type;
		
		Where where = new Where(null);
		
		where.addValue("state =", state);
		where.addValue("cloudprovider.type =", type);
		CurrentUser cuser = CurrentUser.current();
		if(!cuser.isSuper()){
			where.addValue("created_by_id=",cuser.id);
		}	
		
		List<Server> objects = Server.find(where.where(),where.paramsarr()).fetch();
		
		render(objects, id, type);
	}
	/**
	 * @description check the server is associate with ip or not
	 *              in this version only check the data in database
	 *              TODO: check the server with API
	 * @param serverId
	 * @return IpAddress if this server has associated with ip address, otherwise null
	 */
	public static models.IpAddress serverIsAssocIp(String serverId){
		List<models.IpAddress> ipAddresss = models.IpAddress.find("server.id=?", Long.parseLong(serverId)).fetch();
		if(ipAddresss.size() >= 1){
			return ipAddresss.get(0);
		}
		return null;
		
	}
	
	/**
	 * @description associate ip address with server
	 * @param serverId server.id
	 * @param ipAddrId models.ipAddress.id
	 * @param publicPort 
	 * @param privatePort
	 * @param protocol
	 */
	
	public static void doassociate(String serverId, String ipAddrId, int publicPort, int privatePort, String protocol){
		//generate a models.IpAddress according to the ipAddrId
		models.IpAddress ipAddress = new models.IpAddress();
		ipAddress = models.IpAddress.findById(Long.parseLong(ipAddrId));

		//get the models.ipAddress.cloudprovider's type
		String type = ipAddress.cloudprovider.type;
		//generate a models.server according to the serverId
		Server server = Server.findById(Long.parseLong(serverId));
		//generate a object of IpAddrService
		IpAddrService ipAddrService  = null;
		String message = null;
		
		try {
			ipAddrService = new IpAddrService(ipAddress.cloudprovider.id.toString());
			
			//added by liubs
		    ipAddrService.setProject(ipAddress.account);
		    
		    ipAddress.state = BaseModel.PROCESSING;
		    
		    ipAddress._save();
		    
			//call different function for different ipAddress.cloudprovider.type
			if(type.equals("AWS") || type.equals("OPENSTACK") || type.equals("RACKSPACE")){
				
				String key = Scope.Session.current().getId();
				AsyncJob ajob = new AsyncJob(ipAddrService,"associatePublicIP",new F.Action<Map>(){
					public void invoke(Map params) {
					    String key = (String)params.get(AsyncJob.session_key);
				    	 
				    	Map callresult = (Map)params.get(AsyncJob.result_key);
				    	 
				    	models.IpAddress ipAddress = models.IpAddress.findById(Long.parseLong((String)params.get("ipAddrId")));
				    	
				    	if(callresult.get(AsyncJob.event_key) != null){
				    		 //ipAddress.delete();
				    		 //ipAddress.state = "";
				    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
				    	}else{
				    		System.out.println(">>>>>>>>>>>>>>"+(Boolean)callresult.get("result"));
				    		ipAddress.server = new Server(Long.parseLong((String)params.get("serverId")));
							ipAddress.state = "associated";
							ipAddress._save();
				    		MessageJob.publish_info(key,String.format("Success to associate an IP %s !",ipAddress.publicIpAddress));
				    	}
					}
		    	});
		        ajob.initParams(key);
		        ajob.addInParam("publicIpAddress", ipAddress.publicIpAddress);
		        ajob.addInParam("implinstanceId", server.implinstanceId);
		        ajob.addParam("serverId", serverId);
		        ajob.addParam("ipAddrId", ipAddrId);
		        ajob.now();
				
		        /*
		    	DnsService dnsService = new DnsService();
		    	//String zoneId1 = Setting.value("PUBLIC_DNSZONE_ID");
		    	String ip = StringUtils.replace(ipAddress.publicIpAddress, ".", "-");
		    	String cpType = ipAddress.cloudprovider.type.toLowerCase();
		    	String ttl = "86400";
		    	String recordType = "A";
		        //String host = ip + "." + cpType;
		    	//String view = "cloudpi.org";
		        String implid = null;
				String zonename = null;
		    	List<String> publicviews = Setting.values("view");
				for(String view: publicviews){
		    		Map<String,String> dns_result = dnsService.createRecord(Setting.value("PUBLIC_DNSZONE_ID"), 
		    				recordType, ip+ "."+cpType, 
		    				ttl, ipAddress.publicIpAddress, view);
		    		implid = dns_result.get("id");
		    		zonename = dns_result.get("zone_name");
				}
				if(implid != null && zonename != null){
		    		Dnsrecord dzr = new Dnsrecord();
		    		dzr.createdById = server.created_by.id;
		    		dzr.dnszone = Dnszone.find("byName", cpType).first();
			    	dzr.name = ip+ "."+cpType + "." +zonename;
			    	dzr.state = BaseModel.ACTIVE;
			    	dzr.ttl = Integer.parseInt(ttl);
			    	dzr.type = recordType;
			    	dzr.value = ipAddress.publicIpAddress;
			    	dzr.impldnsrecord_id = implid;
			    	dzr.view = "All";
			    	dzr.save();
				}
		    	*/
				//associated = ipAddrService.associatePublicIP(ipAddress.publicIpAddress, server.implinstanceId);
			}else if(type.equals("CLOUDSTACK")){
				
				String key = Scope.Session.current().getId();
				AsyncJob ajob = new AsyncJob(ipAddrService,"createForwardingRules",new F.Action<Map>(){
					public void invoke(Map params) {
					    String key = (String)params.get(AsyncJob.session_key);
				    	 
				    	Map callresult = (Map)params.get(AsyncJob.result_key);
				    	 
				    	if(callresult.get(AsyncJob.event_key) != null){
				    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
				    	}else{
				    		System.out.println(">>>>>>>>>>>>>>result:"+(Boolean)callresult.get("result"));
				    		models.IpAddress ipAddress = new models.IpAddress();
				    		Server server = new Server();
				    		ipAddress = models.IpAddress.findById(Long.parseLong((String)params.get("ipAddrId")));
				    		server = Server.findById(Long.parseLong((String)params.get("serverId")));
				    		ipAddress.server = server;
							ipAddress.state = "associated";
							ipAddress._save();
							
							FirewallRule firewallRule = new FirewallRule();
							firewallRule.createdAt = new Date(java.lang.System.currentTimeMillis());
							firewallRule.createdById = (Long)params.get("createdById");
							firewallRule.ip_address = ipAddress;
							firewallRule.server = server;
							firewallRule.endPort = (Integer)params.get("privatePort");
							firewallRule.startPort = (Integer)params.get("publicPort");
							firewallRule.protocol = (String)params.get("protocol");
							firewallRule.implfirewallruleId = (String)callresult.get("rule");
							firewallRule.state = BaseModel.ACTIVE;
							firewallRule._save();
							
				    		MessageJob.publish_info(key, String.format("IP:%s success to associate to %s!",ipAddress.publicIpAddress,server.name));
				    	}
					}
		    	});
		        ajob.initParams(key);
		        ajob.addInParam("providerIpAddressId", ipAddress.providerIpAddressId);
		        ajob.addInParam("publicPort", publicPort);
		        ajob.addInParam("protocol", protocol);
		        ajob.addInParam("privatePort", privatePort);
		        ajob.addInParam("implinstanceId", server.implinstanceId);
		        
		        ajob.addParam("createdById", CurrentUser.current().id);
		        ajob.addParam("serverId", serverId);
		        ajob.addParam("ipAddrId", ipAddrId);
		        ajob.addParam("privatePort", privatePort);
		        ajob.addParam("publicPort", publicPort);
		        ajob.addParam("protocol", protocol);
		        
		        System.out.println(">>>>>>>>>>>>>>>>ajob.now()");
		        
		        ajob.now();
                /*
		    	String ip = StringUtils.replace(ipAddress.publicIpAddress, ".", "-");
		    	String cpType = ipAddress.cloudprovider.type.toLowerCase();
		    	String ttl = "86400";
		    	String recordType = "A";
				
				String implid = null;
				String zonename = null;
				
		    	DnsService dnsService = new DnsService();				
				List<String> publicviews = Setting.values("view");
				for(String view: publicviews){
		    		Map<String,String> dns_result = dnsService.createRecord(Setting.value("PUBLIC_DNSZONE_ID"), 
		    				recordType, ip+ "."+cpType, 
		    				ttl, ipAddress.publicIpAddress, view);
		    		implid = dns_result.get("id");
		    		zonename = dns_result.get("zone_name");
				}
				System.out.println("=====================>id:"+implid);
				System.out.println("=====================>zone_name:"+zonename);
				if(implid != null && zonename != null){
		    		Dnsrecord dzr = new Dnsrecord();
		    		dzr.createdById = server.created_by.id;
		    		dzr.dnszone = Dnszone.find("byName", cpType).first();
			    	dzr.name = ip+ "."+cpType + "." +zonename;
			    	dzr.state = BaseModel.ACTIVE;
			    	dzr.ttl = Integer.parseInt(ttl);
			    	dzr.type = recordType;
			    	dzr.value = ipAddress.publicIpAddress;
			    	dzr.impldnsrecord_id = implid;
			    	dzr.view = "All";
			    	dzr.save();
				}
             */
			}
			
		} catch (InternalException e) {
			message = e.getMessage();
		} catch (Exception e) {
			message += "<br>"+e.getMessage();
		}
		
		String conName = "ipaddresss";
		renderJSON(forwardJson(conName,
				String.format("/%s/list", conName),
				"Please wait for associating!"));
	}
	
	/**
	 * @description only disassociate the ip with server
	 * @param id ipAddress.id
	 * @return
	 */
	
	public static boolean _disassociate(String id, String firewallRuleId){
		models.IpAddress ipAddress = new models.IpAddress();
		ipAddress = models.IpAddress.findById(Long.parseLong(id));
		IpAddrService ipAddrService = null;
		boolean disassociated = false;
		String type = ipAddress.cloudprovider.type;
		
		try {
			ipAddrService = new IpAddrService(ipAddress.cloudprovider.id.toString());
			
			//added by liubs
		    ipAddrService.setProject(ipAddress.account);
		    
			if(type.equals("AWS") || type.equals("OPENSTACK") || type.equals("RACKSPACE")){
				
				String key = Scope.Session.current().getId();
				AsyncJob ajob = new AsyncJob(ipAddrService,"disAssociatePublicIP",new F.Action<Map>(){
					public void invoke(Map params) {
					    String key = (String)params.get(AsyncJob.session_key);
				    	 
				    	Map callresult = (Map)params.get(AsyncJob.result_key);
				    	 
				    	if(callresult.get(AsyncJob.event_key) != null){
				    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
				    	}else{
				    		System.out.println(">>>>>>>>>>>>>>"+(Boolean)callresult.get("result"));
				    		models.IpAddress ip = models.IpAddress.findById(Long.parseLong((String)params.get("ipAddressId")));
				    		String servername = ip.server.name;
				    		ip.server = null;
				    		ip.state = "available";
				    		ip._save();
				    		/*
				        	DnsService dnsService = new DnsService();
				        	List<Dnsrecord> dnszoneRecords = null;
				        	dnszoneRecords = Dnsrecord.find("value=?", ip.publicIpAddress).fetch();
				        	if(dnszoneRecords!=null){
				        		for(Dnsrecord dnszoneRecord : dnszoneRecords){
				        			dnsService.deleteRecord(dnszoneRecord.impldnsrecord_id);
						        	dnszoneRecord._delete();
				        		}
				        	}
				        	*/
				    		MessageJob.publish_info(key, String.format("Success to disassociate IP:%s from %s!",ip.publicIpAddress,servername));
				    	}
					}
		    	});
		        ajob.initParams(key);
		        ajob.addInParam("publicIpAddress", ipAddress.publicIpAddress);
		        ajob.addParam("ipAddressId", id);
		        ajob.now();
				
				//disassociated = ipAddrService.disAssociatePublicIP(ipAddress.publicIpAddress);
			}else if(type.equals("CLOUDSTACK")){
				
				String key = Scope.Session.current().getId();
				AsyncJob ajob = new AsyncJob(ipAddrService,"removeForwardingRules",new F.Action<Map>(){
					public void invoke(Map params) {
					    String key = (String)params.get(AsyncJob.session_key);
				    	 
				    	Map callresult = (Map)params.get(AsyncJob.result_key);
				    	 
				    	if(callresult.get(AsyncJob.event_key) != null){
				    		 MessageJob.publish(key, (Message)callresult.get(AsyncJob.event_key));
				    	}else{
				    		System.out.println(">>>>>>>>>>>>>>"+(Boolean)callresult.get("result"));
				    		FirewallRule firewallRule = FirewallRule.findById(Long.parseLong((String)params.get("implfirewallruleId")));
				    		firewallRule._delete();
				    		models.IpAddress ip = models.IpAddress.findById(Long.parseLong((String)params.get("ipAddressId")));
				    		String servername = ip.server.name;
				    		ip.server = null;
				    		ip.state = "available";
				    		ip._save();
				    		/*
				        	DnsService dnsService = new DnsService();
				        	List<Dnsrecord> dnszoneRecords = null;
				        	dnszoneRecords = Dnsrecord.find("value=?", ip.publicIpAddress).fetch();
				        	if(dnszoneRecords != null){
				        		for(Dnsrecord dnszoneRecord : dnszoneRecords){
				        			dnsService.deleteRecord(dnszoneRecord.impldnsrecord_id);
						        	dnszoneRecord._delete();
				        		}
				        		
				        	}
				        	*/
				        	MessageJob.publish_info(key, String.format("Success to disassociate IP:%s from %s!",ip.publicIpAddress,servername));
				    		MessageJob.publish_info(key,"Success to disassociate!");
				    	}
					}
		    	});
		        ajob.initParams(key);
		        ajob.addInParam("implfirewallruleId", firewallRuleId);
		        ajob.addParam("implfirewallruleId", firewallRuleId);
		        ajob.addParam("ipAddressId", id);
		        ajob.now();
				
			}
		} catch (InternalException e) {
		} catch (Exception e) {
		}
		return disassociated;
	}
	
	/**
	 * @description disassociate ip address and server
	 * @param id models.IpAddress.id
	 * @return 
	 */
	
	public static void disassociate(String ipAddrId, String firewallRuleId){
		models.IpAddress ipAddress = new models.IpAddress();
		ipAddress = models.IpAddress.findById(Long.parseLong(ipAddrId));
		String message = null;
		
		String conName = "ipaddresss";
		_disassociate(ipAddrId, firewallRuleId);
		
		renderJSON(forwardJson(conName,
				String.format("/%s/list", conName),
				"Please wait for disassociating!"));
		
	}
	
	/**
	 * @description prepare json for the dialogAjaxDone
	 * @param status 
	 * @param tabId
	 * @param url
	 * @param message
	 * @return json
	 */
	public static Map forwardJson(String status, String tabId,String url,String message){
        Map map = new HashMap();     
        map.put( "statusCode", status);     
        map.put( "navTabId", tabId);     
        map.put( "forwardUrl", url); 
        
        String allmessages = "";
        
        Object msgs = renderArgs.get("message");
        
        if(msgs != null){
        	if(msgs instanceof String){
        		allmessages = String.format("%s<br>%s", msgs,(message==null? "":message)); 
        	}else if(msgs instanceof List){
        		List msglist = (List)msgs;
        		
        		if(message != null){
        			msglist.add(message);
        		}
        		for(Object msg:msglist){
        			allmessages = String.format("%s<br>%s", allmessages,msg);
        		}
        	}
        }else{
        	 allmessages = message;
         }    
        if(!"".equals(allmessages))
          	 map.put( "message", allmessages);           
        
        return map;       
    }
	/**
	 * @description get ip address details
	 * @param id IpAddress.id
	 * @return object IpAddress
	 */
	public static void details(Long id){
		
		id = Long.parseLong(params.get("id"));
		models.IpAddress ipAddress = new models.IpAddress();
		ipAddress = models.IpAddress.findById(id);
		List<FirewallRule> firewallRules = new ArrayList<FirewallRule>();
		String type = ipAddress.cloudprovider.type;
		if(type.equals("AWS") || type.equals("OPENSTACK") || type.equals("RACKSPACE")){
			firewallRules = null;
		}else if(type.equals("CLOUDSTACK")){
			firewallRules = FirewallRule.find("ip_address.id=? and state!=?", ipAddress.id, BaseModel.DELETE).fetch();
		}
		render(ipAddress, firewallRules);
	}
	
	public static void selectServer(String id){
		List<FirewallRule> firewallRules = new ArrayList<FirewallRule>();
		
		Where where = new Where(null);
		where.addValue("ip_address.id=", Long.parseLong(id));
		where.addValue("state !=", BaseModel.DELETE);
		firewallRules = FirewallRule.find(where.where(), where.paramsarr()).fetch();
		
		render(id, firewallRules);
	}
	
	public static void getIpAddrId(String ipAddrId){
		Gson gson = new Gson();
		List<models.IpAddress> result = models.IpAddress.find("id!=?", Long.parseLong(ipAddrId)).fetch();
		List list = new ArrayList();
		for(models.IpAddress ipAddress : result){
			list.add(ipAddress.id);
		}
		String result2 = gson.toJson(list);
		try {
			response.setContentTypeIfNotSet("application/json; charset=UTF-8");
			response.out.write(result2.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void selectType(String type){
		try{
			Gson gson=new Gson();
			
			List<Cloudprovider> result = Cloudprovider.queryProviders(type);
			List list=new ArrayList();
			for(Cloudprovider provider:result){
				provider.cloudproviderDetails=null;
				list.add(provider);
			}
			
			String result2=gson.toJson(list);
			try {
				response.setContentTypeIfNotSet("application/json; charset=UTF-8");
				response.out.write(result2.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
	   }catch(Exception e){
		   e.printStackTrace();
	   }
	}
}