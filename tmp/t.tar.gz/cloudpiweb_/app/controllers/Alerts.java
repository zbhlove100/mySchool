package controllers;

public class Alerts extends CRUD {
	
}
