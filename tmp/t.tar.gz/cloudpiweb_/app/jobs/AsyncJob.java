package jobs;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import models.spec.CurrentUser;
import models.spec.Message;
import play.jobs.Job;
import play.libs.F;

//Created by liubs
public class AsyncJob extends Job {
	
	public static String inparams_key = "inparams";
	public static String result_key = "result";
	public static String event_key = "event";
	
	public static String session_key = "session_key";
	
	private String name;
	private String username;	
	private long starttime;
	
	private Object instance;
	private Method method;
	private Map params;
	
	private F.Action<Map> callback;


	
	public AsyncJob(Object instance, String method_name, F.Action<Map> callback){
		this.instance = instance;
		try{
			this.name = String.format("Job: executing %s.%s",instance.getClass().getSimpleName(),
					method);
			this.method = instance.getClass().getMethod(method_name, Map.class);
			if(CurrentUser.current() != null){
				this.username = CurrentUser.current().name;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}		
		this.callback = callback;
	}
	
	public AsyncJob(Object instance, String method_name){
		this(instance,method_name,null);
	}

	public AsyncJob(Object instance, String method_name, Map params, F.Action<Map> callback){	
		this(instance,method_name,callback);
		this.params = params;		
	}


	public void doJob() {
		try{
			if(method != null){
				//Logger.info("Starting an async job ...");
				starttime = System.currentTimeMillis();
				
				Map inparams = (Map)params.get(inparams_key);
				try{
					Map result = (Map)method.invoke(instance, inparams);
					params.put(result_key, result);		
					if(callback != null){
						callback.invoke(params);
					}					
				}catch(Exception e){
					e.printStackTrace();
					params.put(AsyncJob.event_key, new Message(300,e.getMessage()));					
				}
				//Logger.info("Finish an async job ...");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Map initParams(String key){
		this.params = new HashMap<String,Object>();
		params.put(session_key, key);
		return params;
	}
	
	public Map initParams(){
		this.params = new HashMap<String,Object>();
		return params;
	}	
	
	public void addInParam(String key,Object value){
		Map inparams = (Map)this.params.get(inparams_key);
		if(inparams == null){
			inparams = new HashMap<String,Object>();
			this.params.put(inparams_key, inparams);
		}
		inparams.put(key, value);
	}
	
	public void addParam(String key,Object value){
		if(this.params == null){
			this.params = new HashMap<String,Object>();
		}
		this.params.put(key, value);
	}	
	
	public Map<String,Object> getResult(){
		return (Map)this.params.get(result_key);
	}
	
	public String getName(){
		return this.name;
	}
	
	public String getUsername(){
		return this.username;
	}	
	
	public Date getStartDate(){
		return new Date(this.starttime);
	}	
}
