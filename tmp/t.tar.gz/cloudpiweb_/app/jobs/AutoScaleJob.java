package jobs;

import java.util.List;

import models.Account;
import models.AppAutoScale;
import models.PassApplication;
import play.Logger;
import play.jobs.Job;
import play.jobs.On;
import service.pass.ApplicationService;

import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.InstanceStats;

@On("0 0/5 * * * ?")
public class AutoScaleJob extends Job {

	public void doJob() {
		Logger.info(">>>>>>>Start autoscale Job!!!");

		List appScales = AppAutoScale.findAll();
		ApplicationService service = new ApplicationService();

		for (int i = 0; i < appScales.size(); i++) {
			AppAutoScale appScale = (AppAutoScale) appScales.get(i);
			if (appScale.isEnable == 1) {

				PassApplication app = appScale.application;
				Account account = Account.findById(app.accountId);
				CloudFoundryProxy proxy = service.getCloudBeanProxy(
						account.username, account.passwordBase64,
						app.target.targetUrl);

				int minInstance = appScale.minInstance;
				if (app.instances < minInstance) {
					Logger.info(">>>Current instance:" + app.instances
							+ " , min instance: " + minInstance);

					service.scaleApplicationByAppId(app.id, minInstance);
					app.instances = minInstance;
					app.save();

					Logger.info(">>>Autoscale to min instance success!!!!");

					continue;
				} else {
					List<InstanceStats> monitorInfos = service
							.getMonitorInfoListByAppId(app.id,
									String.valueOf(appScale.metricPeriod));

					double result = statisticData(monitorInfos,
							appScale.metricMeasurement,
							appScale.metricStatistic);

					Logger.info(">>>Statistic infomation: app name: "
							+ app.name + ",Measurement:"
							+ appScale.metricMeasurement + ", Statistic type:"
							+ appScale.metricStatistic + ", result: " + result
							+ " ,upper:" + appScale.upperThrethod + " ,lower:"
							+ appScale.lowerThrethod + " !!!!!");

					if (result > appScale.upperThrethod
							&& app.instances < appScale.maxInstance) {
						int newInstance = app.instances + 1;
						service.scaleApplicationByAppId( app.id, newInstance);
						app.instances = newInstance;
						app.save();
						Logger.info(">>>Autoscale: instance +1 success!!!!");
					} else if (result < appScale.lowerThrethod
							&& app.instances > appScale.minInstance) {
						int newInstance = app.instances - 1;
						service.scaleApplicationByAppId( app.id, newInstance);
						app.instances = newInstance;
						app.save();
						Logger.info(">>>Autoscale: instance -1 success!!!!");
					}
				}

			}
		}

	}

	private double statisticData(List<InstanceStats> statDatas,
			String metricMeasurement, String metricStatistic) {
		double result = 0;

		if (metricStatistic.equals("average")) {
			result = getAverage(statDatas, metricMeasurement);
		} else if (metricStatistic.equals("sum")) {
			result = getSum(statDatas, metricMeasurement);
		} else if (metricStatistic.equals("min")) {
			result = getMin(statDatas, metricMeasurement);
		} else if (metricStatistic.equals("max")) {
			result = getMax(statDatas, metricMeasurement);
		}

		return result;
	}

	private double getSum(List<InstanceStats> datas, String measurement) {
		double result = 0;

		for (InstanceStats stat : datas) {

			if (measurement.equals("requestcount")) {
				result = result + stat.getRequestCount();
			} else if (measurement.equals("responsetime")) {
				result = result + stat.getResponseTime();
			} else if (measurement.equals("cpu")) {
				result = result + stat.getUsage().getCpu();
			} else if (measurement.equals("ram")) {
				result = result + stat.getUsage().getMem();
			} else if (measurement.equals("networkin")) {

			} else if (measurement.equals("networkout")) {

			}
		}

		return result;
	}

	private double getAverage(List<InstanceStats> datas, String measurement) {
		double result = getSum(datas, measurement);
		int number = datas.size();
		return result / number;

	}

	private double getMin(List<InstanceStats> datas, String measurement) {
		double result = -1;

		for (InstanceStats stat : datas) {

			if (measurement.equals("requestcount")) {
				result = getMin(result, stat.getRequestCount());
			} else if (measurement.equals("responsetime")) {
				result = getMin(result, stat.getResponseTime());
			} else if (measurement.equals("cpu")) {
				result = getMin(result, stat.getUsage().getCpu());
			} else if (measurement.equals("ram")) {
				result = getMin(result, stat.getUsage().getMem());
			} else if (measurement.equals("networkin")) {

			} else if (measurement.equals("networkout")) {

			}
		}

		return result;
	}

	private double getMax(List<InstanceStats> datas, String measurement) {
		double result = -1;

		for (InstanceStats stat : datas) {

			if (measurement.equals("requestcount")) {
				result = getMax(result, stat.getRequestCount());
			} else if (measurement.equals("responsetime")) {
				result = getMax(result, stat.getResponseTime());
			} else if (measurement.equals("cpu")) {
				result = getMax(result, stat.getUsage().getCpu());
			} else if (measurement.equals("ram")) {
				result = getMax(result, stat.getUsage().getMem());
			} else if (measurement.equals("networkin")) {

			} else if (measurement.equals("networkout")) {

			}
		}

		return result;
	}

	private double getMin(double result, double data) {
		if (result == -1)
			return data;
		if (result >= data) {
			return data;
		} else {
			return result;
		}
	}

	private double getMax(double result, double data) {
		if (result == -1)
			return data;

		if (result >= data) {
			return result;
		} else {
			return data;
		}
	}

}