package rest;

import java.util.List;
import java.util.LinkedList;
import java.util.Date;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import service.pass.DNSService;

import com.samsung.cloudpi.client.dns.DnsService;

import models.Account;
import models.DNS;
import models.DNSTarget;
import models.Setting;
import models.rest.*;

@Path("/dns")
@Consumes( { "application/json" } )
@Produces( { "application/json" } )
public class DNSResource {
	
	@GET
	@Path("/")
	public List<models.rest.DNS> getDNSs(@HeaderParam("Authentication") String token){
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		List<models.DNS> modelDNSs = null;
		List<models.rest.DNS> restDNSs = null;
		
		modelDNSs = models.DNS.find(" from DNS where userID=? ", account.id ).fetch();
		restDNSs = new LinkedList<models.rest.DNS>();
		
		for(models.DNS md: modelDNSs){
			models.rest.DNS rd = new models.rest.DNS();
			
			//fill primitive values of models.rest.DNS
			rd.setBak( md.bak );
			rd.setCreatedOn( md.createdOn.toString() );
			rd.setId( md.id );
			rd.setName( md.name );
			rd.setUserID( md.userID );
			
			//fill dnsTargets list of models.rest.DNS
			for( models.DNSTarget mdt : md.dnsTargets){
				models.rest.DNSTarget rdt = new models.rest.DNSTarget();
				rdt.setCreatedOn( mdt.createdon.toString() );
				//rdt.setId( mdt.id );
				rdt.setName( mdt.name );
				rdt.setRouteIP( mdt.routeIP );
				rdt.setTargetUrl( mdt.url );
				rdt.setViewNames( mdt.viewNames );
				rd.getDnsTargets().add( rdt );
			}
			restDNSs.add( rd );
		}
		
		return restDNSs;
	}  //end getDNSs
	
	@POST 
	@Path("/create")
	public models.rest.DNS createDNS(@HeaderParam("Authentication") String token, models.rest.DNS restDNS) throws Exception{
		String DNS_PUBLIC_DOMAIN_NAME_POSTFIX = "";
		//String DNS_API_ADDRESS = "";
		//String DNS_ZONE_ID = "";
		Setting setting = null;
		String fullDNSName = "";
		//DnsService  dnsService = null; 
		models.DNS modelDNS = null;
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		
		setting = Setting.find("from Setting where name=?", controllers.DNSs._DNS_PUBLIC_DOMAIN_NAME_POSTFIX ).first();
		if(setting!=null)
			DNS_PUBLIC_DOMAIN_NAME_POSTFIX = setting.value;		
//		setting = Setting.find("from Setting where name=?", controllers.DNSs._DNS_API_ADDRESS ).first();
//		if(setting!=null)
//			DNS_API_ADDRESS = setting.value;		
//		setting = Setting.find("from Setting where name=?", controllers.DNSs._DNS_ZONE_ID ).first();
//		if(setting!=null)
//			DNS_ZONE_ID = setting.value;
		
		fullDNSName = restDNS.getName()+ DNS_PUBLIC_DOMAIN_NAME_POSTFIX;
		if( DNS.find("from DNS where name=?", fullDNSName ).first()!=null ){
			throw new play.mvc.results.Forbidden("DNS name:"+ fullDNSName +", already exists.");
		}
		
		modelDNS = new models.DNS();
		modelDNS.bak = restDNS.getBak();
		modelDNS.createdOn = new Date();
		modelDNS.name = fullDNSName;
		modelDNS.userID = account.id;		
		if( restDNS.getTargetIds()!=null && restDNS.getTargetIds().size()>0 ) {
			//dnsService = new DnsService( DNS_API_ADDRESS );
			int index=0;
			for(String tID : restDNS.getTargetIds() ){
				models.Target mt = models.Target.findById( new Long(tID) );
				//String viewNameString = "";
				String recordIDList = "";
				
				if( mt!=null ){
					//call dns rest api
					
					/* Map<String, String> result = dnsService.createRecord(DNS_ZONE_ID, "A", restDNS.getName(), mt.routeip, "cloudpi");
					long recordId = 0;
					try{
						recordId = Long.parseLong( result.get("id") );
					}catch(Exception e){							
					} */
					
					//viewNames = params.getAll(t.id+"_viewnames");
					
					
					String []viewNames = restDNS.getViewNames().get(index).split(";");
					if (viewNames!=null && viewNames.length>0){
						for(int j=0;j<viewNames.length;j++){
							//viewNameString += viewNames[j] + ";";
							recordIDList += DNSService.createARecordInOneView( restDNS.getName()+".apps", mt.routeip, viewNames[j] ) + ";";									
							
						}
					}
					
					modelDNS.dnsTargets.add( new models.DNSTarget(mt.name, mt.targetUrl,
							mt.routeip, "", mt.createdAt, recordIDList, restDNS.getViewNames().get(index) ) );
					
					index++;
				}				
			}  //end for
		} //end if
		modelDNS.save();
		
		//fill new values to restDNS(the parameter)
		restDNS.setName( modelDNS.name );
		restDNS.setCreatedOn( modelDNS.createdOn.toString() );
		restDNS.setId( modelDNS.id);
		restDNS.setUserID( modelDNS.userID );
		for( models.DNSTarget mdt : modelDNS.dnsTargets){
			models.rest.DNSTarget rdt = new models.rest.DNSTarget();
			rdt.setCreatedOn( mdt.createdon.toString() );
			rdt.setName( mdt.name );
			rdt.setRouteIP( mdt.routeIP );
			rdt.setTargetUrl( mdt.url );
			rdt.setViewNames( mdt.viewNames );
			restDNS.getDnsTargets().add( rdt );
		}
		
		return restDNS;
	}
	
	@DELETE 
	@Path("/delete/{dnsName}")
	public boolean deleteDNS(@HeaderParam("Authentication") String token, @PathParam("dnsName") String dnsName) {
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		//Setting setting = null;
		//String DNS_API_ADDRESS = "";
		//DnsService  dnsService = null; 
		models.DNS modelDNS = null;
		
		//setting = Setting.find("from Setting where name=?", controllers.DNSs._DNS_API_ADDRESS ).first();
		//if(setting!=null)
		//	DNS_API_ADDRESS = setting.value;
		
		modelDNS = models.DNS.find("from DNS where name=?", dnsName).first();
		
		if( modelDNS!=null ){
			//dnsService = new DnsService( DNS_API_ADDRESS );
			
			for(models.DNSTarget dt : modelDNS.dnsTargets){  //delete dns-zone-record by calling restAPI
				String viewRecords = dt.recordIds;
				DNSService.deleteRecords( viewRecords );
			}	
			
			modelDNS.delete();
		}
		
		return true;
	}
	
}
