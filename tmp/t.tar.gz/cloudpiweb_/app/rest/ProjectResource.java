package rest;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import play.Logger;

import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.git.CommitsInfo;
import com.samsung.cloudpi.client.git.GitAccount;
import com.samsung.cloudpi.client.git.ProjectInfo;


import models.Account;
import models.PassApplication;
import models.ProjectEvent;
import models.rest.*;
import models.spec.Where;

import service.pass.ApplicationService;
import service.pass.ProjectService;

@Path("/projects")
@Consumes( { "application/json" })
@Produces( { "application/json" })
public class ProjectResource {
	@GET
	@Path("/")
	//curl -i --request GET -H "Content-Type: application/json" -H "Authentication:cnVhbnpoaW1pbjoxMzIwMTU0NDYwMTc4" "http://localhost:9000/api/projects"
	public List<Project> getProjects(@HeaderParam("Authentication") String token){
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		List<models.Project> projects = models.Project.find("byAccountId", account.getId()).fetch();
		List<Project> results = new ArrayList<Project>();
		for(models.Project project: projects) {
			Project tmp = new Project();
			tmp.setDescription(project.description);
			tmp.setFramework(project.framework);
			tmp.setGitUrl(project.gitUrl);
			tmp.setName(project.name);
			tmp.setRuntime(project.runtime);
			results.add(tmp);
		}
		return results;
	}
	
	@POST 
	@Path("/create")
	public Object createProject(@HeaderParam("Authentication") String token, Project restProject) throws Exception{
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		models.Project modelProject = new models.Project();
		String gitURL = null;
		GitAccount gitAccount = null;
		ProjectInfo projectInfo = null;
	//	ProjectService ps = null;
		
		//check duplication
		if( models.Project.find("from Project where accountId=? and name=?", account.id, restProject.name).first()!=null ){
			throw new play.mvc.results.Forbidden("Project name:"+restProject.name+", already exists.");
			//return "project name:"+restProject.name+", already exists.";
		}
		
		modelProject.name = restProject.name;
		modelProject.description = restProject.description;
		modelProject.runtime = restProject.runtime;
		modelProject.framework = restProject.framework;
		modelProject.accountId = account.id;
		modelProject.domainId = account.domain.id;
		modelProject.createdAt = new Date();
		
		gitAccount = new GitAccount();
		gitAccount.setUsername( account.username );
		gitAccount.setPassword( account.passwordBase64 );
		gitAccount.setCloudControllerUrl( new URL( ProjectService.getGitServerURL() ) );
		projectInfo = new ProjectInfo();
		projectInfo.setCreateTime( new Date().toGMTString() );
		projectInfo.setDescription( restProject.description );
		projectInfo.setFramework( restProject.framework );
		projectInfo.setProjectName( restProject.name );
		projectInfo.setRuntime( restProject.runtime );
		projectInfo.setUrl( "" );
		
		
		gitURL =ProjectService.createGitRepo(gitAccount, projectInfo);
		modelProject.gitUrl = gitURL;
		modelProject.save();
		
		restProject.gitUrl = gitURL;
		
		return restProject;
	}
	
	@DELETE 
	@Path("/delete/{projectName}")
	public boolean deleteProject(@HeaderParam("Authentication") String token, @PathParam("projectName") String projectName){
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
	
		Where where = new Where(null);
		where.addValue("name=", projectName);
		where.addValue("account_id=", account.id);
		models.Project project=models.Project.find(where.where(),where.paramsarr()).first();
		ProjectService.deleteOneProject(project, account.username, account.passwordBase64);
		//models.Project.delete("delete from Project where name=? and accountId=?", projectName, account.id );
		return true;
	}
	
	@GET
	@Path("/projectevents/{projectName}")
	public List<models.rest.Event> getProjectEvents(@HeaderParam("Authentication") String token, @PathParam("projectName") String projectName){
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		List<models.ProjectEvent> modelEvents = null;
		List<models.rest.Event> restEvents = null;
		
		restEvents = new ArrayList<Event>();
		modelEvents = ProjectEvent.find("from ProjectEvent where accountId=? and project.name=?", account.id, projectName ).fetch();
		for(ProjectEvent pe :  modelEvents){
			Event e = new Event();
			
			e.setApplicationName( pe.applicationName );
			e.setCreatedAt( pe.createdAt.toString() );
			
			
			e.setEventDetail( pe.eventDetail );
			e.setEventType( pe.eventType );
			e.setTargetName( pe.targetName );
			
			restEvents.add(e);
		}
		return restEvents;
	}
	
	@GET
	@Path("/projecttags/{projectName}")
	public List<String> getProjectTags(@HeaderParam("Authentication") String token, @PathParam("projectName") String projectName){
		UserToken userToken = UserToken.decode(token);
		
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		
		GitAccount gitAccount = ProjectService.getGitAccount(account.username,
				account.passwordBase64, ProjectService.getGitServerURL() );
		
		List<String> tags = ProjectService.getTagsByProjectName(gitAccount, projectName);
		
		return tags;
	}
	
	@GET
	@Path("/projectcommitinfo/{projectName}/{tag}")
	public List<CommitsInfo> getProjectCommitInfo(@HeaderParam("Authentication") String token, @PathParam("projectName") String projectName, @PathParam("tag") String tag){
		UserToken userToken = UserToken.decode(token);
		List<CommitsInfo> result = new ArrayList<CommitsInfo>();
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		GitAccount gitAccount = ProjectService.getGitAccount(account.username,
				account.passwordBase64, ProjectService.getGitServerURL() );
		
		result = ProjectService.queryCommitInfoByTag(gitAccount, projectName, tag);
		
		return result;
	}
	
	@GET
	@Path("/projectapps/{projectName}")
	public List<ProjectApp> getProjectApps(@HeaderParam("Authentication") String token, @PathParam("projectName") String projectName){
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		Map<Long, CloudFoundryProxy> cfps = new HashMap<Long, CloudFoundryProxy>();
		//ApplicationService appService = new ApplicationService();
		List<PassApplication> modelApps = null;
		List<ProjectApp> restApps = null;
		
		restApps = new ArrayList<ProjectApp>();
		modelApps = PassApplication.find(" from PassApplication where accountId=? and project.name=?", account.id, projectName ).fetch();
		
		for(PassApplication pa : modelApps){
			ProjectApp a = new ProjectApp();
			
			a.setAppName( pa.name );
			a.setInstance( pa.instances );
			a.setTag( pa.tag );
			a.setTargetName( pa.target.name );
			a.setUrl( pa.url );
			
			String status = ApplicationService.getApplicationStatusByAppName( ApplicationService.getCloudBeanProxy(	account.username, account.passwordBase64, pa.target.targetUrl), pa.name );
			
			a.setStatus(status);
			
			restApps.add(a);
		}
		
		return restApps;
	}
	
}
