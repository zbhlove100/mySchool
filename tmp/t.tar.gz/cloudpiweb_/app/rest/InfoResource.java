package rest;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;

import models.rest.User;
import models.rest.UserToken;

@Path("/info")
@Consumes( { "application/json" })
@Produces( { "application/json" })
public class InfoResource {

	@POST
	@Path("/token")
	//curl -i --request POST --header "Content-Type: application/json" "http://localhost:9000/api/info/token" --data "{\"password\":\"cloudpi\",\"userName\":\"root\"}"
	public UserToken createToken(User user) {
		if (user.authenticate() == true) {
			return UserToken.createUserToken(user.getUserName());
		}
		else {
			throw new WebApplicationException(Status.FORBIDDEN);
		}
	}
	
	@GET
	@Path("/frameworks")
	//curl -i --request GET -H "Content-Type: application/json" "http://localhost:9000/api/info/frameworks"
	public List<String> getFrameworks() {
		List<String> list = new ArrayList<String>();
		list.add("Spring");
		list.add("Rails");
		list.add("Sinatra");
		list.add("Lift");
		return list;
	}
	
}
