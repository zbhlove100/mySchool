package rest;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import models.Account;
import models.Service;
import models.rest.DedicatedService;
import models.rest.UserToken;

@Path("/dedicatedservices")
@Consumes( { "application/json" } )
@Produces( { "application/json" } )
public class DedicatedServiceResource {
	@GET
	@Path("/{id}")	
	public DedicatedService getDedicatedService(@HeaderParam("Authentication") String token, @PathParam("id") Long id) {
		Service service = Service.findById(id);
		DedicatedService result = new DedicatedService();
		result.setConnectionInfo(service.bak);
		result.setName(service.name);
		result.setType(service.type);
		result.setVersion(service.version);
		return result;
	}
	
	@POST
	@Path("/")		
	public Long registerDedicatedService(@HeaderParam("Authentication") String token, DedicatedService dedicatedService) {
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		Service service = new Service();
		service.bak = dedicatedService.getConnectionInfo();
		service.name = dedicatedService.getName();
		service.type = dedicatedService.getType();
		service.version = dedicatedService.getVersion();
		service.owned_by = account;
		service.registered = 0;
		service.registeredDate = null;
		service.save();
		return service.id;
	}
	
}
