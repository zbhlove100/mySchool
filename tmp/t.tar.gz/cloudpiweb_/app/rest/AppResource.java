package rest;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import org.apache.commons.collections.map.HashedMap;

import models.Account;
import models.DomainTarget;
import models.PassApplication;
import models.Project;
import models.ProjectEvent;
import models.Target;
import models.rest.ProjectApp;
import models.rest.UserToken;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Where;
import service.pass.ApplicationService;
import utils.PassEventWriter;

import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.CloudApplication;
import com.samsung.cloudpi.client.cf.lib.CloudService;
import com.samsung.cloudpi.client.cf.lib.InstanceStats;

@Path("/apps")
@Consumes({ "application/json" })
@Produces({ "application/json" })
public class AppResource {

	@GET
	@Path("/usertargets")
	public List<models.rest.Target> getUserTargets(
			@HeaderParam("Authentication") String token) {
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();
		List<models.rest.Target> restTargets = null;
		List<models.Target> modelTargets = null;

		restTargets = new LinkedList<models.rest.Target>();
		modelTargets = new LinkedList<models.Target>();
		for (DomainTarget dt : account.domain.domainTargets) {
			if (dt.target.state.equals(BaseModel.ACTIVE)) {
				restTargets.add(new models.rest.Target(dt.target.name,
						dt.target.targetUrl, dt.target.id));
			}
		}
		return restTargets;
	}

	@POST
	@Path("/create")
	public boolean createApplication(
			@HeaderParam("Authentication") String token, ProjectApp restApp)
			throws Exception {
		// grt sccount info
		boolean result = false;
		try {
			UserToken userToken = UserToken.decode(token);
			Account account = Account.find("byUserName",
					userToken.getUser_name()).first();

			// get project info
			Where where = new Where(null);
			where.addValue("name=", restApp.getProjectName());
			where.addValue("account_id=", account.id);
			Project dbProject = Project.find(where.where(), where.paramsarr())
					.first();

			// get target info
			Target target = Target.findById(restApp.getTargetId());

			// save appliaction info
			PassApplication dbApplication = new PassApplication();
			dbApplication.accountId = account.id;
			dbApplication.project = dbProject;
			dbApplication.target = target;

			dbApplication.branch = restApp.getBranch();
			dbApplication.createdAt = new Date();
			dbApplication.instances = restApp.getInstance();
			dbApplication.memory = restApp.getMemory();
			dbApplication.name = restApp.getAppName();

			String tag = restApp.getTag();
			if (tag.equalsIgnoreCase("last")) {
				dbApplication.tag = "";
			} else {
				dbApplication.tag = restApp.getTag();
			}

			dbApplication.url = restApp.getUrl();

			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64, target.targetUrl);
			ApplicationService.createApplication(proxy, dbApplication,
					dbProject);

			String event = "Create new appliction: " + restApp.getAppName()
					+ "!";
			PassEventWriter.writeEvent(account.id, target.name,
					restApp.getAppName(), dbProject.id, ProjectEvent.INFO,
					event);

			result = true;
		} catch (Exception e) {
			throw new Exception(">>>REST<<<Creating application has error!", e);
		}
		return result;
	}

	@DELETE
	@Path("/delete/{appName}")
	public boolean deleteApplication(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName) throws Exception {
		boolean result = false;
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);
		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);

			ApplicationService.deleteApplicationByApp(proxy, app);

			String event = "Delete appliction: " + app.name + "!";
			PassEventWriter.writeEvent(account.id, app.target.name, app.name,
					app.project.id, ProjectEvent.INFO, event);

			result = true;

		} catch (Exception e) {
			throw new Exception(">>>REST<<<Deleting application has error!", e);
		}
		return result;
	}

	@POST
	@Path("/start/{appName}")
	public boolean startApplication(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName) throws Exception {
		boolean result = false;
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			ApplicationService.startApplicationByAppName(proxy, app.name);

			String event = "Start appliction: " + appName + "!";
			PassEventWriter.writeEvent(account.id, app.target.targetUrl,
					appName, app.project.id, ProjectEvent.INFO, event);

			result = true;
		} catch (Exception e) {
			throw new Exception(">>>REST<<<Starting application has error!", e);
		}

		return result;
	}

	@POST
	@Path("/stop/{appName}")
	public boolean stopApplication(@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName) throws Exception {
		boolean result = false;
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			ApplicationService.stopApplicationByAppName(proxy, app.name);

			String event = "Stop appliction: " + appName + "!";
			PassEventWriter.writeEvent(account.id, app.target.targetUrl,
					appName, app.project.id, ProjectEvent.INFO, event);

			result = true;
		} catch (Exception e) {
			throw new Exception(">>>REST<<<Stopping application has error!", e);
		}

		return result;
	}

	@POST
	@Path("/upgrade/{appName}/{tag}")
	public boolean upgradeApplication(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName, @PathParam("tag") String tag)
			throws Exception {
		boolean result = false;
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);

			if (tag.equalsIgnoreCase("last")) {
				tag = "";
			}

			ApplicationService.upgradeApplicationByApp(proxy, app, tag);

			String event = appName + " has upgraded to " + tag + " !";
			PassEventWriter.writeEvent(account.id, app.target.targetUrl,
					appName, app.project.id, ProjectEvent.INFO, event);

			result = true;
		} catch (Exception e) {
			throw new Exception(">>>REST<<<Ugrading application has error!", e);
		}

		return result;
	}

	@POST
	@Path("/scale/{appName}/{instance}")
	public boolean scaleApplication(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName,
			@PathParam("instance") int instance) throws Exception {
		boolean result = false;
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			ApplicationService.scaleApplicationByApp(proxy, app, instance);

			String event = "Changed " + app.name + "'s instance to " + instance
					+ "!";
			PassEventWriter.writeEvent(account.id, app.target.targetUrl,
					appName, app.project.id, ProjectEvent.INFO, event);

			result = true;
		} catch (Exception e) {
			throw new Exception(">>>REST<<<Scaleing application has error!", e);
		}

		return result;
	}

	@GET
	@Path("/monitor/{appName}/{minute}")
	public List<InstanceStats> listMonitor(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName,
			@PathParam("minute") String minute) throws Exception {
		List<InstanceStats> monitors = new ArrayList<InstanceStats>();
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			monitors = ApplicationService.getMonitorInfoListByApp(proxy, app,
					minute);

		} catch (Exception e) {
			throw new Exception(
					">>>REST<<<Getting monitor information of application has error!",
					e);
		}

		return monitors;
	}

	@GET
	@Path("/service/{appName}")
	public List<CloudService> listService(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName) throws Exception {
		List<CloudService> services = new ArrayList<CloudService>();
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			services = ApplicationService
					.getAllBindServiceListByApp(proxy, app);

		} catch (Exception e) {
			throw new Exception(
					">>>REST<<<Getting servicelist information of application has error!",
					e);
		}

		return services;
	}

	@GET
	@Path("/usableservice/{appName}")
	public List<CloudService> listUsableService(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName) throws Exception {
		List<CloudService> services = new ArrayList<CloudService>();
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			services = ApplicationService.getAllUsableServiceListByApp(proxy,
					app);

		} catch (Exception e) {
			throw new Exception(
					">>>REST<<<Getting all usable servicelist information of application has error!",
					e);
		}

		return services;
	}

	@POST
	@Path("/bind/{appName}/{serviceName}")
	public boolean bindService(@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName,
			@PathParam("serviceName") String serviceName) throws Exception {

		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			ApplicationService.bindOneServiceToApplicationByApp(proxy,
					app, serviceName);

		} catch (Exception e) {
			throw new Exception(
					">>>REST<<<Binding service to application has error!", e);
		}

		return true;
	}

	@POST
	@Path("/unbind/{appName}/{serviceName}")
	public boolean unbindService(@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName,
			@PathParam("serviceName") String serviceName) throws Exception {

		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();

		Where where = new Where(null);
		where.addValue("name=", appName);
		where.addValue("account_id=", account.id);

		try {
			PassApplication app = PassApplication.find(where.where(),
					where.paramsarr()).first();
			CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
					account.username, account.passwordBase64,
					app.target.targetUrl);
			ApplicationService.unbindOneServiceToApplicationByApp(proxy,
					app, serviceName);

		} catch (Exception e) {
			throw new Exception(
					">>>REST<<<Unbinding service to application has error!", e);
		}

		return true;
	}

	@GET
	@Path("/getapp/{appName}")
	public List<CloudApplication> getApplication(
			@HeaderParam("Authentication") String token,
			@PathParam("appName") String appName) throws Exception {

		List<CloudApplication> cfApps = new ArrayList<CloudApplication>();
		
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();
        
		try {
			if(appName.equals("#")){
			List<DomainTarget> dts=account.domain.domainTargets;
			for(DomainTarget dt:dts){
				CloudFoundryProxy proxy=ApplicationService.getCloudBeanProxy(account.username, account.passwordBase64, dt.target.targetUrl);
				cfApps.addAll(proxy.getApplications());							
			}			
		}else{
			Where where = new Where(null);
			where.addValue("name=", appName);
			where.addValue("account_id=", account.id);			
			
				PassApplication app = PassApplication.find(where.where(),
						where.paramsarr()).first();
				if(app==null){
					return cfApps;
					
				}
				
				CloudFoundryProxy proxy = ApplicationService.getCloudBeanProxy(
						account.username, account.passwordBase64,
						app.target.targetUrl);
			CloudApplication	cfApp = ApplicationService.getCFApplicationByAppName(proxy,
						app.name);
			cfApps.add(cfApp);
			
		}		
		} catch (Exception e) {
			throw new Exception(">>>REST<<<Getting application has error!", e);
		}

		return cfApps;
	}
	
	
	@GET
	@Path("/userinfo")
	public Map getUserInfo(@HeaderParam("Authentication") String token)
			throws Exception {
		Map map=new HashedMap();
		UserToken userToken = UserToken.decode(token);
		Account account = Account.find("byUserName", userToken.getUser_name())
				.first();
		if (account != null) {
			map.put("username", account.username);
		}else{
			map.put("username", "");
		}

		return map;
	}

}
