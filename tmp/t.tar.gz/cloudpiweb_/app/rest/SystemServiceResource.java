package rest;

import java.util.List;
import java.util.LinkedList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.samsung.cloudpi.client.cf.CloudBean;
import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.CloudService;

import models.Account;
import models.Domain;
import models.SystemService;
import models.rest.Project;
import models.rest.UserToken;
import models.spec.CurrentUser;

@Path("/systemservice")
@Consumes( { "application/json" })
@Produces( { "application/json" })
public class SystemServiceResource {
	
	@GET
	@Path("/{targetName}")
	public List<models.rest.SystemService> getSystemServices(@HeaderParam("Authentication") String token, @PathParam("targetName") String targetName ){
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		List<models.SystemService> modelServices = null;
		List<models.rest.SystemService> restServices = null;
		
		if( "all".equalsIgnoreCase(targetName) )
			modelServices = SystemService.find(" from SystemService where owned_by_account=?", account ).fetch();
		else
			modelServices = SystemService.find(" from SystemService where owned_by_account=? and owned_by_target.name=?", account, targetName).fetch();
		
		restServices = new LinkedList<models.rest.SystemService>();
		for(models.SystemService ms : modelServices){
			models.rest.SystemService rs = new models.rest.SystemService();
			rs.setAccountId( account.id );
			rs.setAccountName( account.username );
			rs.setDomainId( account.domain.id );
			rs.setDomainName( account.domain.name );
			rs.setId( ms.id );
			rs.setName( ms.name );
			rs.setTargetId( ms.owned_by_target.id );
			rs.setTargetName( ms.owned_by_target.name );
			rs.setTier( ms.tier );
			rs.setType( ms.type );
			rs.setVersion( ms.version );
			restServices.add(rs);
		}		
		
		return restServices;
	}
	
	@POST 
	@Path("/create")
	public models.rest.SystemService createSystemService(@HeaderParam("Authentication") String token, models.rest.SystemService restService) throws Exception{
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		models.Target modelTarget = null;
		String vendor = null;
		String version = null;
		String type = null;
		String fullServiceName = null; //vendorName_accountName_targetName_serviceName
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		models.SystemService modelService = new models.SystemService();
		
		//check target
		modelTarget = models.Target.findById( restService.getTargetId() );
		if( modelTarget==null ){
			throw new play.mvc.results.Forbidden("Target id invalid.");
		}
		
		vendor = restService.getVendor();
		fullServiceName = vendor+"_"+account.username+"_"+modelTarget.name+"_"+restService.getName();
		
		//check system-service name duplication
		if( models.SystemService.find(" from SystemService where name=? and owned_by_account=? and owned_by_target=?", fullServiceName, account, modelTarget).first()!=null ){
			throw new play.mvc.results.Forbidden("Service name:"+ restService.getName() +", already exists.");
		}
		
		if(vendor!=null){
			type = service.pass.SystemService.getServiceTypeByVendor(vendor);
			version = service.pass.SystemService.getServiceVersionByVendor(vendor);
		}
		
		//call rest api
		cloudBean = new CloudBean(account.username + "@samsung.com", account.passwordBase64, modelTarget.targetUrl);
		cf = new CloudFoundryProxy(cloudBean);
		CloudService service = new CloudService();
		service.setName(fullServiceName);
		service.setTier("free");
		service.setType(type);
		service.setVendor(vendor);
		service.setVersion(version);
		cf.createService(service); // call rest api
		
		//save data to DB
		modelService.name = fullServiceName;
		modelService.owned_by_account = account;
		modelService.owned_by_domain = account.domain;
		modelService.owned_by_target = modelTarget;
		modelService.tier = "free";
		modelService.type = type;
		modelService.version = version;
		modelService.save();	
		
		//reconstruct reture data
		restService.setName( fullServiceName );
		restService.setTargetName( modelTarget.name );
		restService.setAccountId( account.id );
		restService.setAccountName( account.username );
		restService.setDomainId( account.domain.id );
		restService.setDomainName( account.domain.name );
		restService.setTier( "free" );
		restService.setType( type );
		restService.setVersion( version );
		restService.setId( modelService.getId() );
		
		return restService;
	} //end createSystemService
	
	@DELETE 
	@Path("/delete/{serviceName}")
	public boolean deleteSystemService(@HeaderParam("Authentication") String token, @PathParam("serviceName") String serviceName) throws Exception{
		UserToken userToken = UserToken.decode(token);
		Account account=Account.find("byUserName", userToken.getUser_name()).first();
		models.Target modelTarget = null;
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		
		models.SystemService mss = models.SystemService.find("from SystemService where name=? and owned_by_account=?", serviceName, account).first();
		modelTarget = mss.owned_by_target;
		
		cloudBean = new CloudBean(account.username + "@samsung.com", account.passwordBase64, modelTarget.targetUrl);
		cf = new CloudFoundryProxy(cloudBean);
		cf.deleteService( serviceName );
		
		mss.delete();
		
		return true;
	}
	
	@GET
	@Path("/cloneService/{appId}/{targetName}")
	public boolean cloneSystemServices(@HeaderParam("Authentication") String token,@PathParam("appId") long appId , @PathParam("targetName") String targetName ){
		models.Target modelTarget = models.Target.find(" from Target where name=?", targetName).first() ;
		
		try{
			service.pass.SystemService.cloneService(appId, modelTarget.id);
		}catch(Exception e){
			throw new play.mvc.results.Error(e.getMessage());
		}
		
		return true;
	}
	
}
