package utils;

public class GetProperty {

	public static String publicKey;
	public static String privateKey;
	public static String accountNumber;
	public static String cloudName;
	public static String endpoint;
	public static String providerName;
	public static String regionId;
	
}
