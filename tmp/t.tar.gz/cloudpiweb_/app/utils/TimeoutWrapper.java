package utils;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Generic class for adding timeouts to method calls.
 * 
 * This class maintains a cache of proxy instances, so that calling:
 * 
 * wrapper.wrap() with the same args will avoid creating a new proxy.
 * 
 * @author Larry Ogrodnek <larry@bizo.com>
 * 
 * @param <T>
 */
public final class TimeoutWrapper<T> {
  public static final int DEFAULT_CACHE_SIZE = 32;

  private final T instance;
  private final Class<T> intf;
  private final ExecutorService executor;
  private final LRUHashMap<ProxyKey<T>, T> cache;

  /**
   * Constructor.
   * 
   * Equivalent to calling:
   *  TimeoutWrapper(intf, instance, Executors.newCachedThreadPool(), TimeoutWrapper.DEFAULT_CACHE_SIZE);
   *  
   * @param intf interface class
   * @param instance object instance implementing interface
   */
  public TimeoutWrapper(final Class<T> intf, final T instance) {
    this(intf, instance, Executors.newCachedThreadPool(), DEFAULT_CACHE_SIZE);
  }
 
  public TimeoutWrapper(final Class<T> intf, final T instance, final ExecutorService executor) {
    this(intf, instance, executor, DEFAULT_CACHE_SIZE);
  }

  
  /**
   * Constructor.
   * 
   * Equivalent to calling:
   *  TimeoutWrapper(intf, instance, Executors.newCachedThreadPool(), TimeoutWrapper.DEFAULT_CACHE_SIZE);
   *  
   * @param intf interface class
   * @param instance object instance implementing interface
   * @param exector executor service instance to use for running operations.  This directly affects how many operations
   * can run at a given time.
   * @param cacheSize how many cached proxy instances to keep around. 
   */
  public TimeoutWrapper(final Class<T> intf, final T instance, final ExecutorService executor, final int cacheSize) {
    this.intf = intf;
    this.instance = instance;
    this.executor = executor;
    this.cache = new LRUHashMap<ProxyKey<T>, T>(cacheSize);
  }
  
  
  /**
   * Convenience method to get underlying instance without a timeout.
   * 
   * @return underlying service without a timeout.
   */
  public T get() {
    return instance;
  }

  public T withTimeout(final long timeout, final TimeUnit unit) {

    final ProxyKey<T> key = new ProxyKey<T>(timeout, unit);

    T wrapped = this.cache.get(key);

    if (wrapped != null) {
      return wrapped;
    }

    final TimedInvocationHandler h = new TimedInvocationHandler(this.instance, this.executor, timeout, unit);

    wrapped = GenericProxyFactory.getProxy(this.intf, h);

    this.cache.put(key, wrapped);

    return wrapped;
  }

  private static final class ProxyKey<T> {
    private final long timeout;
    private final TimeUnit unit;

    private ProxyKey(final long timeout, final TimeUnit unit) {
      this.timeout = timeout;
      this.unit = unit;
    }

    @Override
    public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + (int) (this.timeout ^ (this.timeout >>> 32));
      result = prime * result + ((this.unit == null) ? 0 : this.unit.hashCode());
      return result;
    }

    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(final Object obj) {
      if (this == obj) {
        return true;
      }
      if (obj == null) {
        return false;
      }
      if (getClass() != obj.getClass()) {
        return false;
      }
      final ProxyKey other = (ProxyKey) obj;
      if (this.timeout != other.timeout) {
        return false;
      }
      if (this.unit == null) {
        if (other.unit != null) {
          return false;
        }
      } else if (!this.unit.equals(other.unit)) {
        return false;
      }
      return true;
    }
  }
}

