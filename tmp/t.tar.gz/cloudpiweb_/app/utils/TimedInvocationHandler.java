package utils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Wrap method calls with timeouts.
 * 
 * @author Larry Ogrodnek <larry@bizo.com>
 */
final class TimedInvocationHandler implements InvocationHandler {

  private final ExecutorService executor;
  private final Object instance;

  private final long timeout;
  private final TimeUnit unit;

  TimedInvocationHandler(final Object instance, final ExecutorService executor, final long timeout, final TimeUnit unit) {
    this.instance = instance;
    this.executor = executor;

    this.timeout = timeout;
    this.unit = unit;
  }

  public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {

    final Collection<Callable<Object>> tasks = new ArrayList<Callable<Object>>(1);

    tasks.add(new Callable<Object>() {
      public Object call() throws Exception {
        return method.invoke(TimedInvocationHandler.this.instance, args);
      }
    });

    return this.executor.invokeAny(tasks, this.timeout, this.unit);
  }
}
