package utils;

public class UserNameAnalyzer {
	
	public static String analyzeUserName(String userName, String type) {
		int pos = userName.indexOf("@");
		if (type.equals("git") && pos > 0) {
			userName = userName.substring(0, pos);
		}
		;
		if (type.equals("cf") && pos < 0) {
			userName = userName + "@samsung.com";
		}

		return userName;

	}

}
