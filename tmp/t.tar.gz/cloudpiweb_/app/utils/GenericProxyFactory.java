package utils;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

/**
 * Handle proxy creation and casting.
 * 
 * @author Larry Ogrodnek <larry@bizo.com>
 */
public class GenericProxyFactory {
  public static <T> T getProxy(final Class<? extends T> intf, final InvocationHandler handler) {
      return (T) intf.cast(Proxy.newProxyInstance(intf.getClassLoader(), new Class[] { intf }, handler));
  }
}

