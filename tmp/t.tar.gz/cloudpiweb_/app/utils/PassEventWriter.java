package utils;

import java.util.Date;

import models.Project;
import models.ProjectEvent;
import models.spec.CurrentUser;

public class PassEventWriter {
	
	public static void writeEvent(Long accountId,String targetName,String appName,Long projectId,String type,String detail){
		//Long accountId=CurrentUser.current().id;
		Project project=Project.findById(projectId);
		Date nowDate= new Date(); 
		ProjectEvent event= new ProjectEvent(targetName,appName,type,detail,accountId,project,nowDate);
		event.save();
	}

}
