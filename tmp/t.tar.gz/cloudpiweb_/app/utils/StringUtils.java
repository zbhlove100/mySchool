package utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;
public class StringUtils{

    private Map<String,Object> allValues(JSONObject val,boolean ignorehead){
   	 Map<String,Object> values = new HashMap<String,Object>();
   	 Iterator vals = val.entrySet().iterator();
       while (vals.hasNext()) {
         
       	Map.Entry e = (Map.Entry)vals.next();
          Object ev = e.getValue();
          
          if(ev instanceof JSONObject){
       	     if(!ignorehead){
       	    	 values.put(e.getKey().toString(), allValues((JSONObject)ev,false));
       	     }else{
       	    	 values = allValues((JSONObject)ev,false);
       	     }
          }if(ev instanceof List){
       	   
       	   Object[] objects = ((List) ev).toArray();
       	   
       	   for(int i=0 ;i < objects.length; i++){
       		   objects[i]  = allValues((JSONObject)objects[i],false);
       	   }
       	   
          }else{
           	 if(!ignorehead){
           		 values.put(e.getKey().toString(), ev);
           	 }
            }
         }    	
   	  return values;
   }

}
