package service.admin;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.cloudstack.CloudstackMethod;
import org.dasein.cloud.cloudstack.CloudstackProvider;
import org.dasein.cloud.cloudstack.Param;

import play.Logger;
import service.utils.JsonUtils;

//Created by Liubisheng
public class CloudstackJsonMethod extends CloudstackMethod {
    
    public CloudstackJsonMethod(CloudstackProvider provider) { super(provider); }
    
    public String buildUrlforJson(String command, Map<String,String> params)  throws InternalException{
        List<Param> csparams = new ArrayList<Param>(); 
        for(String key:params.keySet()){
        	 Param p = new Param(key,params.get(key));
        	 csparams.add(p);
         }    	
        csparams.add(new Param("response","json"));
        
        return buildUrl(command, csparams.toArray(new Param[csparams.size()]));
    }
    
    public Map<String,Object> getjson(String url) throws CloudException, InternalException {
    	
        try {
            HttpClient client = getClient();
            
            HttpConnectionManagerParams hmps = client.getHttpConnectionManager().getParams();
            
            //the unit is ms 
            hmps.setConnectionTimeout(30000);
            hmps.setSoTimeout(120000); 
          
            GetMethod get = new GetMethod(url);
            
            try{
	            get.addRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
	            get.addRequestHeader("Cache-Control","no-cache");
	            get.getParams().setCookiePolicy(CookiePolicy.IGNORE_COOKIES);
	
	            client.executeMethod(get);
	            
	            JSONObject obj = JSONObject.fromObject(get.getResponseBodyAsString());
	            Map<String,Object> values = JsonUtils.allValues(obj,true);
	              
	            Logger.debug("return json: %s", values);
	            
	            return values;
	            
            }finally{
            	get.releaseConnection();
            }
        }
        
       catch(Exception e) {
    	   throw new CloudException("Exception: " + e.getMessage());    	   
        }
    }

}
