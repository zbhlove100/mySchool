package service.admin;

import java.util.HashMap;
import java.util.Map;

import models.Cloudprovider;
import models.Quota;

// Created by Liubisheng
public class OpenstackAdmin {

	private String providerId;	
	private OpenstackCall osec2;
	
	public OpenstackAdmin(String providerId) throws Exception{
		this.providerId = providerId;
		this.osec2 = new OpenstackCall(providerId);		
		this.osec2.setService("Admin");
	}
	
	public OpenstackAdmin(Cloudprovider provider) throws Exception{
		this.providerId = provider.id.toString();
		this.osec2 = new OpenstackCall(provider);		
		this.osec2.setService("Admin");
	}
	
	public String queryProject(String name){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("name", name);
    	Map result = osec2.call("DescribeProject", params);
    	return (String)result.get("projectname");
    	
	}
	
	public String createProject(String name){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("name", name);
    	params.put("manager_user", osec2.getAccountNumber());
    	Map result = osec2.call("RegisterProject", params);
    	return (String)result.get("projectname");
    	
	}

	public String deleteProject(String name){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("name", name);
    	Map result = osec2.call("DeregisterProject", params);
    	return (String)result.get("return");
    	
	}

	public String setQuota(Quota quota){
		
    	Map<String,String> params = new HashMap<String,String>();
    	    	
    	String shareKey = new String(osec2.getProvider().getContext().getAccessPublic());
    	int pos = shareKey.indexOf(':');
    	
    	String project = shareKey.substring(pos+1);
    	
    	params.put("project_id", project);
    	
    	params.put("key", "instances");
    	if(quota.instanceLimit > -1){
    		params.put("value", ""+quota.instanceLimit);
    	}
    	osec2.call("ProjectQuota", params);
    	
    	params.clear();
    	params.put("project_id", project);
    	params.put("key", "floating_ips");
    	if(quota.ipLimit > -1){
    		params.put("value", ""+quota.ipLimit);
    	}
    	osec2.call("ProjectQuota", params);
    	
    	params.clear();
    	params.put("project_id", project);
    	params.put("key", "volumes");
    	if(quota.volumeLimit > -1){
    	  params.put("value", ""+quota.volumeLimit);
    	}
    	
    	Map<String,String> result = osec2.call("ProjectQuota", params);
	    	
		// params.put("key", "quota_instances");
		// params.put("value", ""+quota.snapshotLimit);
		// 
		// result = osec2.call("ProjectQuota", params);
		//    	
		// params.put("key", "quota_instances");
		// params.put("value", ""+quota.templateLimit);
		// 
		// result = osec2.call("ProjectQuota", params);
	    
	   return (String)result.get("instances");
	}	
	
}
