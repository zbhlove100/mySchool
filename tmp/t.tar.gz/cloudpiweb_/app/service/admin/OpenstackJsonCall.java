package service.admin;

import java.util.HashMap;
import java.util.Map;

import models.Cloudprovider;

import org.dasein.cloud.cloudstack.CloudstackProvider;

import play.Logger;
import service.BaseService;

//Created by Liubisheng
public class OpenstackJsonCall extends BaseService{
	
	public OpenstackJsonCall(Cloudprovider providermodel)throws Exception{
		super(providermodel);
	}
	
	public OpenstackJsonCall(String providerId) throws Exception{
		super(providerId);
	}
	
    public Map call(String command, Map<String,String> params){

    	try{
	        CloudstackJsonMethod method = new CloudstackJsonMethod((CloudstackProvider)provider);
	        
	        String url = method.buildUrlforJson(command, params);
	        
	        Logger.debug("Call API url in callservice: %s", url);
	        
	        return method.getjson(url);
	        
    	}catch(Exception e){
    		e.printStackTrace();
        	Map<String,Object> values = new HashMap<String,Object>();    		
    		values.put("error", e.toString());
        	return values;    		
    	}

    }
}
