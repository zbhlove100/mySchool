package service.admin;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import models.Cloudprovider;

import org.dasein.cloud.InternalException;
import org.dasein.cloud.ProviderContext;
import org.dasein.cloud.openstack.nova.ec2.NovaEC2;

import play.Logger;
import service.BaseService;
import service.utils.MapEntryConverter;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

//Created by Liubisheng
public class OpenstackCall extends BaseService{
    
	static public final String P_ACCESS            = "AWSAccessKeyId";
    static public final String P_ACTION            = "Action";
    static public final String P_CFAUTH            = "Authorization";
    static public final String P_DATE              = "x-amz-date";
    static public final String P_SIGNATURE         = "Signature";
    static public final String P_SIGNATURE_METHOD  = "SignatureMethod";
    static public final String P_SIGNATURE_VERSION = "SignatureVersion";
    static public final String P_TIMESTAMP         = "Timestamp";
    static public final String P_VERSION           = "Version";
    
    static public final String EC2_ALGORITHM       = "HmacSHA256";
    static public final String SIGNATURE           = "2";
    static public final String VERSION             = "2009-11-30";
    static public final String ELB_VERSION         = "2009-11-30";
    
    private String service;
    
	public OpenstackCall(Cloudprovider providermodel)throws Exception{
		super(providermodel);
	}
	
	public OpenstackCall(String providerId) throws Exception{
		super(providerId);
	}
	
	public String getAccountNumber(){
		return this.accountNumber;
	}
	
    public Map<String,String> getStandardParameters(ProviderContext ctx, String action) throws InternalException {
        HashMap<String,String> parameters = new HashMap<String,String>();
        
        parameters.put(P_ACTION, action);
        parameters.put(P_SIGNATURE_VERSION, SIGNATURE);
        try {
           //parameters.put(P_ACCESS, new String(ctx.getAccessPublic(), "utf-8") + ":" + ctx.getAccountNumber());
        	parameters.put(P_ACCESS, new String(ctx.getAccessPublic(), "utf-8"));
        } 
        catch( UnsupportedEncodingException e ) {
            e.printStackTrace();
            throw new InternalException(e);
        }
        parameters.put(P_SIGNATURE_METHOD, EC2_ALGORITHM);
        parameters.put(P_TIMESTAMP, getTimestamp(System.currentTimeMillis(), false));
        parameters.put(P_VERSION, VERSION);
        return parameters;
    }
    
    public String getTimestamp(long timestamp, boolean withMillis) {
        SimpleDateFormat fmt;
        
        if( withMillis ) {
            fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
        }
        else {
            fmt = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");            
        }
        fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        return fmt.format(new Date(timestamp));
    }
    
    public void setService(String service){
    	this.service = service;
    }
    
    public Map call(String command, Map<String,String> params){
    	
    	String xmlstr = null;
    	try{
    		
    		NovaEC2 current_provider =  (NovaEC2)provider;
    		String endpoint = current_provider.getEc2Url();
    		
    		if(this.service != null){
    			int pos = current_provider.getEc2Url().indexOf("services");
    			endpoint = current_provider.getEc2Url().substring(0, pos+8) + "/"+ service;
    		}
    		
	       Map<String,String> parameters = getStandardParameters(provider.getContext(), command);
	       parameters.putAll(params);
	       
	       OpenstackEC2Method method = new OpenstackEC2Method(current_provider,endpoint,parameters);
	       xmlstr = method.invoke();
	      
			XStream xStream = new XStream(new DomDriver());
			
			xStream.alias(command+"Response", java.util.Map.class);
			xStream.alias("item", java.util.List.class);
			
			xStream.registerConverter(new MapEntryConverter());
			
			Map<String,Object> values = (Map<String,Object>) xStream.fromXML(xmlstr);

			Logger.debug("return values: %s", values);

			return values;
	        
    	}catch(Exception e){
    		play.Logger.info("error in openstack call:%s", xmlstr);
    		e.printStackTrace();
        	Map<String,Object> values = new HashMap<String,Object>();    		
    		values.put("error", e.toString());
        	return values;    		
    	}

    }
}
