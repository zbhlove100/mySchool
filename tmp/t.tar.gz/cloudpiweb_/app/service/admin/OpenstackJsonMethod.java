package service.admin;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.TreeSet;

import net.sf.json.JSONObject;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.openstack.nova.ec2.NovaEC2;

import play.Logger;
import service.utils.JsonUtils;

//Created by Liubisheng
public class OpenstackJsonMethod{
	
	private Map<String,String> parameters  = null;
	private NovaEC2 provider = null;
	private String url = null;
	
	public OpenstackJsonMethod(NovaEC2 provider, Map<String,String> parameters) throws Exception{
		this.url = provider.getEc2Url();
		this.parameters = parameters;
		this.provider = provider;
		this.parameters.put(NovaEC2.P_SIGNATURE, provider.signEc2(provider.getContext().getAccessPrivate(), url, parameters));
	}
    
	protected HttpClient getClient() {
        String proxyHost = provider.getContext().getCustomProperties().getProperty("proxyHost");
        String proxyPort = provider.getContext().getCustomProperties().getProperty("proxyPort");
        HttpClient client = new HttpClient();
        
        if( proxyHost != null ) {
            int port = 0;
            
            if( proxyPort != null && proxyPort.length() > 0 ) {
                port = Integer.parseInt(proxyPort);
            }
            client.getHostConfiguration().setProxy(proxyHost, port);
        }
        return client;
    }
    
    public Map<String,Object> getjson() throws CloudException, InternalException {

        try {
            HttpClient client = getClient();
            
            HttpConnectionManagerParams hmps = client.getHttpConnectionManager().getParams();
            
            //the unit is ms 
            hmps.setConnectionTimeout(30000);
            hmps.setSoTimeout(120000); 
          
            StringBuilder paramString = new StringBuilder();
            TreeSet<String> keys = new TreeSet<String>();
            
            keys.addAll(parameters.keySet());
            for( String key : keys ) {
                if( !key.equalsIgnoreCase("signature") ) {
                    if( paramString.length() > 0 ) {
                        paramString.append("&");
                    }
                    paramString.append(key);
                    paramString.append("=");
                    try {
                        paramString.append(URLEncoder.encode(parameters.get(key), "utf-8"));
                    }
                    catch( UnsupportedEncodingException e ) {
                        throw new InternalException(e);
                    }
                }
            }
           paramString.append("&Signature=");
           try {
               paramString.append(URLEncoder.encode(parameters.get("Signature"), "utf-8"));
            }
           catch( UnsupportedEncodingException e ) {
               throw new InternalException(e);
            }
           
           GetMethod get = new GetMethod(url + "/?" + paramString.toString());
             
			try {
				get.addRequestHeader("Content-Type", "application/json; charset=utf-8");

				client.executeMethod(get);

				JSONObject obj = JSONObject.fromObject(get.getResponseBodyAsString());
				Map<String, Object> values = JsonUtils.allValues(obj, true);

				
				Logger.debug("return json: %s", values);

				return values;

			} finally {
				get.releaseConnection();
			}
        }
        
       catch(Exception e) {
    	   throw new CloudException("Exception: " + e.getMessage());    	   
        }
    }

}
