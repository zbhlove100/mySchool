package service.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jobs.AsyncJob;
import models.Account;
import models.Cloudprovider;
import models.Domain;
import models.DomainCloudprovider;
import models.Quota;
import models.spec.Message;

// Created by Liubisheng
public class CloudstackAdmin {

	private String providerId;	
	private CloudstackJsonCall cscs;

	public CloudstackAdmin(String providerId) throws Exception{
		this.providerId = providerId;
		this.cscs = new CloudstackJsonCall(providerId);		
	}
	
	public CloudstackAdmin(Cloudprovider provider) throws Exception{
		this.providerId = provider.id.toString();
		this.cscs = new CloudstackJsonCall(provider);		
	}
	
    public String getAccountType(String role){
    	//Specify 0 for user, 1 for root admin, and 2 for domain admin    	
    	if("root".equals(role)){
    		return "1";
    	}else if("domainadmin".equals(role)){
    		return "2";
    	}else{
    		return "0";
    	}
    }
	
    public List<Map> queryDomains(){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	Map result = cscs.call("listDomains", params);
    	List<Map> domains = (List)result.get("domain"); 
    	return domains==null? null: domains;
	}
	
	public Map queryDomain(String name){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("name", name);
    	Map result = cscs.call("listDomains", params);
    	List<Map> domains = (List)result.get("domain"); 
    	return domains==null? null: domains.get(0);
	}
	
	public Map createDomain(Domain domain){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("name", domain.name);
    	Map result = cscs.call("createDomain", params);
    	return (Map)result.get("domain");
	}
	
	public Map updateDomain(String implid, Domain domain){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("id", implid);
    	params.put("name", domain.name);
    	Map result = cscs.call("updateDomain", params);

    	return (Map)result.get("domain");
	}
	
	public String deleteDomain(Domain domain){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	
    	DomainCloudprovider dcp = domain.getDomainCloudprovider(providerId);
    	
    	if(dcp !=null){
    		params.put("id", dcp.impldomainId);
    		Map result = cscs.call("deleteDomain", params);
    		return (String)result.get("success");
    	}
    	return null;
	}
	
	
	public Map setQuota(Quota quota){
		
    	Map<String,String> params = new HashMap<String,String>();
    	
    	DomainCloudprovider dcp = quota.domain.getDomainCloudprovider(quota.cloudprovider.id.toString());
    	
    	params.put("domainid", dcp.impldomainId);
    	
    	params.put("resourcetype", "0");
    	params.put("max", ""+quota.instanceLimit);
    	Map result = cscs.call("updateResourceLimit", params);
    	
    	params.put("resourcetype", "1");
    	params.put("max", ""+quota.ipLimit);
    	result = cscs.call("updateResourceLimit", params);
    	
    	params.put("resourcetype", "2");
    	params.put("max", ""+quota.volumeLimit);
    	result = cscs.call("updateResourceLimit", params);
    	
    	params.put("resourcetype", "3");
    	params.put("max", ""+quota.snapshotLimit);
    	result = cscs.call("updateResourceLimit", params);
    	
    	params.put("resourcetype", "4");
    	params.put("max", ""+quota.templateLimit);
    	result = cscs.call("updateResourceLimit", params);
    	
    	return (Map)result.get("resourcelimit");
    	
	}	
	
	public Map updateQuota(Quota quota){
		
    	Map<String,String> params = new HashMap<String,String>();
    	
    	DomainCloudprovider dcp = quota.domain.getDomainCloudprovider(quota.cloudprovider.id.toString());
    	
    	params.put("domainid", dcp.impldomainId);
    	
    	params.put("resourcetype", "0");
    	Map result = cscs.call("updateResourceCount", params);
    	quota.instanceLimit = Integer.parseInt((String)result.get("resourcecount"));
    	
    	params.put("resourcetype", "1");
    	params.put("max", ""+quota.ipLimit);
    	result = cscs.call("updateResourceCount", params);
    	quota.ipLimit = Integer.parseInt((String)result.get("resourcecount"));
    	
    	params.put("resourcetype", "2");
    	params.put("max", ""+quota.volumeLimit);
    	result = cscs.call("updateResourceCount", params);
    	quota.volumeLimit = Integer.parseInt((String)result.get("resourcecount"));
    	
    	params.put("resourcetype", "3");
    	params.put("max", ""+quota.snapshotLimit);
    	result = cscs.call("updateResourceCount", params);
    	quota.snapshotLimit = Integer.parseInt((String)result.get("resourcecount"));
    	
    	params.put("resourcetype", "4");
    	params.put("max", ""+quota.templateLimit);
    	result = cscs.call("updateResourceCount", params);
    	quota.templateLimit = Integer.parseInt((String)result.get("resourcecount"));
    	
    	quota.save();
    	
    	return (Map)result.get("resourcecount");
    	
	}	
	
	public Map queryAccount(String impldomainId,Account account){
		
		Map<String,String> params = new HashMap<String,String>();
    	params.put("domainid", impldomainId);
    	params.put("name", account.username);
    	Map result = cscs.call("listAccounts", params);
    	
    	List<Map> accounts = (List)result.get("account");
    	
    	return accounts == null? null: accounts.get(0);
    	
	}
	
	public Map generateKeys(String impluserId){	
		
		Map<String,String> params = new HashMap<String,String>();
		
		params.put("id", impluserId);
		
		Map<String,Object> result = cscs.call("registerUserKeys", params);
		
		Map<String,Object> implkeys = (Map)result.get("userkeys");
		
		return implkeys;
	}
	
	public Map createAccount(String impldomainId,Account account){
		
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("accounttype", getAccountType(account.role.name));
    	params.put("email", account.username);
    	params.put("firstname", account.username);
    	params.put("lastname", account.username);
    	//warning: default hashing algorithm is MD5 for CloudStack, so it's same as CloudPI
    	params.put("password", account.password);
    	params.put("username", account.username);
    	
    	if(account.timezone != null){
    		params.put("timezone", account.timezone);
    	}
    	
    	params.put("domainid", impldomainId);
    	
    	Map result = cscs.call("createAccount", params);
    	
    	Map<String,Object> implaccount = (Map)result.get("account");
    	
	   	if(implaccount != null){
			
	   		List<Map> users = (List<Map>)implaccount.get("user");
			
	   		Map<String,Object> impluser = users.get(0);
	   		Map<String,Object> implkeys = generateKeys((String)impluser.get("id"));
	    	
	    	if(implkeys != null){
	    		implaccount.put("apikey",implkeys.get("apikey"));
	    		implaccount.put("secretkey",implkeys.get("secretkey"));
	    	}
	    	
    	}
    	return implaccount;//(Map)result.get("account");
    	
	}	
	
	public Map updateUser(String impldomainId, String impluserId, Account account,boolean genkeys){
		
    	Map<String,String> params = new HashMap<String,String>();
    	params.put("id", impluserId);
    	
    	params.put("accounttype", getAccountType(account.role.name));
    	params.put("email", account.username);
    	params.put("firstname", account.username);
    	params.put("lastname", account.username);
    	//warning: default hashing algorithm is MD5 for CloudStack, so it's same as CloudPI
    	params.put("password", account.password);
    	params.put("username", account.username);
    	
    	if(account.timezone != null){
    		params.put("timezone", account.timezone);
    	}
    	
    	params.put("domainid", impldomainId);
    	
    	Map result = cscs.call("updateUser", params);
    	
    	Map<String,Object> impluser = (Map)result.get("user");
    	
	   	if(genkeys && impluser != null){
	   		
	   		Map<String,Object> implkeys = generateKeys((String)impluser.get("id"));
	    	
	    	if(implkeys != null){
	    		impluser.put("apikey",implkeys.get("apikey"));
	    		impluser.put("secretkey",implkeys.get("secretkey"));
	    	}
    	}
	   	
    	return impluser;
    	
	}	
	
	public String deleteAccount(String implaccountId){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	
    	params.put("id", implaccountId);
    	Map result = cscs.call("deleteAccount", params);

    	//why? as an async call?
    	//return (String)result.get("success");
    	return (String)result.get("jobid");
	}	

	public Map<String,Object> queryJob(String impljobId){
    	
    	Map<String,String> params = new HashMap<String,String>();
    	
    	params.put("jobid", impljobId);
    	Map result = cscs.call("queryAsyncJobResult", params);
    	
    	return result;
	}
	
	public Map job_deleteAccount(Map inparams){
		
    	Map<String,Object> result = new HashMap<String,Object>();
    	Map<String,String> params = new HashMap<String,String>();
    	
    	params.put("id", (String)inparams.get("implaccountId"));
    	Map accresult = cscs.call("deleteAccount", params);
    	
    	String jobid = (String)accresult.get("jobid");
    	if(jobid == null){
    		result.put(AsyncJob.event_key, new Message(300,"Fail to delete account"));
    	}else{
    		try{
	    		while(true){
	    			Thread.sleep(1000);
	    			
	    			Map<String,Object> jobreturn = queryJob(jobid);
	    			
	    			String jobstatus = (String)jobreturn.get("jobstatus");
	    			
	    			if(jobstatus == null){
	    				result.put(AsyncJob.event_key, new Message(300,"Fail to delete account"));
	    				break;
	    			}
	    			
	    			if(!"0".equals(jobstatus)){
	    				Map jobresult = (Map) jobreturn.get("jobresult");
	    				
	    				if(jobresult.get("errorcode") != null){
	    					result.put(AsyncJob.event_key, new Message(300,"Fail to delete account"));
	    				}
	    				break;
	    			}
	    		}
    		}catch(Exception e){
    			result.put(AsyncJob.event_key, new Message(300,"Fail to delete account"));
    		}
    	}
    	return result;
	}
	
	public void testAPI(){
    	
    	Map<String,String> params = new HashMap<String,String>();
//    	params.put("name", "dsheng-net");
//    	params.put("displaytext", "virtualnet-network");
//    	params.put("networkofferingid", "7");
//    	params.put("zoneid", "1");
//    	params.put("isdefault", "true");
//    	params.put("vlan", "1301");
//    	params.put("gateway", "192.168.13.1");
//    	params.put("netmask", "255.255.255.0");
//    	params.put("startip", "192.168.13.1");
//    	params.put("endip", "192.168.13.254");
//    	params.put("isshared", "true");
//    	
//    	Map result = cscs.call("createNetwork", params);
//    	System.out.println(result);
//    	
		params.put("id", "210");
//    	
    	Map result = cscs.call("listTemplatePermissions", params);
    	System.out.println(result);		
	}	

}
