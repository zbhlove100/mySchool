package service.storage;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import jobs.AsyncJob;

import models.Container;
import models.Object;
import models.spec.Message;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.encryption.Encryption;
import org.dasein.cloud.storage.BlobStoreSupport;
import org.dasein.cloud.storage.CloudStoreObject;
import org.dasein.cloud.storage.FileTransfer;

import play.Play;

import service.BaseService;

public class BlobStorageService extends BaseService {

	private BlobStoreSupport blobStorageSupport = null;
	private static Logger log = LogManager.getLogger(BlobStorageService.class);

	public BlobStorageService(String providerId) throws Exception {
		super(providerId);
		blobStorageSupport = provider.getStorageServices()
				.getBlobStoreSupport();
	}

	public String createBucket(String bucket, boolean findFreeName) throws InternalException, CloudException {

		findFreeName = true;
		bucket = blobStorageSupport.createDirectory(bucket, findFreeName);
		return bucket;
	}

	public Iterable<CloudStoreObject> listBuckets() throws CloudException, InternalException {

		Iterable<CloudStoreObject> storage = null;
			storage = blobStorageSupport.listFiles(null);	
		return storage;
	}

	public Iterable<CloudStoreObject> listFiles(String bucketName)
			throws CloudException, InternalException {
		Iterable<CloudStoreObject> storage = null;
			storage = blobStorageSupport.listFiles(bucketName);
		return storage;
	}

	public FileTransfer downLoad(CloudStoreObject cloudFile, File diskFile)
			throws CloudException, InternalException {
		FileTransfer transfer = null;
			transfer = blobStorageSupport.download(cloudFile, diskFile);
		return transfer;
	}

	public boolean existsBucket(String directroy) throws InternalException, CloudException {
		boolean isExists = false;
			isExists = blobStorageSupport.exists(directroy);
		return isExists;
	}

	public long existsFile(String directory, String fileName, boolean multiPart)
			throws InternalException, CloudException {
		long length = 0L;
			length = blobStorageSupport.exists(directory, fileName, multiPart);
		return length;
	}

	public void deleteBucket(String bucketName) throws CloudException, InternalException {
			blobStorageSupport.clear(bucketName);
	}

	public boolean isPublic(String bucket, String object)
			throws CloudException, InternalException {
		boolean isPublic = false;
			isPublic = blobStorageSupport.isPublic(bucket, object);
		return isPublic;
	}

	public boolean isSubscribed() throws CloudException, InternalException {
		boolean isSubscribed = false;
			isSubscribed = blobStorageSupport.isSubscribed();
		return isSubscribed;
	}

	public void makeDirectoryPublic(String directory) throws InternalException, CloudException {
			blobStorageSupport.makePublic(directory);
	}

	public void makeFilePublic(String directory, String fileName) throws InternalException, CloudException {
			blobStorageSupport.makePublic(directory, fileName);
	}

	public void moveFile(String fromDirectory, String fileName,
			String toDirectory) throws InternalException, CloudException {
			blobStorageSupport.moveFile(fromDirectory, fileName, toDirectory);
	}

	public void removeDirectory(String directory) throws CloudException, InternalException {
			blobStorageSupport.removeDirectory(directory);
	}

	public void removeFile(String directory, String name, boolean multipartFile) throws CloudException, InternalException {
			blobStorageSupport.removeFile(directory, name, multipartFile);
	}

	public String renameDirectory(String oldName, String newName,
			boolean findFreeName) throws CloudException, InternalException {
		String name = null;
			name = blobStorageSupport.renameDirectory(oldName, newName,
					findFreeName);
		return name;
	}

	public void renameFile(String directory, String oldName, String newName) throws CloudException, InternalException {
			blobStorageSupport.renameFile(directory, oldName, newName);
	}

	public void upload(File sourceFile, String directory, String fileName,
			boolean multiPart, Encryption encryption) throws CloudException, InternalException {
			blobStorageSupport.upload(sourceFile, directory, fileName,
					multiPart, encryption);
	}

	public CloudStoreObject copy(CloudStoreObject file,
			CloudStoreObject toDirectory, String copyName)
			throws InternalException, CloudException {
		CloudStoreObject object = null;
			object = blobStorageSupport.copy(file, toDirectory, copyName);
		return object;
	}
	public Map uploadJob(Map inparams){
		System.out.println("starting upload job .........");
		Map result = new HashMap<String, Object>();
		String providerId = (String)inparams.get("providerId");
		String fileName = (String)inparams.get("fileName");
		Container container = (Container)inparams.get("container");
		Encryption encryption = (Encryption) inparams.get("encryption");
		boolean multipart = (Boolean) inparams.get("multipart");
		BlobStorageService storageService = (BlobStorageService) inparams.get("storageService");
		String containerName = container.name;
		File file = new File(Play.applicationPath.getPath()+"/tmp/uploads/"+fileName);
		System.err.print("pid:"+Thread.currentThread().getId());
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);	
		try {
			//BlobStorageService storageService = new BlobStorageService(providerId);
			storageService.upload(file, containerName, fileName, multipart, encryption);
			if(storageService.existsFile(containerName, fileName, multipart)==0||
					storageService.existsFile(containerName, fileName, multipart)==-1){
				result.put(AsyncJob.event_key, new Message(300,"Fail to upload :"+fileName));
			}
			result.put("file",file);
			result.put("container",container);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result.put(AsyncJob.event_key, new Message(300,"Fail to delete upload :"+fileName));
			return result;
		}
		return result;
	}
}
