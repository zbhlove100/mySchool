package service.monitor.host;
/**
 * 
 * @author jiangxuan
 *
 */
public class Host {
	private float cpuUtilization;
	private float diskUtilization;
	private float memoryUtilization;
	private int  memorysize;
	private int disksize;
	private int network;
	private int networkin;
	private int networkout;
	
	public float getCpuUtilization() {
		return cpuUtilization;
	}
	public void setCpuUtilization(float cpuUtilization) {
		this.cpuUtilization = cpuUtilization;
	}
	public float getDiskUtilization() {
		return diskUtilization;
	}
	public void setDiskUtilization(float diskUtilization) {
		this.diskUtilization = diskUtilization;
	}
	public float getMemoryUtilization() {
		return memoryUtilization;
	}
	public void setMemoryUtilization(float memoryUtilization) {
		this.memoryUtilization = memoryUtilization;
	}
	public int getMemorysize() {
		return memorysize;
	}
	public void setMemorysize(int memorysize) {
		this.memorysize = memorysize;
	}
	public int getDisksize() {
		return disksize;
	}
	public void setDisksize(int disksize) {
		this.disksize = disksize;
	}
	public int getNetwork() {
		return network;
	}
	public void setNetwork(int network) {
		this.network = network;
	}
	public int getNetworkin() {
		return networkin;
	}
	public void setNetworkin(int networkin) {
		this.networkin = networkin;
	}
	public int getNetworkout() {
		return networkout;
	}
	public void setNetworkout(int networkout) {
		this.networkout = networkout;
	}
}
