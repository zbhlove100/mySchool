package service.monitor.host;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hyperic.hq.hqapi1.AgentApi;
import org.hyperic.hq.hqapi1.MetricApi;
import org.hyperic.hq.hqapi1.MetricDataApi;
import org.hyperic.hq.hqapi1.ResourceApi;
import org.hyperic.hq.hqapi1.types.AgentResponse;
import org.hyperic.hq.hqapi1.types.DataPoint;
import org.hyperic.hq.hqapi1.types.Metric;
import org.hyperic.hq.hqapi1.types.MetricData;
import org.hyperic.hq.hqapi1.types.MetricDataResponse;
import org.hyperic.hq.hqapi1.types.MetricsResponse;
import org.hyperic.hq.hqapi1.types.Resource;
import org.hyperic.hq.hqapi1.types.ResourcesResponse;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;

public class HostService extends MonitorBaseService{
	public HostService(){
		
	}
	public HostService(String serverIp,int serverPort,String userName,String password){
		super(serverIp,serverPort,userName,password);
	}
	public String getMetricData(String[] metricIds,long lInterval,long endTime){
		long startTime =endTime-lInterval;
		StringBuilder result=new StringBuilder("date,");
		MetricApi metricApi=this.getProvider().getMetricApi();
		MetricDataApi metricDataApi=this.getProvider().getMetricDataApi();
		List<Map<String,String>> resultlist=new ArrayList();
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd HH:mm");
		Map<String,String> tempMap=new HashMap();
		try {
			for(String metricId:metricIds){
				Metric m=metricApi.getMetric(Integer.parseInt(metricId)).getMetric();
				//System.out.println(/60/1000);
				MetricDataResponse mdr=metricDataApi.getData(m,startTime,endTime);
				MetricData md=mdr.getMetricData();
				result.append(md.getResourceName()).append(",");
				//tempList.add(md.getResourceName());
				long n=lInterval/m.getInterval();
				if(tempMap.size()==0){
					for(int i=0;i<n;i++){
						tempMap.put(sdf.format(new java.util.Date(startTime+i*m.getInterval())), null);
					}
				}
				if(md!=null){
					List<DataPoint> dataList=md.getDataPoint();
					for(DataPoint dataPoint:dataList){
						String key=sdf.format(new java.util.Date(dataPoint.getTimestamp()));
						String value=tempMap.get(key);
						tempMap.remove(key);
						if(value!=null){
							value=value+","+dataPoint.getValue();
						}else{
							value=""+dataPoint.getValue();
						}
						tempMap.put(key, value);
						
					}
				}
				resultlist.add(tempMap);
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		result=new StringBuilder(result.substring(0, result.length()-1));
		result.append("\r\n");
		//for(Map<String,String> map:resultlist){
			Set<String> keySet=tempMap.keySet();
			for(String key:keySet){
				result.append(key).append(",").append(tempMap.get(key)).append("\r\n");
			}
		//}
/*		for(){
			for(Map<String,String> map:resultlist){
				Set<String> keySet=map.keySet();
				for(String key:keySet){
					result.append(key).append(",").append(map.get(key)).append("\\n");
				}
			}
		}*/
		return result.toString();
		
	}
	public TimeSeriesCollection getMetricData2(String[] metricIds,long lInterval,long endTime){
		long startTime =endTime-lInterval;
		TimeSeriesCollection dataset=new TimeSeriesCollection();
		MetricApi metricApi=this.getProvider().getMetricApi();
		MetricDataApi metricDataApi=this.getProvider().getMetricDataApi();
		try {
			for(String metricId:metricIds){
				Metric m=metricApi.getMetric(Integer.parseInt(metricId)).getMetric();
				//System.out.println(/60/1000);
				MetricDataResponse mdr=metricDataApi.getData(m,startTime,endTime);
				MetricData md=mdr.getMetricData();
				TimeSeries series = new TimeSeries(md.getResourceName());
				long n=lInterval/m.getInterval();
				for(int i=0;i<n;i++){
					series.add(new Minute(new java.util.Date(startTime+i*m.getInterval())), 0);
				}
				if(md!=null){
					List<DataPoint> dataList=md.getDataPoint();
					for(DataPoint dataPoint:dataList){
						series.addOrUpdate(new Minute(new java.util.Date(dataPoint.getTimestamp())), dataPoint.getValue());
					}
				}
				dataset.addSeries(series);
			}
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return dataset;
		
	}
	public List<DataPoint> getMetricData(String metricId,long startTime,long endTime){
		MetricApi metricApi=this.getProvider().getMetricApi();
		MetricDataApi metricDataApi=this.getProvider().getMetricDataApi();
		try {
			Metric m=metricApi.getMetric(Integer.parseInt(metricId)).getMetric();
			MetricDataResponse mdr=metricDataApi.getData(m,startTime,endTime);
			MetricData md=mdr.getMetricData();
			if(md!=null){
				List<DataPoint> dataList=md.getDataPoint();
				return dataList;
			}
			return null;
		} catch (NumberFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
	public Map<String,List<Integer>> getMetricIdByIp(String ip){
		Map<String,List<Integer>> result=new HashMap<String,List<Integer>>();
		try {
			ResourceApi resourceApi=this.getProvider().getResourceApi();
			AgentApi agentApi=this.getProvider().getAgentApi();
			AgentResponse agentResponse=agentApi.getAgent(ip,2144);
			ResourcesResponse resourceResponses=resourceApi.getResources(agentResponse.getAgent(), true, true);
			List<Resource> resourceList=resourceResponses.getResource();
			List<Integer> cpuList=new ArrayList<Integer>();
			List<Integer> diskWritesList=new ArrayList<Integer>();
			List<Integer> diskReadsList=new ArrayList<Integer>();
			List<Integer> bitTransmittedList=new ArrayList<Integer>();
			List<Integer> bitReceivedList=new ArrayList<Integer>();
			for(Resource temp:resourceList){
				cpuList.addAll(this.getResourceId(temp,"CPU","Cpu Usage"));
				diskWritesList.addAll(this.getResourceId(temp,"FileServer Mount","Disk Writes per Minute"));
				diskReadsList.addAll(this.getResourceId(temp,"FileServer Mount","Disk Reads per Minute"));
				bitTransmittedList.addAll(this.getResourceId(temp,"NetworkServer Interface","Bits Transmitted per Second"));
				bitReceivedList.addAll(this.getResourceId(temp,"NetworkServer Interface","Bits Received per Second"));
			}
			result.put("CPU", cpuList);
			result.put("diskWrites", diskWritesList);
			result.put("diskReads", diskReadsList);
			result.put("bitTransmitted", bitTransmittedList);
			result.put("bitReceived", bitReceivedList);
			return result;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public List<Integer> getResourceId(Resource resource,String resourcePrototype,String metrics) throws IOException{
		List<Integer> result=new ArrayList<Integer>();
		MetricApi metricApi=this.getProvider().getMetricApi();
		List<Resource> rr=resource.getResource();
		if(rr!=null&&rr.size()>0){
			for(Resource res:rr){
				result.addAll(getResourceId(res,resourcePrototype,metrics));
			}
		}else{
			if(resource.getResourcePrototype().getName().equals(resourcePrototype)){
				MetricsResponse metricsResponse=metricApi.getMetrics(resource,true);
				List<Metric> ll=metricsResponse.getMetric();
				for(Metric m:ll){
					if (metrics.equals(m.getName())){
						result.add(m.getId());
						break;
					}
				}
			}
		}
		return result;
	}
	/**
	 * update server's agent_ip column
	 * @param server
	 * @return
	 */
	public Map<String,List<Integer>> getMetricId(String qn){
		Map<String,List<Integer>> result=new HashMap<String,List<Integer>>();
		//int[] result=new int[]{0,0,0,0,0};
		try {
			result.put("CPU", this.getResourceId(qn,"CPU","Cpu Usage"));
			result.put("diskWrites", this.getResourceId(qn,"FileServer Mount","Disk Writes per Minute"));
			result.put("diskReads", this.getResourceId(qn,"FileServer Mount","Disk Reads per Minute"));
			result.put("bitTransmitted", this.getResourceId(qn,"NetworkServer Interface","Bits Transmitted per Second"));
			result.put("bitReceived", this.getResourceId(qn,"NetworkServer Interface","Bits Received per Second"));
			return result;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<Integer> getResourceId(String name,String resourcePrototype,String metrics) throws IOException{
		List<Integer> result=new ArrayList<Integer>();
		ResourceApi resourceApi=this.getProvider().getResourceApi();
		MetricApi metricApi= this.getProvider().getMetricApi();
		
		ResourcesResponse resourceResponse=resourceApi.getResources(resourceApi.getResourcePrototype(resourcePrototype).getResourcePrototype(), false, false);
		List<Resource> resourceList=resourceResponse.getResource();
		for(Resource resource:resourceList){
			if(resource.getName().indexOf(name)!=-1){//&&"localhost".equals(resource.get)
				MetricsResponse metricsResponse=metricApi.getMetrics(resource,true);
				List<Metric> ll=metricsResponse.getMetric();
				for(Metric m:ll){
					if(metrics.equals(m.getName())){
						result.add(m.getId());
					}
				}
			}
		}
		return result;
	}
	public static void main(String[] args){
		//HostService host=new HostService("127.0.0.1",7080,"hqadmin","hqadmin");
		//host.getMetricId(null,null);
		//host.getMetricData();
		//host.getCpuUtilization();
		/*Map<String,TimeSeriesCollection> result=host.getDiskReadAndWriteBytes();*/
		long lInterval=60*60*1000*1;
		HostService host=new HostService("127.0.0.1",7080,"hqadmin","hqadmin");
		Map<String,List<Integer>> metricId=host.getMetricIdByIp("50.57.175.223");
		StringBuffer str=new StringBuffer("");
		for(int i:metricId.get("CPU")){
			str.append(i).append(",");
		}
		str.append(";");
		for(int i:metricId.get("diskWrites")){
			str.append(i).append(",");
		}
		str.append(";");
		for(int i:metricId.get("diskReads")){
			str.append(i).append(",");
		}
		str.append(";");
		for(int i:metricId.get("bitTransmitted")){
			str.append(i).append(",");
		}
		str.append(";");
		for(int i:metricId.get("bitReceived")){
			str.append(i).append(",");
		}
		System.out.println(str.toString());
		/*for(int i:tt){
			System.out.println(i);
		}*/
		/*10811
		10695
		10690
		10788
		10786*/
		long endtime=System.currentTimeMillis();
		
		TimeSeriesCollection dataset=host.getMetricData2(new String[]{"28380"}, lInterval, endtime);
		/* TimeSeries series = new TimeSeries("test", org.jfree.data.time.Minute.class);
		 long time=list.get(0).getTimestamp();
		for(DataPoint dataPoint:list){
			series.add(new Minute(new java.util.Date(dataPoint.getTimestamp())), dataPoint.getValue());
			if(dataPoint.getTimestamp()<time){
				time=dataPoint.getTimestamp();
			}
		}
		
		series.add(new Minute(new java.util.Date(time-5*60*1000)), 0);
		series.add(new Minute(new java.util.Date(time-10*60*1000)), 0);
		series.add(new Minute(new java.util.Date(time-15*60*1000)), 0);
		series.add(new Minute(new java.util.Date(time-20*60*1000)), 0);
		series.add(new Minute(new java.util.Date(time-25*60*1000)), 0);
		 TimeSeriesCollection dataset=new TimeSeriesCollection();
		dataset.addSeries(series);*/
		JFreeChart chart = ChartFactory.createTimeSeriesChart("test", "time", "value",
				dataset, true, true, false);
/*		XYPlot plot=chart.getXYPlot();
		DateAxis domainAxis=(DateAxis)plot.getDomainAxis();
		domainAxis.setTickUnit(new DateTickUnit(DateTickUnit.MINUTE,5,new SimpleDateFormat("HH:mm")));
		chart.setBorderVisible(true);*/
		ChartFrame frame = new ChartFrame("First", chart);
		frame.pack();
		frame.setVisible(true);
		/*host.createPlatform();*/
		//host.getMetricData();
	//	test();
	}
}
