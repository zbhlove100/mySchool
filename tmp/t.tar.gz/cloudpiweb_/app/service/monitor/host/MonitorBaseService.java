package service.monitor.host;

import org.hyperic.hq.hqapi1.HQApi;
/**
 * 
 * @author jiangxuan
 *this class will provide the connection to hqserver
 */
public class MonitorBaseService {
	private HQApi provider;
	public MonitorBaseService(){
		
	}
	public HQApi getProvider() {
		return provider;
	}
	public void setProvider(HQApi provider) {
		this.provider = provider;
	}
	public MonitorBaseService(String serverIp,int serverPort,String userName,String password){
		provider= new HQApi(serverIp, serverPort, false, userName, password);
	}
}
