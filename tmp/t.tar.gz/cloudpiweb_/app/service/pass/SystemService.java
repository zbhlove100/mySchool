package service.pass;

import java.util.List;

import com.samsung.cloudpi.client.cf.CloudBean;
import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.CloudService;

import models.Domain;
import models.PassApplication;
import models.Target;
import models.Account;
import models.spec.CurrentUser;

public class SystemService {
	
	/*
	 * find out all the binded system-service of the app specified by appId, and 
	 * create these services(system-service) on the new target, but don't bind these service.
	 */
	public static void cloneService( long appId, long toTargetId) throws Exception{
		PassApplication app = null;
		Target toTarget = null;
		Target fromTarget = null;
		CloudBean  cloudBean = null;
		CloudFoundryProxy cf = null;
		Account account = null;
		List<CloudService> fromTargetBindedService = null;
		List<CloudService> toTargetBindedService = null;
		String tempName = null;
		
		
		app = PassApplication.findById( appId );
		toTarget = Target.findById( toTargetId );
		fromTarget = app.target;
		account = Account.findById( app.accountId );
		tempName = account.username + "@samsung.com";
		
		//get all the binded system-service of the app's target specified by appId
		cloudBean = new CloudBean(tempName, account.passwordBase64, fromTarget.targetUrl);
		cf = new CloudFoundryProxy(cloudBean);
		fromTargetBindedService = ApplicationService.getAllBindServiceListByApp(cf, app);
		
		//get all the binded system-service of the new target specified by toTargetId
		cloudBean = new CloudBean(tempName, account.passwordBase64, toTarget.targetUrl);
		cf = new CloudFoundryProxy(cloudBean);
		toTargetBindedService = ApplicationService.getAllBindServiceListByApp(cf, app);
		
		//find out which service(system service) the new target doesn't have. 
		fromTargetBindedService.removeAll( toTargetBindedService );
		
		for(CloudService cs : fromTargetBindedService){
			models.SystemService modelService = null;
			CloudService restService = null;
			String vendor = cs.getVendor();
			String type = getServiceTypeByVendor(vendor);
			String version = getServiceVersionByVendor(vendor);
			String newServiceName = vendor+"_"+account.username+"_"+toTarget.name+"_"+cs.getName().substring( cs.getName().lastIndexOf("_")+1 );
			
			//create service on toTarget
			restService = new CloudService();
			restService.setName(newServiceName);
			restService.setTier("free");
			restService.setType(type);
			restService.setVendor(vendor);
			restService.setVersion(version);
			cf.createService(restService); // call rest api
			
			//create in DB
			modelService = new models.SystemService(newServiceName, type, version, "free");
			modelService.owned_by_account = account;
			modelService.owned_by_domain = account.domain;
			modelService.owned_by_target = toTarget;
			modelService.save();
			
		}
	}
	
	public static String getServiceTypeByVendor(String vendor){
		String type = "";
		if ( vendor.equalsIgnoreCase("mysql") ) {
			type = "database";
		} else if ( vendor.equalsIgnoreCase("mongodb") ) {
			type = "key-value";
		} else if ( vendor.equalsIgnoreCase("redis") ) {
			type = "key-value";
		} else if ( vendor.equalsIgnoreCase("membase") ) {
			type = "membase";
		} else if ( vendor.equalsIgnoreCase("rabbitmq") ) {
			type = "rabbitmq";
		} else if ( vendor.equalsIgnoreCase("neo4j") ) {
			type = "nosql-server";
		} else if ( vendor.equalsIgnoreCase("cassandra") ) {
			type = "nosql-server";
		} else if ( vendor.equalsIgnoreCase("kafka") ) {
			type = "message-queue";
		} else if ( vendor.equalsIgnoreCase("postgresql") ) {
			type = "database";
		} else if ( vendor.equalsIgnoreCase("voldemort") ) {
			type = "nosql-server";
		}
		return type;
	}
	
	public static String getServiceVersionByVendor(String vendor){
		String version = "";
		if ( vendor.equalsIgnoreCase("mysql") ) {
			version = "5.1";
		} else if ( vendor.equalsIgnoreCase("mongodb") ) {
			version = "1.8";
		} else if ( vendor.equalsIgnoreCase("redis") ) {
			version = "2.2";
		} else if ( vendor.equalsIgnoreCase("membase") ) {
			version = "1.7.1";
		} else if ( vendor.equalsIgnoreCase("rabbitmq") ) {
			version = "2.4";
		} else if ( vendor.equalsIgnoreCase("neo4j") ) {
			version = "1.4";
		} else if ( vendor.equalsIgnoreCase("cassandra") ) {
			version = "1.0.1";
		} else if ( vendor.equalsIgnoreCase("kafka") ) {
			version = "0.6";
		} else if ( vendor.equalsIgnoreCase("postgresql") ) {
			version = "9.0";
		} else if ( vendor.equalsIgnoreCase("voldemort") ) {
			version = "0.90.1";
		}
		return version;
	}
	
	public static void main(String args[]){
		String s = "mongodb_ruanzhimin_target1_scalademo";
		System.out.println( s.substring( s.lastIndexOf("_")+1 ) );
	}
}
