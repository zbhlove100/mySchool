package service.pass;

import java.util.List;
import java.util.Map;

import service.networking.DnsService;

import models.Setting;

public class DNSService {
	
	public static String DNS_API_ADDRESS = "";
	public static String DNS_ZONE_ID = "";
	private static final String _DNS_API_ADDRESS = "DNS_API_ADDRESS";
	private static final String _DNS_ZONE_ID = "DNS_ZONE_ID";
	private static final String _VIEW = "view";
	private static List<Setting> VIEWS = null;
	private static DnsService dnsService;
	
	static {
		Setting setting = null;
		
		setting = Setting.find("from Setting where name=?", _DNS_API_ADDRESS ).first();
		if(setting!=null)
			DNS_API_ADDRESS = setting.value;
		
		setting = Setting.find("from Setting where name=?", _DNS_ZONE_ID ).first();
		if(setting!=null)
			DNS_ZONE_ID = setting.value;
		
		VIEWS = Setting.find("from Setting where name=?", _VIEW ).fetch();
		dnsService = new DnsService(DNS_API_ADDRESS);
	}
	
	public static String createARecordInAllViews(String hostname, String IP) {
		String result = "";
		for(Setting setting :VIEWS)
		{
			String viewValue = setting.value;
			Map<String, String> tmp = dnsService.createRecord(DNS_ZONE_ID, "A", hostname, "86400" ,IP, viewValue);
			
			result = result + tmp.get("id") + ";";
		}
		return result;
	}
	
	public static String createARecordInOneView(String hostname,String IP, String view){	
		Map<String, String> tmp = dnsService.createRecord(DNS_ZONE_ID, "A", hostname, "86400" , IP, view);
		return tmp.get("id");
	}
	
	public static void deleteARecord(String id){
		dnsService.deleteRecord( id );
	}
	
	/**
	 * 
	 * @param ids : 1;2;3
	 */
	public static void deleteRecords(String recordIds){
		String viewIds[] = recordIds.split(";");
		for (int j=0; j< viewIds.length ; j++){
			if( viewIds[j].contains("null") )
				continue;
			dnsService.deleteRecord( viewIds[j] );
		}		
	}
	
}
