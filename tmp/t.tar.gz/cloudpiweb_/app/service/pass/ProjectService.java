package service.pass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import play.Logger;

import models.Account;
import models.PassApplication;
import models.Project;
import models.ProjectEvent;
import models.Setting;
import models.spec.Where;
import utils.UserNameAnalyzer;

import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.git.CommitsInfo;
import com.samsung.cloudpi.client.git.CreateGitRepoRequest;
import com.samsung.cloudpi.client.git.CreateGitRepoResponse;
import com.samsung.cloudpi.client.git.DeleteGitRepoRequest;
import com.samsung.cloudpi.client.git.DeleteGitRepoResponse;
import com.samsung.cloudpi.client.git.GitAccount;
import com.samsung.cloudpi.client.git.GitServerProxy;
import com.samsung.cloudpi.client.git.ListBranchesRequest;
import com.samsung.cloudpi.client.git.ListBranchesResponse;
import com.samsung.cloudpi.client.git.ListCommitsByBranchRequest;
import com.samsung.cloudpi.client.git.ListCommitsByBranchResponse;
import com.samsung.cloudpi.client.git.ListCommitsByTagRequest;
import com.samsung.cloudpi.client.git.ListCommitsByTagResponse;
import com.samsung.cloudpi.client.git.ListTagsRequest;
import com.samsung.cloudpi.client.git.ListTagsResponse;
import com.samsung.cloudpi.client.git.ProjectInfo;

public class ProjectService {

	public static List<String> getBranchsByProjectName(GitAccount gitAccount,
			String projectName) {

		GitServerProxy proxy = new GitServerProxy(gitAccount);
		ListBranchesRequest brequest = new ListBranchesRequest();
		brequest.setUsername(gitAccount.getUsername());
		brequest.setPassword(gitAccount.getPassword());
		brequest.setProjectName(projectName);
		ListBranchesResponse bres = proxy.listBranches(brequest);

		return bres.getList();
	}
	
	public static List<String> getBranchsByProjectId(GitAccount gitAccount,
			Long projectId) {

		Project pro=Project.findById(projectId);
		List<String> result=getBranchsByProjectName(gitAccount,pro.name);
		return result;
	}

	public static List<String> getTagsByProjectName(GitAccount gitAccount,
			String projectName) {

		GitServerProxy proxy = new GitServerProxy(gitAccount);
		ListTagsRequest trequest = new ListTagsRequest();
		trequest.setUsername(gitAccount.getUsername());
		trequest.setPassword(gitAccount.getPassword());
		trequest.setProjectName(projectName);
		ListTagsResponse tres = proxy.listTags(trequest);

		return tres.getList();
	}
	
	public static List<String> getTagsByProjectId(GitAccount gitAccount,
			Long projectId) {

		Project pro=Project.findById(projectId);
		List<String> result=getTagsByProjectName(gitAccount,pro.name);
		return result;
	}

	public static List<CommitsInfo> queryCommitInfoByTag(GitAccount gitAccount,
			String projectName, String tagName) {
		GitServerProxy proxy = new GitServerProxy(gitAccount);
		ListCommitsByTagRequest trequest = new ListCommitsByTagRequest();
		trequest.setUsername(gitAccount.getUsername());
		trequest.setPassword(gitAccount.getPassword());
		trequest.setProjectName(projectName);
		trequest.setTag(tagName);
		ListCommitsByTagResponse tres = proxy.listCommitsByTag(trequest);

		return tres.getList();

	}

	public static List<CommitsInfo> queryCommitInfoByBranch(GitAccount gitAccount,
			String projectName, String branchName) {
		GitServerProxy proxy = new GitServerProxy(gitAccount);
		ListCommitsByBranchRequest brequest = new ListCommitsByBranchRequest();
		brequest.setUsername(gitAccount.getUsername());
		brequest.setPassword(gitAccount.getPassword());
		brequest.setProjectName(projectName);
		brequest.setBranches(branchName);
		ListCommitsByBranchResponse bres = proxy.listCommitsByBranch(brequest);

		return bres.getList();

	}

	public static List<ProjectEvent> getEventsByProjectId(Long projectId) {
		List<ProjectEvent> events = ProjectEvent.find("byProject.id", projectId)
				.fetch();
		return events;
	}
	

	public static void createProject(GitAccount gitAccount, Project project) {

		ProjectInfo projectInfo = new ProjectInfo();
		projectInfo.setProjectName(project.name);
		projectInfo.setFramework(project.framework);
		projectInfo.setRuntime(project.runtime);
		
		//create git repo
		String gitURL = createGitRepo(gitAccount, projectInfo);

		project.gitUrl = gitURL;
		
		//db save
		project.save();

	}	

	public static String createGitRepo(GitAccount gitAccount, ProjectInfo projectInfo) {				
		
		GitServerProxy proxy = new GitServerProxy(gitAccount);
		CreateGitRepoRequest requestRepo = new CreateGitRepoRequest();
		requestRepo.setGitAccount(gitAccount);

		requestRepo.setProjectInfo(projectInfo);
		CreateGitRepoResponse res = proxy.CreateGitRepo(requestRepo);

		return res.getUrl();

	}

	public static boolean deleteGitRepo(GitAccount gitAccount, String projectName) {

		GitServerProxy proxy = new GitServerProxy(gitAccount);
		DeleteGitRepoRequest ret = new DeleteGitRepoRequest();

		ProjectInfo projectInfo = new ProjectInfo();
		projectInfo.setProjectName(projectName);

		ret.setGitAccount(gitAccount);
		ret.setProjectInfo(projectInfo);
		DeleteGitRepoResponse rest = proxy.deleteGitRepo(ret);
		return rest.isResult();
	}

	public static Project getProjectBaseInfoByProjectId(Long projectId) {
		Project p = Project.findById(projectId);
		return p;
	}

	public  static List<Project> getProjectList(Long domainId, Long userId,String projectName) {
		List<Project> projects = new ArrayList<Project>();
		Where where = new Where();

		if (domainId != null) {
			where.addValue("domain_id=", domainId);
		}

		if (userId != null) {
			where.addValue("account_id=", userId);
		}
		
		if (projectName != null&&!projectName.equals("")) {
			where.addValue("name like", "%"+projectName+"%");
		}

		projects = Project.find(where.where(), where.paramsarr()).fetch();
		return projects;

	}
	
	public static void deleteProjectsByOneUser(Long userId,String userName,String password){
		List<Project> projects=Project.find("byAccountId", userId).fetch();
		
		for(Project pro:projects){
			deleteOneProject(pro,userName,password);
		}
		
	}
	
	public static void deleteProjectsByOneUser(Account account){
		List<Project> projects=Project.find("byAccountId", account.id).fetch();
		
		for(Project pro:projects){
			deleteOneProject(pro,account.username,account.passwordBase64);
		}
		
	}
	
	public static void deleteProjectByProjectId(Long projectId,String userName,String password){
		Project pro=Project.findById(projectId);
		deleteOneProject(pro,userName,password);
						
	}
	
	public static void deleteOneProject(Project  project,	String userName, String password) {

		GitAccount gitAccount = getGitAccount(userName, password,
				getGitServerURL());
		List<PassApplication> apps=project.applications;
		ApplicationService service=new ApplicationService();
		
		for(PassApplication app:apps){
			service.deleteApplicationByAppId( app.id);
		}
		
		deleteGitRepo(gitAccount, project.name);
		
		project.delete();
				
	}
	
	
	public static void deletePassDBInfoByOneUser(Long userId){
		List<Project> projects=Project.find("byAccountId", userId).fetch();
		for(Project pro:projects){			
			pro.delete();
		}		
	}
	
	
	public static void deleteEventsByProjectId(Long projectId) {
		List<ProjectEvent> events = ProjectEvent.find("byProjectId", projectId)
				.fetch();
		for (ProjectEvent event : events) {
			event.delete();
		}

	}	

	public static GitAccount getGitAccount(String userName, String password,
			String gitServerURL) {

		GitAccount gitAccount = new GitAccount();
		try {
		gitAccount.setUsername(UserNameAnalyzer.analyzeUserName(userName,"git"));
		gitAccount.setPassword(password);
		gitAccount.setCloudControllerUrl(new URL(gitServerURL));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

		return gitAccount;
	}
		

	public static GitAccount getGitAccount(Account account, String gitServerURL) {

		return getGitAccount(account.username, account.passwordBase64,
				gitServerURL);

	}
	
	public static String getGitServerURL(){
		Setting setting=Setting.find("byName", "GIT_SERVER").first();
		return setting.value;
	}
	
	
}
