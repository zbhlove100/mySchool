package service.pass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import play.Logger;

import models.Account;
import models.AppEnvironment;
import models.DNS;
import models.Domain;
import models.DomainTarget;
import models.PassApplication;
import models.PassApplicationService;
import models.Project;
import models.ProjectEvent;
import models.Target;
import models.spec.CurrentUser;
import models.spec.Where;
import utils.PassEventWriter;
import utils.UserNameAnalyzer;

import com.samsung.cloudpi.client.cf.CloudBean;
import com.samsung.cloudpi.client.cf.CloudFoundryException;
import com.samsung.cloudpi.client.cf.CloudFoundryProxy;
import com.samsung.cloudpi.client.cf.lib.ApplicationStats;
import com.samsung.cloudpi.client.cf.lib.CloudApplication;
import com.samsung.cloudpi.client.cf.lib.CloudService;
import com.samsung.cloudpi.client.cf.lib.DeploymentInfo;
import com.samsung.cloudpi.client.cf.lib.InstanceStats;
import com.samsung.cloudpi.client.git.CreateGitAccountRequest;
import com.samsung.cloudpi.client.git.CreateGitAccountResponse;
import com.samsung.cloudpi.client.git.DeleteGitAccountRequest;
import com.samsung.cloudpi.client.git.DeleteGitAccountResponse;
import com.samsung.cloudpi.client.git.GitAccount;
import com.samsung.cloudpi.client.git.GitServerProxy;

public class ApplicationService {

	/**
	 * 
	 * @param userName
	 * @param password
	 * @param cfURL
	 * @return
	 */

	public static CloudFoundryProxy getCloudBeanProxy(String userName,
			String password, String targetURL) {

		CloudBean cloudBean = new CloudBean(UserNameAnalyzer.analyzeUserName(
				userName, "cf"), password, targetURL);
		CloudFoundryProxy cfp = null;

		//get cloudfoundry proxy
		try {
			cfp = new CloudFoundryProxy(cloudBean);
			Logger.info(">>  Get cloud proxy: "+targetURL+" success!!");
		} catch (CloudFoundryException e) {
			Logger.error(">> Getting cloud proxy: "+targetURL+" has error!!", e);
		}
		return cfp;
	}
	
	public static CloudFoundryProxy getCloudBeanProxyByApp(PassApplication app) {
        Account account=Account.findById(app.accountId);
        return getCloudBeanProxy(account.username, account.passwordBase64, app.target.targetUrl);		
		
	}

	public static boolean createApplication(CloudFoundryProxy proxy,
			PassApplication app, Project project) {

		boolean result = false;
		
			List urls = new ArrayList();
			urls.add(app.url);

			DeploymentInfo deploymentInfo = new DeploymentInfo();
			deploymentInfo.setProjectName(project.name);
			deploymentInfo.setAppName(app.name);
			deploymentInfo.setRuntime(project.runtime);
			deploymentInfo.setFramework(project.framework);
			deploymentInfo.setMemory(app.memory);
			deploymentInfo.setRepository(project.gitUrl);
			deploymentInfo.setTag(app.tag);
			deploymentInfo.setInstances(app.instances);
			deploymentInfo.setUris(urls);
			deploymentInfo.setBranch(app.branch);

			try {
			// deploy app in cloudfoundry
			proxy.deployApplication(deploymentInfo);

			//save dns info
			Account account=Account.findById(app.accountId);
			String hostname=app.name+"."+account.username+"."+app.target.name;
			String ip=app.target.routeip;
			String recordIds=DNSService.createARecordInAllViews(hostname, ip);
			app.recordIds=recordIds;
			
			//save app info
			app.save();

			Logger.info(">> Create application: "+app.name+" success!!");
			result = true;
		} catch (Exception e) {
			Logger.error(">> Creating application: "+app.name+" has error!!", e);
		}

		return result;

	}

	public static CloudApplication getCFApplicationByAppName(
			CloudFoundryProxy proxy, String appName) {

		CloudApplication application = null;
		try {
			application = proxy.getApplication(appName);
			Logger.info(">> Get cloudfoundry application: "+appName+" success!!");
		} catch (Exception e) {
			Logger.error(">> Getting cloudfoundry application: "+appName+" has error!!", e);
		}
		return application;

	}

	public static List<String> getApplicationMapedURLListByAppId(Long appId) {
		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
				
		return getApplicationMapedURLListByApp(app, proxy, appId);
	}
	
	public static List<String> getApplicationMapedURLListByApp(PassApplication pApp,
			CloudFoundryProxy proxy, Long appId) {

		CloudApplication app=null;
		
		try {
			 app= proxy.getApplication(pApp.name);
		} catch (Exception e) {
           Logger.error(">> Getting maped urls:"+pApp.name+" has error!!", e);
           return null;
		}
		
		List<String> urls = app.getUris();

		for (Iterator it = urls.iterator(); it.hasNext();) {
			String s = (String) it.next();
			if (s.equals(pApp.url)) {
				it.remove();
			}
		}
		Logger.info(">> Get maped urls:"+pApp.name+" has success!!");
		return urls;
	}

	public static boolean mapURLToApplicationByAppId(
			Long appId, List<String> urls) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return mapURLToApplicationByApp(app, proxy, urls);
	}
	
	public static boolean mapURLToApplicationByApp(PassApplication pApp,CloudFoundryProxy proxy,
			 List<String> urls) {

		boolean result = false;
		
		try {
			CloudApplication app = proxy.getApplication(pApp.name);
			List<String> appUrls = app.getUris();
			appUrls.addAll(urls);
			proxy.updateApplicationUris(pApp.name, appUrls);
			
			Logger.info(">> Map urls to application:"+pApp.name+" success!!");	
			result=true;
		} catch (Exception e) {
			Logger.error(">> Mapping urls to application:"+pApp.name+" has error!!", e);		    
		}
		return result;
	}

	public static boolean unmapURLToApplicationByAppId(Long appId, List<String> urls) {
		
		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return unmapURLToApplicationByApp(app, proxy,urls);
	}
	
	public static boolean unmapURLToApplicationByApp(PassApplication pApp,CloudFoundryProxy proxy,
			List<String> urls) {
		boolean result = false;

		try {
			CloudApplication app = proxy.getApplication(pApp.name);
			List<String> appUrls = app.getUris();
			for (String u : urls) {
				appUrls.remove(u);
			}
			proxy.updateApplicationUris(pApp.name, appUrls);
			
			Logger.info(">> Unmap urls to application: "+ pApp.name+" success!!");
			result=true;
		} catch (Exception e) {
			Logger.error(">> Unmapping urls to application: "+ pApp.name+" has error!!", e);
		}
		return result;
	}

	public static List<DNS> getAllUsableURLListByAppId(Long appId, Long userId) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return getAllUsableURLListByApp(app, proxy, userId);
	}
	
	public static List<DNS> getAllUsableURLListByApp(PassApplication pApp,CloudFoundryProxy proxy,
			 Long userId) {

		List<DNS> urls = DNS.find("byUserID", userId).fetch();

		List<String> appUrls=null;
		try {
			CloudApplication app = proxy.getApplication(pApp.name);
			appUrls= app.getUris();
		} catch (Exception e) {
			Logger.error(">> Getting all usable dns:"+ pApp.name+" has error!!", e);
			return null;
		}
		
		for (Iterator it = urls.iterator(); it.hasNext();) {
			DNS d = (DNS) it.next();
			if (appUrls.contains(d.name)) {
				it.remove();
			}
		}
		Logger.info(">> Get all usable dns:"+ pApp.name+" success!!");
		return urls;
	}

	public static List<AppEnvironment> getAllEnviromentListByAppId(Long appId) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return getAllEnviromentListByApp(app, proxy);
	}
	
	public static List<AppEnvironment> getAllEnviromentListByApp(PassApplication pApp,
			CloudFoundryProxy proxy) {

		List<String> tmpList = null;
		
		try {
			tmpList = proxy.getAppEnv(pApp.name);			
		} catch (Exception e) {
			Logger.error(">> Getting env :"+ pApp.name+" has error!!", e);
			return null;
		}
		
		List<AppEnvironment> envs = new ArrayList<AppEnvironment>();

		for (String s : tmpList) {
			String result[] = s.split("=");
			AppEnvironment appEnv = new AppEnvironment();

			appEnv.name = result[0];
			appEnv.value = result[1];
			envs.add(appEnv);
		}
		Logger.info(">> Get env :"+ pApp.name+" success!!");
		return envs;
	}

	public static boolean deleteEnviromentsByAppId(Long appId, List<String> enviroments) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return deleteEnviromentsByApp(app, proxy,enviroments);

	}
	
	public static boolean deleteEnviromentsByApp(PassApplication pApp,CloudFoundryProxy proxy,
			 List<String> enviroments) {

		boolean result = false;

		try {
			for (String env : enviroments) {
				proxy.deleteAppEnv(pApp.name, env);
			}
			Logger.info(">> Delete env :" + pApp.name + " success!!");
			result = true;
		} catch (Exception e) {
			Logger.error(">> Deleting env :" + pApp.name + " has error!!", e);
		}
		
		return result;

	}

	public static boolean addEnviromentByAppId(Long appId, String enviroment) {
		
		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return addEnviromentByApp(app, proxy, enviroment);
	}
	
	public static boolean addEnviromentByApp(PassApplication pApp,CloudFoundryProxy proxy,
			 String enviroment) {
		boolean result = false;

		try {
			proxy.addAppEnv(pApp.name, enviroment);
			Logger.info(">> Add env :" + pApp.name + " success!!");
			result = true;
		} catch (Exception e) {
			Logger.error(">> Adding env :" + pApp.name + " has error!!", e);
		}
		return result;
	}

	public static List<InstanceStats> getMonitorInfoListByAppId( Long appId, String minute) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return getMonitorInfoListByApp(proxy, app, minute);

	}	

	public static List<InstanceStats> getMonitorInfoListByApp(
			CloudFoundryProxy proxy, PassApplication app, String minute) {
		List<InstanceStats> monitors = null;
		try {
			ApplicationStats appStats = proxy.getApplicationStats(app.name,
					minute);
			monitors = appStats.getRecords();
			Logger.info(">> Get monitor info :" + app.name
					+ " success!!");
		} catch (Exception e) {
			Logger.error(">> Getting monitor info :" + app.name
					+ " has error!!", e);
		}
		return monitors;

	}

	public static boolean startApplicationByAppId(Long appId) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return startApplicationByAppName(proxy, app.name);

	}

	public static boolean startApplicationByAppName(CloudFoundryProxy proxy,
			String appName) {
		boolean result = false;
		
		try {
			proxy.startApplication(appName);
			result = true;
		} catch (Exception e) {
			Logger.error(
					">> Starting application :" + appName + " has error!!", e);
		}
		return result;
	}

	public static boolean stopApplicationByAppId(Long appId) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return stopApplicationByAppName(proxy, app.name);

	}

	public static boolean stopApplicationByAppName(CloudFoundryProxy proxy,
			String appName) {
		boolean result = false;

		try {
			proxy.stopApplication(appName);
			result = true;
		} catch (Exception e) {
			Logger.error(
					">> Stopping application :" + appName + " has error!!", e);
		}
		return result;

	}

	public static boolean upgradeApplicationByAppId(Long appId, String tagName) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);

		return upgradeApplicationByApp(proxy, app, tagName);
	}

	public static boolean upgradeApplicationByApp(CloudFoundryProxy proxy,
			PassApplication app, String tagName) {
		boolean result = false;

		try {
			proxy.updateApplication(app.name, tagName);
			app.tag = tagName;
			app.save();
		} catch (Exception e) {
			Logger.error(">> Upgrading application :" + app.name
					+ " has error!!", e);
		}
		return result;
	}

	public static boolean scaleApplicationByAppId(Long appId, int instanceNum) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return scaleApplicationByApp(proxy, app, instanceNum);
	}

	public static boolean scaleApplicationByApp(CloudFoundryProxy proxy,
			PassApplication app, int instanceNum) {
		boolean result = false;

		try {
			proxy.updateApplicationInstances(app.name, instanceNum);
			app.instances = instanceNum;
			app.save();
		} catch (Exception e) {
			Logger.error(">> Scaling application :" + app.name
					+ " has error!!", e);
		}
		return result;
	}

	public static List<CloudService> getAllServiceList(CloudFoundryProxy proxy) {
		List<CloudService> services=null;
		
		try{
			services=proxy.getServices();			
		}catch (Exception e) {
			Logger.error(">> Getting all services :" + proxy.toString()
					+ " has error!!", e);
		}
		return services;

	}

	public static List<CloudService> getAllBindServiceListByAppId( Long appId) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return getAllBindServiceListByApp(proxy, app);

	}

	public static List<CloudService> getAllBindServiceListByApp(
			CloudFoundryProxy proxy, PassApplication app) {
		List<CloudService> bindServices=null;
		
		try{			
			bindServices=proxy.GetServicesByApplicationName(app.name);			
		}catch (Exception e) {
			Logger.error(">> Getting bind services :" + app.name
					+ " has error!!", e);
			return null;
		}
		
		return bindServices;

	}

	public static List<CloudService> getAllUsableServiceListByAppId( Long appId) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		return getAllUsableServiceListByApp(proxy, app);
	}

	public static List<CloudService> getAllUsableServiceListByApp(
			CloudFoundryProxy proxy, PassApplication app) {

		List<CloudService> services = getAllServiceList(proxy);
		List<CloudService> bindList = proxy
				.GetServicesByApplicationName(app.name);

		if(services==null||bindList==null) return null;
		
		for (Iterator it = services.iterator(); it.hasNext();) {
			CloudService se = (CloudService) it.next();
			for (CloudService bs : bindList) {
				if (bs.getName().equals(se.getName())) {
					it.remove();
				}
			}
		}
		
		return services;
	}

	public static void bindServiceListToApplicationByAppId( Long appId, List<String> services) {

		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		
		bindServiceListToApplicationByApp(proxy, app, services);

	}

	public static void bindServiceListToApplicationByApp(
			CloudFoundryProxy proxy, PassApplication app, List<String> services) {
		
		for (String se : services) {			
			bindOneServiceToApplicationByApp(proxy, app, se);
			
		}

	}

	public static boolean bindOneServiceToApplicationByApp(
			CloudFoundryProxy proxy, PassApplication app, String serviceName) {

		try {
			proxy.bindService(app.name, serviceName);
		} catch (Exception e) {
			Logger.error(">> Binding service :" + app.name+"---"+serviceName
					+ " has error!!", e);
			return false;
		}
		
		Date nowDate = new Date();
		PassApplicationService dbService = new PassApplicationService();
		dbService.application = app;
		dbService.createdAt = nowDate;
		dbService.serviceName = serviceName;
		dbService.save();
		return true;
		
	}

	public static void unbindServiceLIstToApplicationByAppId( Long appId, List<String> services) {

		PassApplication app = PassApplication.findById(appId);	
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);

		for (String se : services) {
			unbindOneServiceToApplicationByApp(proxy, app, se);			
		}

	}

	public static boolean unbindOneServiceToApplicationByApp(
			CloudFoundryProxy proxy, PassApplication app, String serviceName) {

		try {
			proxy.unbindService(app.name, serviceName);
		} catch (Exception e) {
			Logger.error(">> Binding service :" + app.name + "---"
					+ serviceName + " has error!!", e);
			return false;
		}
		
		PassApplicationService dbService = new PassApplicationService();
		Where where = new Where(null);
		where.addValue("application_id=", app.id);
		where.addValue("service_name=", serviceName);
		dbService = PassApplicationService.find(where.where(),
				where.paramsarr()).first();
		if (dbService != null) {
			dbService.delete();
		}
		return true;
	}

	public static List<PassApplication> getApplicationListByProjectId(
			CloudFoundryProxy proxy, Long proId) {
		List<PassApplication> apps = new ArrayList<PassApplication>();
		apps = PassApplication.find("byProjectId", proId).fetch();

		for (PassApplication app : apps) {
			String status = getApplicationStatusByAppName(proxy, app.name);
			app.status = status;
		}

		return apps;

	}

	public static String getApplicationStatusByAppName(CloudFoundryProxy proxy,
			String appName) {

		String status = proxy.getApplication(appName).getState().toString();

		return status;
	}

	public static void createGitAccount(String userName, String password,
			String gitServerURL) {

		GitAccount gitAccount = new GitAccount();

		try {
			gitAccount.setCloudControllerUrl(new URL(gitServerURL));
			GitServerProxy proxy = new GitServerProxy(gitAccount);
			CreateGitAccountRequest request = new CreateGitAccountRequest();

			GitAccount newAccount = new GitAccount();
			newAccount.setUsername(UserNameAnalyzer.analyzeUserName(userName,
					"git"));
			newAccount.setPassword(password);

			request.setGitAccount(newAccount);
			CreateGitAccountResponse response = proxy.createGitAccount(request);
			// return response.getResult();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

	public static void createGitAccount(Account account) {
		ProjectService service = new ProjectService();
		createGitAccount(account.username, account.passwordBase64,
				service.getGitServerURL());
	}

	public static void createCloudFoundryUser(String userName, String password,
			Long domainId) {
		Domain domain = Domain.findById(domainId);
		List<DomainTarget> domainTargets = domain.domainTargets;
		for (DomainTarget dt : domainTargets) {
			String url = dt.target.targetUrl;
			String adminId = dt.target.adminId;
			String adminPass = dt.target.adminPassword;
			CloudFoundryProxy proxy = getCloudBeanProxy(adminId, adminPass, url);
			createCloudFoundryUser(userName, password, proxy);
		}

	}

	public static void createCloudFoundryUser(String userName, String password,
			CloudFoundryProxy proxy) {

		CloudBean cloudBean = new CloudBean();
		cloudBean.setEmail(UserNameAnalyzer.analyzeUserName(userName, "cf"));
		cloudBean.setPassword(password);
		proxy.add_user(cloudBean);
	}

	public static void createCloudFoundryUser(Account account) {
		createCloudFoundryUser(account.username, account.passwordBase64,
				account.domain.id);

	}

	public static void deleteGitAccount(String userName, String password,
			String gitServerURL) {

		GitAccount gitAccount = new GitAccount();

		try {
			gitAccount.setCloudControllerUrl(new URL(gitServerURL));
			GitServerProxy proxy = new GitServerProxy(gitAccount);
			DeleteGitAccountRequest requ = new DeleteGitAccountRequest();

			GitAccount newAccount = new GitAccount();
			newAccount.setUsername(UserNameAnalyzer.analyzeUserName(userName,
					"git"));
			newAccount.setPassword(password);

			requ.setGitAccount(newAccount);
			DeleteGitAccountResponse respo = proxy.deleteGitAccount(requ);
			// return response.getResult();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}

	}

	public static void deleteGitAccount(Account account) {
		ProjectService service = new ProjectService();
		deleteGitAccount(account.username, account.passwordBase64,
				service.getGitServerURL());
	}

	public static void deleteCloudFoundryUser(String userName, String password,
			Long domainId) {
		Domain domain = Domain.findById(domainId);
		List<DomainTarget> domainTargets = domain.domainTargets;
		for (DomainTarget dt : domainTargets) {
			String url = dt.target.targetUrl;
			String adminId = dt.target.adminId;
			String adminPass = dt.target.adminPassword;
			CloudFoundryProxy proxy = getCloudBeanProxy(adminId, adminPass, url);
			deleteCloudFoundryUser(userName, password, proxy);
		}

	}

	public static void deleteCloudFoundryUser(String userName, String password,
			CloudFoundryProxy proxy) {

		CloudBean cloudBean = new CloudBean();
		cloudBean.setEmail(UserNameAnalyzer.analyzeUserName(userName, "cf"));
		proxy.delete_user(cloudBean);
	}

	public static void deleteCloudFoundryUser(Account account) {
		deleteCloudFoundryUser(account.username, account.passwordBase64,
				account.domain.id);
	}

	public static void deleteApplicationsByProjectId(Long projectId, Long userId) {
		List<PassApplication> apps = PassApplication.find("byProjectId",
				projectId).fetch();

		for (PassApplication app : apps) {
			Account account = Account.findById(userId);
			deleteApplicationByAppId(app.id);
		}
	}

	public static void deleteApplicationByAppId(Long appId) {
		PassApplication app = PassApplication.findById(appId);
		CloudFoundryProxy proxy=getCloudBeanProxyByApp(app);
		deleteApplicationByApp(proxy, app);

	}

	public static void deleteApplicationByApp(CloudFoundryProxy proxy,
			PassApplication app) {

		try{
			proxy.deleteApplication(app.name);
		}catch (Exception e) {
			// TODO: handle exception
		}
		//=======
		String recordIds=app.recordIds;
		DNSService.deleteRecords(recordIds);
		//=======
		
		app.delete();

	}

	public static void cloneApplication(Long userId,Long appId, String newAppName, String newTargetName) {
	
		Account account = Account.findById(userId);
		// get old application info
		PassApplication oldApp = PassApplication.findById(appId);
		CloudFoundryProxy proxy = getCloudBeanProxy(account.username,
				account.passwordBase64, oldApp.target.targetUrl);
		CloudApplication cloudApp = ApplicationService
				.getCFApplicationByAppName(proxy, oldApp.name);

		// get project info
		Project pro = Project.findById(oldApp.project.id);

		// get new application info
		Target newTarget = Target.find("byName", newTargetName).first();
		String targetUrl = newTarget.name + "-samsungcloud.org";

		String url = newAppName.toLowerCase() + "."
				+ CurrentUser.current().name + "." + targetUrl;

		Logger.info(oldApp.project.id + ">>>>" + oldApp.target.id + ">>>>>>>>"
				+ appId + ">>>>" + newAppName + ">>>>>>>>" + newTarget.name
				+ ">>>>>>>" + url);

		PassApplication newApp = new PassApplication();
		newApp.name = newAppName;
		newApp.instances = oldApp.instances;
		newApp.project = pro;
		newApp.url = url;
		newApp.tag = oldApp.tag;
		newApp.branch = oldApp.branch;
		newApp.memory = cloudApp.getMemory();
		newApp.target = newTarget;
		newApp.accountId = userId;
		newApp.createdAt = new Date();

		// create and deploy application
		CloudFoundryProxy newProxy = getCloudBeanProxy(account.username,
				account.passwordBase64, newTarget.targetUrl);
		createApplication(newProxy, newApp, pro);

		List<PassApplicationService> bindServices = new ArrayList<PassApplicationService>();

		// create service

		/*
		 * if (!newTarget.name.equals(app.target.name)) { PassApplication tmpApp
		 * = PassApplication.find("byName", newAppName) .first(); Date nowDate =
		 * new Date();
		 * 
		 * for (PassApplicationService appSe : app.services) {
		 * PassApplicationService newService = new PassApplicationService();
		 * newService.application = tmpApp; newService.createdAt = nowDate;
		 * String tmpName = appSe.serviceName.replace(app.target.name,
		 * newTarget.name); newService.serviceName = tmpName + "_" +
		 * System.currentTimeMillis(); newService.save();
		 * bindServices.add(newService);
		 * 
		 * // TODO CREATE CF SERVICE } } else {
		 * bindServices.addAll(app.services); }
		 * 
		 * 
		 * // bind service for (PassApplicationService newSe : bindServices) {
		 * bindOneServiceToApplicationByApp( newProxy, newApp,
		 * newSe.serviceName);
		 * 
		 * }
		 */

		// create event
		String event = "Clone " + oldApp.name + " to new application: "
				+ newAppName + " !";
		PassEventWriter.writeEvent(CurrentUser.current().id,
				oldApp.target.name, oldApp.name, oldApp.project.id,
				ProjectEvent.INFO, event);
	
	}
	

	private static synchronized long getCurrentTime() {//================
		return System.currentTimeMillis();
	}

	public static void getMonitorGraph(GitAccount account, Long appId) {// ==============
		PassApplication application = PassApplication.findById(appId);
		String appName = application.name;

	}


	public static List<String> getLogByAppNameAndInstNum(String appName,int instanceNum,
			CloudFoundryProxy proxy) {
        
		List<String> logs = new ArrayList<String>();
		try {
			for (int i = 0; i < instanceNum; i++) {
				StringBuffer log=new StringBuffer();
				String errLog=proxy.getAppLogFile(appName, i, "logs/stderr.log");
				if(errLog!=null){
                	log.append(String.valueOf(i)).append("#").append("logs/stdout.log: \n").append(errLog);
                }
				log.append("logs/stderr.log: \n");
                String outLog=proxy.getAppLogFile("appName", i, "logs/stdout.log");
                if(outLog!=null){
                	log.append(outLog);
                }
				
				logs.add(log.toString());
			}
			Logger.info(">> Get logs: "+appName+" success!!");
		} catch (Exception e) {
			Logger.error(">> Getting logs: "+appName+" has error!", e);
			return null;
		}
				
		return logs;

	}

	public static int getInstanceNum(String appName, CloudFoundryProxy proxy) {
		int num = -1;
		CloudApplication app = getCFApplicationByAppName(proxy, appName);
		if (app != null) {
			num = app.getInstances();
		}
		return num;
	}

}
