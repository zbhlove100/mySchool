package service.pass;


public class PassConstants {
	public static  String GIT_SERVER_URL="";

}


