package service.compute;

import java.util.Collection;
import java.util.List;

import models.Cloudprovider;
import models.Zone;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.dc.DataCenter;

import service.BaseService;

public class DataCenterService extends BaseService {
	private org.dasein.cloud.dc.DataCenterServices dataCenterService;
	public DataCenterService(String providerId)  throws Exception{
		super(providerId);
		dataCenterService=provider.getDataCenterServices();
	}
	public DataCenterService(Cloudprovider providermodel) throws Exception{
		super(providermodel);
		dataCenterService=provider.getDataCenterServices();
	}	
	/**
	 * 
	 * @return all the datacenters fecthed by realtime
	 */
	public Collection<DataCenter> listDataCenters(){
		Collection<DataCenter> result=null;
		try {
			result = dataCenterService.listDataCenters(provider.getContext().getRegionId());
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return result;
	}
	/**
	 * 
	 * @return all the datacenters fecthed from database
	 */
	public List<Zone> listDataCentersFromDB(){
		return Zone.find("byCloudprovider", this.providerVO).fetch();
	}
	/**
	 * synchronize DataCenter,because the regionid is defined in the cloudprovider,
	 * so it just fetch the dataCenter belong to the cloudprovider's region 
	 */
	public void synchronizeDataCenter(){
		Collection<DataCenter> result=null;
		try {
			result = dataCenterService.listDataCenters(provider.getContext().getRegionId());
			for(DataCenter dataCenter:result){
				Zone zone=Zone.find("implzoneId", dataCenter.getProviderDataCenterId()).first();
				if(zone==null){
					zone=new Zone();
				}
				zone.name=dataCenter.getName();
				zone.implzoneId=dataCenter.getProviderDataCenterId();
				zone.cloudprovider=providerVO;
				zone.save();
			}
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
	}
}
