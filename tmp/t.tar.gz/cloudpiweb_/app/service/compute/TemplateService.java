package service.compute;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jobs.AsyncJob;

import models.Account;
import models.Cloudprovider;
import models.Template;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Message;

import org.dasein.cloud.AsynchronousTask;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.compute.Architecture;
import org.dasein.cloud.compute.MachineImage;
import org.dasein.cloud.compute.MachineImageSupport;
import org.dasein.cloud.compute.VmState;

import play.cache.Cache;
import play.mvc.Scope;
import service.BaseService;

public class TemplateService extends BaseService {
	private MachineImageSupport machineImageSupport;
	
	public TemplateService(){
		
	}
	
	public TemplateService(String providerId) throws Exception{
		super(providerId);
		machineImageSupport=provider.getComputeServices().getImageSupport();
	}
	
	public TemplateService(Cloudprovider providermodel) throws Exception{
		super(providermodel);
		machineImageSupport=provider.getComputeServices().getImageSupport();
	}	
	
	public List<Template> listAllFromDB(){
		return Template.find("cloudprovider=? and state =?", this.providerVO,BaseModel.ACTIVE).fetch();
	}
	public Template getTemplateByName(String name){
		return Template.find("cloudprovider=? and state =? and name=?", this.providerVO,BaseModel.ACTIVE,name).first();
	}
	public Iterable<MachineImage> listAllTemplate(){
		Iterable<MachineImage> result=null;
		try {
			result = machineImageSupport.listMachineImages();
		} catch (CloudException e) {
			e.printStackTrace();
		} catch (InternalException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public Iterable<MachineImage> listTemplateOwnedBy(String accountNumber) {
		
		Iterable<MachineImage> result=null;
		
		try {
			result = machineImageSupport.listMachineImagesOwnedBy(accountNumber);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
	}
	
	public MachineImage getTemplate(String providerMachineImageId) {
		
		MachineImage machineImage 	= null;
		try {
			machineImage = machineImageSupport.getMachineImage(providerMachineImageId);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return machineImage;
	}
	
	public List<String> getTemplatShare(String providerMachineImageId) {
		
		List<String> results	= new ArrayList<String>();
		
		try {
			Iterable<String> tempResult = machineImageSupport.listShares(providerMachineImageId);
			results.addAll(results);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return results;
	}
	
	public void makeTemplatePublic(String providerMachineImageId) {
		
		try {
			machineImageSupport.shareMachineImage(providerMachineImageId, null, true);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} 
	
	public void makeTemplatePrivate(String providerMachineImageId) {
		
		try {
			machineImageSupport.shareMachineImage(providerMachineImageId, null, false);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void addTemplateShare(String providerMachineImageId, String accountNumber) {
		
		try {
			machineImageSupport.shareMachineImage(providerMachineImageId, accountNumber, true);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void removeTemplateShare(String providerMachineImageId, String accountNumber) {
		
		try {
			machineImageSupport.shareMachineImage(providerMachineImageId, accountNumber, false);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean isTemplatePublic(String machineImageName) {
		
		try {
			return machineImageSupport.isImageSharedWithPublic(machineImageName);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	
	}
	
	public MachineImage createTemplate(String serverId, String machineImageName, String description) {
		
		AsynchronousTask<String> taskMachineImage = null;
		MachineImage machineMage = null;
		
		try {
			taskMachineImage = machineImageSupport.imageVirtualMachine(serverId, machineImageName, description);
			while(!taskMachineImage.isComplete()){
				Thread.sleep(100);
			}
			machineMage = machineImageSupport.getMachineImage(taskMachineImage.getResult());
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return machineMage;
	}
	
	public Map createTemplate(Map inparams) {
		System.out.println("starting createTemplate...");
		Map<String,Object> result = new HashMap<String,Object>();		
		try{
			String serverId = (String)inparams.get("serverId");
			String machineImageName = (String)inparams.get("machineImageName");
			String description = (String)inparams.get("description");
			
			MachineImage mi = createTemplate(serverId,machineImageName,description);
			while(!VmState.PENDING.equals(mi.getCurrentState())) {
				Thread.sleep(2*1000);
				mi = this.machineImageSupport.getMachineImage(mi.getProviderMachineImageId());
	        }			
			result.put("mi", mi);
		}catch(Exception e){
    		e.printStackTrace();
    		result.put(AsyncJob.event_key, new Message(300,e.getMessage()));			
		}
		return result;
	}
	
	public void removeTemplate(String providerMachineImageId) {
		
		try {
			machineImageSupport.remove(providerMachineImageId);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void synchronizeTemplate(){
		
		Iterable<MachineImage> resultCloud=null;
		List<Template> resultCP = null;
		
		
		/**
		 * if the template was removed in targed cloud, but still save in
		 * cloudpi database, remove the record in cloudpi database.
		 * 
		 * */
		try {
			resultCloud = machineImageSupport.listMachineImages();
			
			System.out.println("================>" + resultCloud);
			
			resultCP = Template.find("cloudprovider_id=? and created_by_id=? and state !=?", providerVO.id, CurrentUser.current().id, BaseModel.DELETE).fetch();
			
			Iterator<Template> resultCloudPi = resultCP.iterator();			
			
			while(resultCloudPi.hasNext()) {
				
				boolean hasfind = false;
				Template template = resultCloudPi.next();
				
				for(MachineImage machineImage : resultCloud) {
					String templateId = template.impltemplateId;
					String machineImageId = machineImage.getProviderMachineImageId();
					if(machineImageId.equals(templateId)) {
						hasfind = true;
						break;
					} else {
						continue;
					}
				}
				if(hasfind == false) {
					template.delete();
				}
			}
			
			for(MachineImage machineImage:resultCloud){
				Template template=Template.find("impltemplate_id=? and cloudprovider_id=?", machineImage.getProviderMachineImageId(),providerVO.id).first();
				if(template==null){
					template=new Template();
				}
				template.name=machineImage.getName();
				template.impltemplateId=machineImage.getProviderMachineImageId();
				template.cloudprovider=this.providerVO;
				template.state=machineImage.getCurrentState().toString();
				template.format="XEN";
				template.hypervisorType="XEN";
				template.isbootable=true;
				template.ispublic=true;				
				//template.isbootable=false;
				//template.ispublic=false;
				template.ispublic = machineImageSupport.isImageSharedWithPublic(machineImage.getProviderMachineImageId());
				if(machineImage.getPlatform() != null){
					template.platform = machineImage.getPlatform().name();
				}
                
				template.created_by=new Account(CurrentUser.current().id);
				if(Architecture.I32.equals(machineImage.getArchitecture())){
					template.bits=32;
				}else{
					template.bits=64;
				}
				//template.hypervisorType=machineImage.getType().
				template.save();
			}
		} catch (CloudException e) {
			e.printStackTrace();
		} catch (InternalException e) {
			e.printStackTrace();
		}
	}
	
	
	
}
