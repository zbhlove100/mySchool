package service.compute;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jobs.AsyncJob;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Message;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.compute.Snapshot;
import org.dasein.cloud.compute.SnapshotSupport;

import service.BaseService;


/**
 * <p>
 * The class SnapshotService provides the backends functions support of all snapshot
 * operations in cloud. The implementation of the class is by calling the dasein-cloud API.
 * 
 * For web console developers, when develop the snapshot service, can call the methos of 
 * this class, or can refer to this class to learn how to call dasein-cloud API, and then
 * call the dasein-cloud API directly.
 * </p>
 * 
 */
public class SnapshotService extends BaseService {
	
	private SnapshotSupport snapshotSupport;
	private static Logger log=LogManager.getLogger(VolumeService.class); 
	
    public SnapshotService(String providerId) throws Exception {
		super(providerId);
		snapshotSupport=provider.getComputeServices().getSnapshotSupport();
	}
    
    /**
     * @description, list all snapshot from DB
     * @return List<Volumes>
     */
    public List<models.Snapshot> listSnapshotFromDB() {
    	return models.Snapshot.findAll();
    }
    
    
    /**
     * @Description, list all snapshot from dasein api
     * @return
     * @throws CloudException 
     * @throws InternalException 
     */
    public Iterable<Snapshot> listSnapshot() throws InternalException, CloudException {
    	
    	Iterable<Snapshot> snapshots = null;
    	snapshots = snapshotSupport.listSnapshots();
		
		return snapshots;
    }
    
    /**
     * @Description get snapshot by the snapshot name
     * @param snapshotName
     * @return
     * @throws CloudException 
     * @throws InternalException 
     */
    public Snapshot getSnapshot(String snapshotName) throws InternalException, CloudException {
    	
    	Snapshot snapshot = null;
    	snapshot = snapshotSupport.getSnapshot(snapshotName);
		
		return snapshot;
    }
    
    /**
     * @Description create a snapshot for a volume
     * @param fromVolumeId
     * @param description
     * @return
     * @throws CloudException 
     * @throws InternalException 
     */
    public Map createSnapshot(Map inparams) {
    	
    	String snapshotId = null;
    	Map<String,Object> result = new HashMap<String,Object>();
    	
    	try{
    		String fromVolumeId = (String)inparams.get("implvolumeId");
	    	String description = (String)inparams.get("description");
	    	
	    	snapshotId = snapshotSupport.create(fromVolumeId, description);
	        if(snapshotId == null )
	        	result.put(AsyncJob.event_key, new Message(300,"Fail to createSnapshot"));
	        else
	        	result.put("snapshotId", snapshotId);
        
    	} catch(Exception e){
    		e.printStackTrace();
    		result.put(AsyncJob.event_key, new Message(300,e.getMessage()));
		}
    	
		return result;
    }
    
    /**
     * @Description removed the snapshot
     * @param snapshotName
     * @throws InternalException
     * @throws CloudException
     */
    public void removeSnapshot(String snapshotName) throws InternalException, CloudException {
    	snapshotSupport.remove(snapshotName);
    }
    
    /**
     * @Description list share of the snapshot, in other words, list all accounts who has permission 
     * of the snapshot.
     * @param forSnapshotId
     * @return the account list.
     * @throws InternalException
     * @throws CloudException
     */
    public Iterable<String> listShare(String forSnapshotId) throws InternalException, CloudException {
    	
    	Iterable<String> list = null;
    	list = snapshotSupport.listShares(forSnapshotId);
    	
    	return list;
    }
    
    /**
     * @Descriptioin check the snapshot is public or private, true for public.
     * @param snapshotId
     * @return
     * @throws InternalException
     * @throws CloudException
     */
    public boolean isPublic(String snapshotId) throws InternalException, CloudException {
    	
    	return snapshotSupport.isPublic(snapshotId);
    }
    
    /**
     * @Description share a snapshot to a account
     * @param snapshotId
     * @param withAccountId
     * @param affirmative
     * @throws InternalException
     * @throws CloudException
     */
    public void shareSnapshot(String snapshotId, String withAccountId, boolean affirmative) throws InternalException, CloudException {
    	snapshotSupport.shareSnapshot(snapshotId, withAccountId, affirmative);
    }

    public void synchronizeSnapshots(){
    	
		Iterable<Snapshot> result = null;
        try {
	         result = this.snapshotSupport.listSnapshots();
	         for(Snapshot snapshot:result){
	        	 String snapshotId = snapshot.getProviderSnapshotId();
	        	 models.Snapshot snapshots=models.Snapshot.find("cloudprovider_id = ? and implsnapshot_id=? and state !=?", this.providerVO.id,snapshotId, BaseModel.DELETE).first();

	        	 if(snapshots==null){
	            	 snapshots=new models.Snapshot();
	            	 
	            	 /** 
	            	  * if the snapshot is not created from cloudpi, when sync the snapshot info 
	            	  * from remote cloud to cloudpi, the default account is Root (id = 1)
	            	  * */
	            	 CurrentUser cu = CurrentUser.current();
	            	 snapshots.created_by = models.Account.find("id=?", cu.id).first();
	            	 
	            	 snapshots.name = "sync from "+snapshot.getVolumeId();
	             }
	             
	             snapshots.cloudprovider = this.providerVO;
	             
	             snapshots.state = snapshot.getCurrentState().toString();
	             snapshots.createdAt = new Date(snapshot.getSnapshotTimestamp());
	             
	             snapshots.implsnapshotId = snapshot.getProviderSnapshotId();
	             snapshots.size = (long)snapshot.getSizeInGb();
	             
	             if(snapshotSupport.isPublic(snapshotId)) {
	            	 snapshots.type = "Public";
	             } else {
	            	 snapshots.type = "Private";
	             }
	             
	             String volumeId = snapshot.getVolumeId();
	             models.Volume volumes = models.Volume.find("implvolume_id=?", volumeId).first();
	             snapshots.volume = volumes;
	             
	             snapshots.save();
	             
	         }
		} catch (CloudException e) {
			e.printStackTrace();
		} catch (InternalException e) {
			e.printStackTrace();
		}
	}    
    
}
