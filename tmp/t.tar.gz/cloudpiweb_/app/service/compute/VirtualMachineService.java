package service.compute;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.persistence.EntityManager;

import jobs.AsyncJob;
import models.Account;
import models.Cloudprovider;
import models.Cloudprovider.CloudType;
import models.CloudproviderDetail;
import models.Domain;
import models.Product;
import models.SSHKeypair;
import models.Server;
import models.Template;
import models.Zone;
import models.spec.BaseModel;
import models.spec.CurrentUser;
import models.spec.Message;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.Tag;
import org.dasein.cloud.compute.Architecture;
import org.dasein.cloud.compute.VirtualMachine;
import org.dasein.cloud.compute.VirtualMachineProduct;
import org.dasein.cloud.compute.VirtualMachineSupport;
import org.dasein.cloud.compute.VmState;
import org.dasein.cloud.compute.VmStatistics;
import org.dasein.cloud.network.AddressType;
import org.dasein.cloud.network.IpAddress;
import org.dasein.cloud.network.IpAddressSupport;
import org.dasein.cloud.network.Protocol;

import play.cache.Cache;
import play.mvc.Scope;
import service.BaseService;
import service.monitor.host.HostService;

public class VirtualMachineService extends BaseService {
	private static final int timeout=60;
	private VirtualMachineSupport virtualMachineSupport;
	private VolumeService volumeService=null;
	private TemplateService templateService=null;
	private static Logger log=LogManager.getLogger(VirtualMachineService.class); 
	
	public static VirtualMachineService createServiceByServerId(String serverId) throws Exception{
		//Server server=Server.find("implinstance_Id",serverId).first();
		Server server=Server.findById(Long.parseLong(serverId));
		VirtualMachineService vms = new VirtualMachineService(server.cloudprovider.id+"");
		//added by liubs		
		vms.setProject(server.created_by);
		return vms;
	}
	
	public VirtualMachineService(String providerId)  throws Exception{
		super(providerId);
		volumeService=new VolumeService(providerId);
		virtualMachineSupport=provider.getComputeServices().getVirtualMachineSupport();
		
		templateService=new TemplateService(providerId);
	}
	
	public void synchronizeVMState() throws InternalException, CloudException{
		Iterable<VirtualMachine> vms=virtualMachineSupport.listVirtualMachines();
		for(VirtualMachine vm:vms){
			Server server=Server.find("cloudprovider_id=? and implinstanceId=? and state!=?", providerVO.id,  vm.getProviderVirtualMachineId(),VmState.TERMINATED.name()).first();
			if(server!=null){
			server.state=vm.getCurrentState().name();
			server.save();
			}
		}
	}
	public Server saveServer(Long templateId,
			Long productId,String inZoneId,String name,String description,
			 String keypair,String inVlanId, boolean withMonitoring, 
				boolean asImageSandbox,int diskSizeInGB,
				String ... protectedByFirewalls
			)  throws Exception{
		Server server=new Server();
		String keypairName=null;
		if(keypair!=null&&!"".equals(keypair)){
			SSHKeypair sshkeypair=SSHKeypair.findById(Long.parseLong(keypair));
			if(sshkeypair!=null){
				keypairName=sshkeypair.name;
				server.sshkeypair=sshkeypair;
			}
		}
		
		Template template=Template.findById(templateId);
		
		Product product=Product.findById(productId);
		VirtualMachineProduct size=null;
		try {
			size = virtualMachineSupport.getProduct(product.implproductId);
			size.setDiskSizeInGb(diskSizeInGB);
		} catch (InternalException e) {
			e.printStackTrace();
			return null;
		} catch (CloudException e) {
			e.printStackTrace();
			return null;
		}
		
		VirtualMachine vm=null;
		Zone zone=null;
		try {
			zone=Zone.findById(Long.parseLong(inZoneId));
			
//			if(provider instanceof CloudstackProvider){
//				CurrentUser cuser = CurrentUser.current();				
//				if(!cuser.isSuper()){
//					Account acc = Account.findById(cuser.id);
//					DomainCloudprovider dcp = acc.domain.getDomainCloudprovider(providerByCloudpi.id.toString());
//					Param dp = new Param("domainid",dcp.impldomainId);
//					((CloudstackProvider)provider).addParam("deployVirtualMachine",dp);					
//					dp = new Param("account","9");
//					((CloudstackProvider)provider).addParam("deployVirtualMachine",dp);						
//				}				
//			}
			//Param dp = new Param("networkids","207");
			//((CloudstackProvider)provider).addParam("deployVirtualMachine",dp);
			
			vm = virtualMachineSupport.launch(template.impltemplateId,
					 size, zone.implzoneId,name,description,keypairName,
					inVlanId,withMonitoring,asImageSandbox,	protectedByFirewalls);
			
		} catch (InternalException e) {
			e.printStackTrace();
			return null;
		} catch (CloudException e) {
			e.printStackTrace();
			return null;
		}
		server.zone= zone;
		Domain domain=new Domain();
		CurrentUser currentuser=(CurrentUser)Cache.get(Scope.Session.current().getId());
		domain.id=currentuser.domainid;
		server.domain=domain;
		server.product=product;
		server.cloudprovider=this.providerVO;
		server.state=vm.getCurrentState().toString();
		//server.cloudprovider=this.provider; cloudpi
		if(name!=null&&!"".equals(name)){
			server.name=name;
		}else{
			server.name=vm.getName();
		}
		server.templateId=templateId;
		if(vm.getPrivateIpAddresses()!=null&&vm.getPrivateIpAddresses().length>0){
			server.privateIp=vm.getPrivateIpAddresses()[0];
		}
		//server.hypervisorType
		server.implinstanceId=vm.getProviderVirtualMachineId();
		//server.ismonitor=vm.i
		//server.state
		server.created_by= new Account(currentuser.id);
		server.createdAt=new java.util.Date();
		server.updatedAt=server.createdAt;
		server.state=VmState.PENDING.name();
		//server.removedAt
		server.save();
		Cache.delete(Scope.Session.current().getId()+"server");
		Cache.delete(Scope.Session.current().getId()+"diskSize");
		Cache.delete(Scope.Session.current().getId()+"firewallId");
		Cache.delete(Scope.Session.current().getId()+"keypair");
		volumeService.addRootVolumesByServerId(vm.getProviderVirtualMachineId());
		return server;
	}
	public List<Server> listAllServersFromDb(){
		return Server.findAll();
	}

	public List<Server> listAllServersFromProvider(){
		List<Server> serverList=null;
		try {
		Iterable<VirtualMachine> result = null;
		serverList = new ArrayList<Server>();
		result=virtualMachineSupport.listVirtualMachines();
		for (VirtualMachine vm : result) {
			Server server = new Server();
			server.name=vm.getName();
			server.state = vm.getCurrentState().toString();
			
			Zone zone = new Zone();
			zone.name = provider.getDataCenterServices().getRegion(provider.getContext().getRegionId()).toString();
			server.zone = zone;
			
			Cloudprovider cloudprovider = new Cloudprovider();
			cloudprovider.name = provider.getProviderName();
			
			server.cloudprovider = cloudprovider;
			serverList.add(server);
		}
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return serverList;
	}
	public void boot(String serverId){
		try {
			Server server=Server.findById(Long.parseLong(serverId));
			this.virtualMachineSupport.boot(server.implinstanceId);
			this.setServerState(serverId,VmState.RUNNING);
		} catch (InternalException e) {
			log.debug("boot virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("boot virtualMachine fail"+e.getMessage());
		}
	}

	public VirtualMachine clone(String arg0, String arg1, String arg2,
			String arg3, boolean arg4, String... arg5){
		try {
			return this.virtualMachineSupport.clone(arg0, arg1, arg2, arg3, arg4, arg5);
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void disableAnalytics(String vmId) throws InternalException,
			CloudException {
		virtualMachineSupport.disableAnalytics(vmId);
	}

	public void enableAnalytics(String vmId) throws InternalException,
			CloudException {
		virtualMachineSupport.enableAnalytics(vmId);
	}

	public String getConsoleOutput(String vmId) throws InternalException,
			CloudException {
		return virtualMachineSupport.getConsoleOutput(vmId);
	}

	public VirtualMachineProduct getProduct(String productId)
			throws InternalException, CloudException {
		return virtualMachineSupport.getProduct(productId);
	}

	public String getProviderTermForServer(Locale locale) {
		return virtualMachineSupport.getProviderTermForServer(locale);
	}

	public VmStatistics getVMStatistics(String arg0, long arg1, long arg2)
			throws InternalException, CloudException {
		return virtualMachineSupport.getVMStatistics(arg0, arg1, arg2);
	}

	public Iterable<VmStatistics> getVMStatisticsForPeriod(String arg0,
			long arg1, long arg2) throws InternalException, CloudException {
		return virtualMachineSupport.getVMStatisticsForPeriod(arg0, arg1, arg2);
	}

	public VirtualMachine getVirtualMachine(String providerVirtualMachineId) {
		try {
			Server server=Server.findById(Long.parseLong(providerVirtualMachineId));
			VirtualMachine virtualMachine=virtualMachineSupport.getVirtualMachine(server.implinstanceId);
			server.state=virtualMachine.getCurrentState().name();
			server._save();
			return virtualMachine;
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean isSubscribed(){
		try {
			return this.virtualMachineSupport.isSubscribed();
		} catch (InternalException e) {
			log.debug("isSubscribed inoking fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("isSubscribed inoking fail"+e.getMessage());
		}
		return false;
	}
	public VirtualMachine launch( String fromMachineImageId,  String productID, String dataCenterId, String name, String description,  String withKeypairId,  String inVlanId, boolean withAnalytics, boolean asSandbox,  String ... firewallIds){
		VirtualMachineProduct product;
		try {
			product = virtualMachineSupport.getProduct(productID);
			VirtualMachine virtualMachine=virtualMachineSupport.launch(fromMachineImageId, product,
					dataCenterId,name,description,withKeypairId,
					inVlanId,withAnalytics,asSandbox,firewallIds);
			return virtualMachine;
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return null;
	}

	public VirtualMachine launch(String arg0, VirtualMachineProduct arg1,
			String arg2, String arg3, String arg4, String arg5, String arg6,
			boolean arg7, boolean arg8, String[] arg9, Tag... arg10){
		return null;
	}

	public Iterable<String> listFirewalls(String vmId){
		try {
			return virtualMachineSupport.listFirewalls(vmId);
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return null;
	}

	public Iterable<VirtualMachineProduct> listProducts(Architecture architecture){
		try {
			return this.virtualMachineSupport.listProducts(architecture);
		} catch (InternalException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		}
		return null;
	}
	public List<Product> listProductsFromDB(int bits){
		if(CloudType.AWS.equals(this.providerVO.type)){
			return Product.find("cloudprovider=? and bits=? and state=? order by implproductId",
						this.providerVO,bits,BaseModel.ACTIVE).fetch();
		}
		return Product.find("cloudprovider=? order by implproductId", this.providerVO).fetch();
	}	
	public void synchronizedProduct(){
		
		try {
			List<Product> result32CP = Product.find("cloudprovider_id=? and bits=?", providerVO.id, 32).fetch();
			Iterator<Product> result32CloudPi = result32CP.iterator();
			Iterable<VirtualMachineProduct> result=this.virtualMachineSupport.listProducts(Architecture.I32);
			
			/**
			 * if the product was removed in targed cloud, but still save in
			 * cloudpi database, remove the record in cloudpi database.
			 * 
			 * */
			while(result32CloudPi.hasNext()) {
				
				boolean hasfind = false;
				Product product = result32CloudPi.next();
				
				for(VirtualMachineProduct vmProduct : result) {
					
					String productId = product.implproductId;
					String vmProductId = vmProduct.getProductId();

					if(productId.equals(vmProductId)) {
						hasfind = true;
						break;
					} else {
						continue;
					}
				}
				if(hasfind == false) {
					product.delete();
				}
			}
			
			for(VirtualMachineProduct product:result){
				Product productVo=Product.find("cloudprovider_id = ? and implproductId=?", providerVO.id, product.getProductId()).first();
				if(productVo==null){
					productVo=new Product();
				}
				productVo.name=product.getName();
				productVo.implproductId=product.getProductId();
				productVo.cloudprovider=this.providerVO;
				productVo.state="AVAILABLE";
				productVo.bits=32;
				productVo.save();
			}
			
			List<Product> result64CP = Product.find("cloudprovider_id=? and bits=?", providerVO.id, 64).fetch();
			Iterator<Product> result64CloudPi = result64CP.iterator();
			result=this.virtualMachineSupport.listProducts(Architecture.I64);
			
			while(result64CloudPi.hasNext()) {
				
				boolean hasfind = false;
				Product product = result64CloudPi.next();
				
				for(VirtualMachineProduct vmProduct : result) {
					
					String productId = product.implproductId;
					String vmProductId = vmProduct.getProductId();

					if(productId.equals(vmProductId)) {
						hasfind = true;
						break;
					}
				}
				if(hasfind == false) {
					product.delete();
				}
			}
			
			for(VirtualMachineProduct product:result){
				Product productVo=Product.find("cloudprovider_id = ? and implproductId=?", providerVO.id, product.getProductId()).first();
				if(productVo==null){
					productVo=new Product();
				}
				productVo.name=product.getName();
				productVo.implproductId=product.getProductId();
				productVo.cloudprovider=this.providerVO;
				productVo.state="AVAILABLE";
				productVo.bits=64;
				productVo.save();
			}
			
		} catch (InternalException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		}
	}	

	public Iterable<VirtualMachine> listVirtualMachines(){
		try {
			return this.virtualMachineSupport.listVirtualMachines();
		} catch (InternalException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		}
		return null;
	}

	public void pause(String serverId){
		try {
			Server server=Server.findById(Long.parseLong(serverId));
			this.virtualMachineSupport.pause(server.implinstanceId);
			this.setServerState(serverId,VmState.PAUSED);
		} catch (InternalException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("pause virtualMachine fail"+e.getMessage());
		}
	}

	public void reboot(String serverId){
		try {
			Server server=Server.findById(Long.parseLong(serverId));
			this.virtualMachineSupport.reboot(server.implinstanceId);
			this.setServerState(serverId,VmState.RUNNING);
		} catch (InternalException e) {
			log.debug("reboot virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			log.debug("reboot virtualMachine fail"+e.getMessage());
		}
	}


	public Map terminate(Map inparams){
		Map<String,Object> result = new HashMap<String,Object>();
		String serverId=(String)inparams.get("serverId");
		String oldState="";
		Server oldServer=null;
		try {
			//Server server=Server.find("implinstanceId=? and state!=?",serverId,VmState.TERMINATED.toString()).first();
			Server server=Server.findById(Long.parseLong(serverId));
			oldServer=server;
			oldState=server.state;
			server.state=VmState.TERMINATED.toString();
			server.save();
			this.virtualMachineSupport.terminate(server.implinstanceId);
			int i=0;
			while(true){
				Thread.sleep(5000);
				VirtualMachine vm=this.virtualMachineSupport.getVirtualMachine(server.implinstanceId);
				if(vm.getCurrentState().equals(VmState.TERMINATED)){
					break;
				}
				if(i>this.timeout){
					break;
				}
				i++;
			}
			result.put(AsyncJob.event_key, new Message(200,"Success to terminate the instance!"));
		} catch (InternalException e) {
			oldServer.state=oldState;
			oldServer.save();
			result.put(AsyncJob.event_key, new Message(300,e.getMessage()));
			log.debug("terminate virtualMachine fail"+e.getMessage());
		} catch (CloudException e) {
			oldServer.state=oldState;
			oldServer.save();
			result.put(AsyncJob.event_key, new Message(300,e.getMessage()));
			log.debug("terminate virtualMachine fail"+e.getMessage());
		}catch(Exception e){
			result.put(AsyncJob.event_key, new Message(300,e.getMessage()));
			log.debug("terminate virtualMachine fail"+e.getMessage());
		}
		return result;
	}
	public Server saveServer(Server server,int diskSizeInGb,String keypair,String... firewallId) throws Exception {
		Server serverR=this.saveServer(server.templateId,
				server.product.id, ""+server.zone.id,server.name,server.name,keypair,
				null, true, 
				true,diskSizeInGb,firewallId);
		return serverR;
	}
	
	public Map<String,Object> job_saveServer(Map inparams){
		
		Map<String,Object> result = new HashMap<String,Object>();
		
		Long serverId = (Long)inparams.get("serverId");
		int diskSizeInGB = Integer.parseInt((String)inparams.get("diskSizeInGB"));
		String[] firewallId = (String[])inparams.get("firewallId");
		
		String keypairName = (String)inparams.get("keypairName");
		
		Server server = Server.findById(serverId);
		
		try{
			
			Template template=Template.findById(server.templateId);
			Product product= server.product;
			
			VirtualMachineProduct size = virtualMachineSupport.getProduct(product.implproductId);
			size.setDiskSizeInGb(diskSizeInGB);
			
			Zone zone=server.zone;
			String name = server.name;
			
			play.Logger.info("Start creating %s instance >>>>>>>>>>>>>>>>:"+new Date(System.currentTimeMillis()),server.name);
					
			VirtualMachine vm = virtualMachineSupport.launch(template.impltemplateId,
							 size, zone.implzoneId,server.name,server.name,keypairName,
							null,true,true,	firewallId);
					
			if(name!=null &&! "".equals(name)){
				server.name=name;
			}else{
				server.name=vm.getName();
			}
			
			if(vm.getPrivateIpAddresses()!=null&&vm.getPrivateIpAddresses().length > 0){
				server.privateIp=vm.getPrivateIpAddresses()[0];
			}
			
			server.implinstanceId=vm.getProviderVirtualMachineId();
			server.state=vm.getCurrentState().toString();
			
			EntityManager em = server.em();
			//em.getTransaction().begin();
			//em.persist(server);
			server._save();
			
			result.put("server", server);
			
			while(true){
				try {
					Thread.sleep(2*1000);
					
					vm = virtualMachineSupport.getVirtualMachine(server.implinstanceId);
					
					if(!VmState.PENDING.name().equals(vm.getCurrentState().toString())){
						server.state=vm.getCurrentState().toString();
						if(vm.getPrivateIpAddresses()!=null && vm.getPrivateIpAddresses().length > 0){
							server.privateIp=vm.getPrivateIpAddresses()[0];
						}
						server._save();
						play.Logger.info("Finished %s instance >>>>>>>>>>>>>>>>:"+new Date(System.currentTimeMillis()),server.name);
						break;
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					break;
				}				
			}
			
			if(vm.getPublicIpAddresses() !=null && vm.getPublicIpAddresses().length > 0 &&
					Cloudprovider.CloudType.RACKSPACE.name().equals(server.cloudprovider.type)){
				
				result.put("publicIp", vm.getPublicIpAddresses()[0]);
				
				models.IpAddress ipaddress = new models.IpAddress();
				
				ipaddress.cloudprovider = this.providerVO;
				ipaddress.server = server;
				ipaddress.account = server.created_by;
				ipaddress.domain = server.domain; 			 
				ipaddress.sourceNat = 0;
				ipaddress.publicIpAddress = vm.getPublicIpAddresses()[0]; 
				ipaddress.allocated = new Date(System.currentTimeMillis()); 
				ipaddress.state = "associated";
				
				ipaddress.save();				
			}
			                                      
			try{
				volumeService.setCurrentUserId(server.created_by.id);
				volumeService.addRootVolumesByServerId(vm.getProviderVirtualMachineId());
				
				em.getTransaction().commit();
				
			    AsyncJob metric_job = new AsyncJob(this, "saveMetricId");
			    
			    metric_job.initParams();
			    metric_job.addInParam("serverId", server.id);
			    metric_job.now();
					     
				//saveMetricId(server);
			}catch(Exception e){
				e.printStackTrace();
			}
			
		}catch(Exception e){
			e.printStackTrace();
			server.delete();
			result.put(AsyncJob.event_key, new Message(300,"Fail to create instance:"+e.getMessage()));
		}
		return result;
		
	}
	
	private void setServerState(String serverId,VmState vmState){
		Server server=Server.findById(Long.parseLong(serverId));
		server.state=vmState.name();
		server.save();
	}
	public void createMonitorServer(){
		templateService.synchronizeTemplate();
		Template template=templateService.getTemplateByName("hypericserver");
		if(template==null){
			return;
		}
		//boolean withAnalytics, boolean asSandbox, @Nullable String ... firewallIds)
		//VirtualMachine vm = virtualMachineSupport.launch(template.impltemplateId,size, this.providerVO.getId(),"hyperic_server","hyperic server","","",true,true,"");
		try {
			VirtualMachineProduct vmProduct = new VirtualMachineProduct();
			vmProduct.setProductId("1");
			VirtualMachine vm = virtualMachineSupport.launch(template.impltemplateId,
					vmProduct,this.providerVO.detailshash().get("regionId"),"hyperic_server","hyperic server",null,
					 null,true,true);
			
			String address = null;
			IpAddressSupport ipAddressSupport=provider.getNetworkServices().getIpAddressSupport();
	    	/** request public ip address*/
	        if( ipAddressSupport.isRequestable(AddressType.PUBLIC) ) {
	        	try {
	        		System.out.println(AddressType.PUBLIC);
	        		address = ipAddressSupport.request(AddressType.PUBLIC);
	        	}
	        	/** Too many addresses allocated. there is no available ip address in ip pool*/
	        	catch(CloudException ce) {
	        	}
	        }
	        System.out.println(address);
	        Iterable<IpAddress> listPublicIpPool=ipAddressSupport.listPublicIpPool(true);
	        for(IpAddress ipAddress:listPublicIpPool){
	        	if(ipAddress.getAddress().equals(address)){
	        		System.out.println(ipAddress.getProviderIpAddressId()+":"+ipAddress.getAddress());
	        		ipAddressSupport.forward(ipAddress.getProviderIpAddressId(), 7080, Protocol.TCP, 7080,vm.getProviderVirtualMachineId());
	                ipAddressSupport.forward(ipAddress.getProviderIpAddressId(), 22, Protocol.TCP, 22,vm.getProviderVirtualMachineId());
	        	}
	        }
			
			CloudproviderDetail detail=new CloudproviderDetail();
			detail.cloudprovider=this.providerVO;
			detail.name="Hyperic_Server_IP";
			detail.value=address;
			detail.save();
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		/*this.saveServer(server.templateId,
				server.product.id, ""+server.zone.id,server.name,server.name,keypair,
				null, true, 
				true,diskSizeInGb,firewallId);
		this.saveServer(templateId, productId, this.providerVO, name, description, keypair, inVlanId, withMonitoring, asImageSandbox, diskSizeInGB, protectedByFirewalls);*/
	}
	
	public void saveMetricId(Map inparam){
		
		HostService host=new HostService("176.34.30.24",7080,"hqadmin","hqadmin");
		Long serverId = (Long)inparam.get("serverId");
		Server server = Server.findById(serverId);
		if(server ==null ||server.implinstanceId == null){
			play.Logger.error("No instanceId to get monitor metric_id:"+server+"-->"+serverId.toString());
			return;
		}
		try {
			
			for(int count = 0; count < 10; count++){
				
				VirtualMachine vm = virtualMachineSupport.getVirtualMachine(server.implinstanceId);
				Map<String,List<Integer>> metricId= null;
				if(CloudType.CLOUDSTACK.name().equals(server.cloudprovider.type)){
					metricId=host.getMetricId(vm.getDescription());
				}else if(CloudType.RACKSPACE.name().equals(server.cloudprovider.type)){
					metricId=host.getMetricIdByIp(vm.getPublicIpAddresses()[0]);
				}else if(CloudType.OPENSTACK.name().equals(server.cloudprovider.type)){
					metricId=host.getMetricId(vm.getDescription().replace(" ", "-").toLowerCase());
				}else{
					play.Logger.error("Fail to get monitor metric_id");
					return ;
				}
				
				StringBuffer str=new StringBuffer("");
				for(int i:metricId.get("CPU")){
					str.append(i).append(",");
				}
				str.append(";");
				for(int i:metricId.get("diskWrites")){
					str.append(i).append(",");
				}
				str.append(";");
				for(int i:metricId.get("diskReads")){
					str.append(i).append(",");
				}
				str.append(";");
				for(int i:metricId.get("bitTransmitted")){
					str.append(i).append(",");
				}
				str.append(";");
				for(int i:metricId.get("bitReceived")){
					str.append(i).append(",");
				}
				
				if(!";;;;".equals(str.toString())){
					server.MetricId=str.toString();
					break;
				}
				play.Logger.info("Waiting for %s monitor starting in an minute",server.name);
				Thread.sleep(60*1000);
			}
			
			if(server.MetricId != null){
				server.ismonitor = true;
				server.save();
			}else{
				play.Logger.error("Fail to get monitor metric_id");
			}

			
		} catch (Exception e) {
			play.Logger.error("Fail to get monitor metric_id");
			e.printStackTrace();
		}
		return ;
	}
}
