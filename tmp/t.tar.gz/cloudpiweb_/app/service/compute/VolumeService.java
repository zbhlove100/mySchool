package service.compute;

import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

import models.Account;
import models.Server;
import models.Template;
import models.Zone;
import models.spec.BaseModel;
import models.spec.CurrentUser;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.compute.MachineImage;
import org.dasein.cloud.compute.VirtualMachine;
import org.dasein.cloud.compute.Volume;
import org.dasein.cloud.compute.VolumeSupport;

import play.cache.Cache;
import play.mvc.Scope;
import service.BaseService;


/**
 * <p>
 * The class VolumeService provides the backends functions support of all volume
 * operations in cloud. The implementation of the class is by calling the dasein-cloud API.
 * 
 * For web console developers, when develop the volume service, can call the methos of 
 * this class, or can refer to this class to learn how to call dasein-cloud API, and then
 * call the dasein-cloud API directly.
 * </p>
 * 
 */
public class VolumeService extends BaseService {
	
	private VolumeSupport volumeSupport;
	private static Logger log=LogManager.getLogger(VolumeService.class); 
	private Long currentuserId = null;
	
    public VolumeService(String providerId) throws Exception {
		super(providerId);
		this.currentuserId = CurrentUser.current()==null? null:CurrentUser.current().id;
		volumeSupport=provider.getComputeServices().getVolumeSupport();
	}
    
    public void setCurrentUserId(Long userid){
    	this.currentuserId = userid;
    }
    
    /**
     * @description, list all volumes from DB
     * @return List<Volumes>
     */
    public List<models.Volume> listVolumesFromDB() {
    	return models.Volume.findAll();
    }

    /**
     * 
     * @description: list volume list in target cloud (dasein api calling)
     * @return Iterable<Volume>
     * 
     */
    public Iterable<Volume> ListVolumes() {
    	
    	log.debug("get the volume list");
		try {
			return this.volumeSupport.listVolumes();
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return null;
    }

    
    /**
     * 
     * @param volumeId
     * @description: removed a volume with the input "volume ID".  
     * @return removed the volume sucessfully, return true. fail to remove the volume ,reture false.
     * @throws InternalException
     * @throws CloudException
     * 
     */
    public boolean removeVolume(String volumeId) throws InternalException, CloudException {
    	
    	boolean removed = false;
        Volume v = this.volumeSupport.getVolume(volumeId);
		 
        log.setLevel(Level.DEBUG);
        
        /** check whether there are volume in IaaS Cloud. */ 
        if(v == null) {
        	log.debug("Please check the input volumeId, there is no volume " + volumeId + " in IaaS Cloud!");
        	return removed;
        }
       
        /** check whether the volume is used by server now. */
        if (v.getProviderVirtualMachineId() != null) {
        	log.debug("Currently the volume is used by server: " + v.getProviderVirtualMachineId());
        	return removed;               
        /** check whether the status of the volume is AVAILABLE. */
        } else if(!(v.getCurrentState().toString().equals("AVAILABLE"))) {
        	log.debug("Currently the status of this volume is not available, can not be removed!");
        	return removed;
        /** removed the specifying volume, which is not used by any server now. */
        } else {
        	provider.getComputeServices().getVolumeSupport().remove(volumeId);
        }
        
        /** sleep 5 seconds, and then check whether removed the volume successfully. */
        try { 
        	Thread.sleep(5000L); 
        } catch( InterruptedException e ) {        	
        }
        
        Volume vCheck = this.volumeSupport.getVolume(volumeId);
        if(vCheck == null) {
        	log.debug("removed the volume successfully!\n");
        	removed = true;
        	return removed;
        } else {
        	log.debug("Volume " + volumeId +" is still alive!");
        	return removed;
        }
        	
    }
    
    /**
     * 
     * @param volumeId: the volume ID that will be attached.
     * @param serverId: the server ID
     * @param deviceId: the device ID when the volume is attached to the server.
     * @description: attach a volume to a target server 
     * @return attach the volume successfully, return true. fail to attach the volume ,reture false.
     * @throws InternalException
     * @throws CloudException
     * 
     */
    public boolean attachVolume(String volumeId, String serverId, String deviceId) throws InternalException, CloudException {
    	
    	boolean attached = false;
    	
    	String device = deviceId;
        Volume v = this.volumeSupport.getVolume(volumeId);
        VirtualMachine server = provider.getComputeServices().getVirtualMachineSupport().getVirtualMachine(serverId);
        
        /** check whether the volume is using by some servers.*/
        if(v.getProviderVirtualMachineId() != null) {
        	System.out.println("Server status!");
        	log.debug("Currently the volumeId " + volumeId + " is using by server " + v.getProviderVirtualMachineId());
        	return attached;
        	
//        /** check whether the status of server is PAUSED status.*/
//        } else if(!(server.getCurrentState().toString().equals("PAUSED"))) {
//        	System.out.println();
//        	log.debug("Currently the server " + serverId + " is not PAUSED status, can not attach volume to this server!");
//        	
//        	return attached;
        } else {
        	
        	/** 
        	 * using the input deviceId to attach the volume first, if fail to attach, check all
        	 * possible device out, and use them to attach the volume unti find a usable deviceID
        	 * 
        	 * Note: For AWS cloud, the possible deviceID from /dev/sdg to /dev/sdp!
        	 * 
        	 * */
            for( String id : provider.getComputeServices().getVolumeSupport().listPossibleDeviceIds(server.getPlatform()) ) {
            	try {
            		this.volumeSupport.attach(volumeId, serverId, device);
            		attached = true;
            		log.debug("attach the volume " + volumeId + " to server " + serverId + " with device " + device);
            		return attached;
            	} catch(CloudException expected) {
            		log.debug("The device " + device + " is using by server!");
                	device = id;
            		continue;
            	}
            }
            return attached;
        }

    } 
    
    
    /**
     * 
     * @param volumeId: the volume ID that will be detached.
     * @description: detach a volume from a target server 
     * @return detach the volume successfully, return true. fail to detach the volume ,return false.
     * @throws InternalException
     * @throws CloudException
     * 
     */
    public boolean detachVolume(String volumeId) throws InternalException, CloudException {
    	    	
    	this.volumeSupport.detach(volumeId);
		return true;
		
/*		
    	boolean detached = false;
    	Volume v = this.volumeSupport.getVolume(volumeId);
    	// check whether the volume is attached or not
    	if(v.getProviderVirtualMachineId() == null) {
    		log.debug("the volume is not attached to any server!");
    		return detached;
    		
    	} else {
    		this.volumeSupport.detach(volumeId);
    		return true;
    	}
*/    	
    	
//        /** sleep 5 seconds, and then check whether detach the volume successfully. */
//        try { 
//        	Thread.sleep(5000L); 
//        } catch( InterruptedException e ) {        	
//        }
//        
//        Volume vCheck = this.volumeSupport.getVolume(volumeId);
//        if(vCheck.getProviderVirtualMachineId() == null) {
//        	log.debug("detach the volume " + volumeId + " successfully!");
//        	detached = true;
//        	return detached;
//        } else {
//        	log.debug("The volume " + volumeId + "is still attaching to server " + v.getProviderVirtualMachineId());
//        	return detached;
//        }
    	
    	
    } 
    
    /**
     * 
     * @param fromSnapshot: create volume from snapshot
     * @param sizeInGb: the size of the volume
     * @param zoneId: the zone where create the volume
     * 
     * @description: create a volume in specific zone 
     * @return the volume ID
     * 
     * @throws InternalException
     * @throws CloudException
     * 
     */
    public String createVolume(String fromSnapshot,int sizeInGb, String zoneId) throws InternalException, CloudException {
    	
    	/** todo: currently do not support create volume from snapshot*/
    	fromSnapshot = null;
    	
    	String volumeId = null;
    	
    	/** check ehwther the zone is alive status*/
    	boolean alived = provider.getDataCenterServices().getDataCenter(zoneId).isActive();
    	if(!alived) {
    		log.debug("datacenter / zone " + zoneId + " can not be reachable, change a zone please!");
    		return volumeId;
    	} else if(sizeInGb <= 0) {
    		log.debug("The side of volume should be larger than 1 GB!");
    		return volumeId;
    	} else {
    		volumeId = this.volumeSupport.create(fromSnapshot, sizeInGb, zoneId);
    		return volumeId;
    	}    	
    }
    
    /**
     * 
     * @param volumeId
     * @description get volume from volumeId
     * @return Volume
     * @throws InternalException
     * @throws CloudException
     */
    public Volume getVolume(String volumeId) throws InternalException, CloudException {
    	Volume v = null;
    	v = this.volumeSupport.getVolume(volumeId);
    	return v;
    }
    
    public void addRootVolumesByServerId(String providerVirtualMachineId){
		 Iterable<Volume> result=null;
        try {
        	 if(this.volumeSupport==null){
        		 return;
        	 }
	         result = this.volumeSupport.listVolumes();;
	         for(Volume volume:result){
	        	 	if(!providerVirtualMachineId.equals(volume.getProviderVirtualMachineId()))
	        	 	{
	        	 		continue;
	        	 	}
	                 models.Volume volumes=new models.Volume();
	                 
	                 volumes.cloudprovider = this.providerVO;
	                 
	                 Server server=Server.find("implinstanceId", volume.getProviderVirtualMachineId()).first();
	
	                 if(volume.getDeviceId() == null) {
	                	 volumes.state = "AVAILABLE";
	                 } else {
	                	 volumes.server=server;
	                	 volumes.state = "in-use";
	                 }
	                 
	                 if(volume.getName()!=null&&!"".equals(volume.getName())){
	                	 volumes.name = volume.getName();
	                 }else{
	                	 volumes.name = volume.getProviderVolumeId();
	                 }
	                 
	                 volumes.implvolumeId = volume.getProviderVolumeId();
	                 volumes.size = volume.getSizeInGigabytes();
	                 
//	                 volumes.state = volume.getCurrentState().toString();
	                 Calendar calendar = Calendar.getInstance(TimeZone
	                                 .getTimeZone("UTC"));
	                 calendar.setTimeInMillis(calendar.getTimeInMillis());
	                 calendar.set(Calendar.MILLISECOND, 0);
	                 volumes.createdAt=calendar.getTime();
	                 volumes.created_by=new Account(currentuserId);
	                 volumes.type="RootDisk";
	                 volumes.zone = Zone.find("implzoneId=?", volume.getProviderDataCenterId()).first();
	                 volumes.save();
	         }
		} catch (CloudException e) {
			e.printStackTrace();
		} catch (InternalException e) {
			e.printStackTrace();
		}
	}
	
	public void synchronizeVolumes(){
		 
		 try {
			Iterable<Volume> result= this.volumeSupport.listVolumes();
			List<models.Volume> resultCP = models.Volume.find("cloudprovider_id=? and created_by_id=? and state !=?", providerVO.id, CurrentUser.current().id, BaseModel.DELETE).fetch();
		        
			Iterator<models.Volume> resultCloudPi = resultCP.iterator();
			
			/**
			 * if the volume was removed in targeted cloud, but still save in
			 * cloudpi database, remove the record in cloudpi database.
			 * 
			 * */
			while(resultCloudPi.hasNext()) {
					
				boolean hasfind = false;
				models.Volume volumeCloudPi = resultCloudPi.next();
				
				for(Volume volumeCloud : result) {
					String volumeCloudPiId = volumeCloudPi.implvolumeId;
					String volumeCloudId = volumeCloud.getProviderVolumeId();
					if(volumeCloudPiId.equals(volumeCloudId)) {
						hasfind = true;
						break;
					} else {
						continue;
					}
				}
				if(hasfind == false) {
					volumeCloudPi.delete();
				}
			}
			 
	        for(Volume volume:result){
	         	 String volumeId = volume.getProviderVolumeId();
	                models.Volume volumes=models.Volume.find("implvolume_id=?", volumeId).first();
	                if(volumes==null){
	               	 volumes=new models.Volume();
	               	 volumes.name = volume.getProviderVolumeId();
	                }
	                
	                volumes.cloudprovider = this.providerVO;
	                Server server=Server.find("implinstanceId", volume.getProviderVirtualMachineId()).first();
	                
	                if(volume.getDeviceId() == null) {
	                	 volumes.state = "AVAILABLE";
	                } else {
	                	 volumes.server=server;
	                	 volumes.state = "in-use";
	                 }
	                 
//	                 if(volume.getName()!=null&&!"".equals(volume.getName())){
//	                	 volumes.name = volume.getName();
//	                 }else{
//	                	 volumes.name = volume.getProviderVolumeId();
//	                 }
	                
	                 volumes.implvolumeId = volume.getProviderVolumeId();
	                 volumes.size = volume.getSizeInGigabytes();
	                 
//	                 volumes.state = volume.getCurrentState().toString();
	                 Calendar calendar = Calendar.getInstance(TimeZone
	                                 .getTimeZone("UTC"));
	                 calendar.setTimeInMillis(calendar.getTimeInMillis());
	                 calendar.set(Calendar.MILLISECOND, 0);
	                 volumes.createdAt=calendar.getTime();
	                 volumes.attachedAt=calendar.getTime();
	                 volumes.created_by=new Account(this.currentuserId);
	                 //volumes.type="rootDisk";
	                 volumes.zone = Zone.find("implzoneId=?", volume.getProviderDataCenterId()).first();
	                           
	                 volumes.save();
	         }
		} catch (CloudException e) {
			e.printStackTrace();
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    

}
