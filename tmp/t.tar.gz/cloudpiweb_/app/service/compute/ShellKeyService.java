package service.compute;

import java.util.List;

import models.Account;
import models.Domain;
import models.SSHKeypair;
import models.spec.CurrentUser;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.identity.ShellKeySupport;

import play.cache.Cache;
import play.mvc.Scope;
import service.BaseService;

public class ShellKeyService extends BaseService {
	private ShellKeySupport shellKeySupport;

	public ShellKeyService(String providerId) throws Exception {
		super(providerId);
		shellKeySupport = provider.getIdentityServices().getShellKeySupport();
	}

	public void synchronizeShellKey() {
		// shellKeySupport.list();
	}

	public SSHKeypair createKeypair(String name){
		try {
			String material=shellKeySupport.createKeypair(name);
			SSHKeypair keypair=new SSHKeypair();
			keypair.cloudprovider=this.providerVO;
			keypair.name=name;
			keypair.publicKey=material;
			CurrentUser currentuser=(CurrentUser)Cache.get(Scope.Session.current().getId());
			Account account=new Account();
            account.id=currentuser.id;
			keypair.created_by=account;
			Domain domain=new Domain();
			domain.id=currentuser.domainid;
			keypair.domain=domain;
			keypair.fingerprint="";
			keypair.save();
			return keypair;
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<SSHKeypair> getKeypairFromDb(){
		CurrentUser currentuser=(CurrentUser)Cache.get(Scope.Session.current().getId());
		Account account=new Account();
        account.id=currentuser.id;
		List<SSHKeypair> result=SSHKeypair.find("created_by=? and cloudprovider=?", account,this.providerVO).fetch();
		return result;
	}
}
