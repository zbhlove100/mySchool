package service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import models.Account;
import models.Cloudprovider;
import models.spec.CurrentUser;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.CloudProvider;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.ProviderContext;
import org.dasein.cloud.aws.AWSCloud;
import org.dasein.cloud.cloudstack.CloudstackProvider;
import org.dasein.cloud.dc.Region;
import org.dasein.cloud.jclouds.openstack.swift.Swift;
import org.dasein.cloud.openstack.nova.ec2.NovaEC2;
import org.dasein.cloud.rackspace.RackspaceCloud;


public class BaseService {
	
	protected CloudProvider provider;
	protected Cloudprovider providerVO;
	protected String accountNumber;
	
	private static Logger log=LogManager.getLogger(BaseService.class); 
	
	private ProviderContext ctx;
	
	protected BaseService(){
		
	}
	
	public BaseService(Cloudprovider providermodel)throws Exception{
		
		initialize(providermodel);
	}
	
	public BaseService(String providerId) throws Exception{
		
		Cloudprovider cloudProvider = Cloudprovider.findById(Long.parseLong(providerId));
		initialize(cloudProvider);
	}
	
	public void initialize(Cloudprovider providerVO) throws Exception{
	
		this.providerVO = providerVO;
		
		Cloudprovider.CloudType type = Cloudprovider.CloudType.getCloudType(providerVO.type);
		this.ctx = new ProviderContext();

		CurrentUser cuser = CurrentUser.current();
		Map<String, String> details = null;
		
		details = providerVO.detailshash();
		String sharekey = details.get("apiSharedKey");
		String secretkey = details.get("apiSecretKey");
		
		if (Cloudprovider.CloudType.AWS.equals(type)) {
			provider = new AWSCloud();
		} else if (Cloudprovider.CloudType.CLOUDSTACK.equals(type)) {
			provider = new CloudstackProvider();
			if(!cuser.isSuper()){
				Map<String, String> mydetails = providerVO.detailshash(cuser.id);
				sharekey = mydetails.get("apiSharedKey");
				secretkey =  mydetails.get("apiSecretKey");
			}
		} else if (Cloudprovider.CloudType.OPENSTACK.equals(type)) {
			provider = new NovaEC2();
			if(!cuser.isSuper()){
				int pos = sharekey.indexOf(':');
				sharekey = sharekey.substring(0, pos+1)+cuser.name; //the username is same as project name
			}			
		} else if (Cloudprovider.CloudType.RACKSPACE.equals(type)) {
			provider = new RackspaceCloud();
		} else if (Cloudprovider.CloudType.SWIFT.equals(type)) {
			provider = new Swift();
		}
		
		
		if(provider == null){
			throw new Exception("You aren't avaliable in this provider");
		}
		
		
		if(sharekey == null){
			throw new Exception("There arenot available keys for calling in this provider");
		}
		
		ctx.setAccessKeys(sharekey.getBytes(), secretkey.getBytes());
		
		ctx.setEndpoint(details.get("endpoint"));
		
		//ctx.setCloudName(properties.get("cloudName"));
		if (details.get("accountNumber") != null) {
			ctx.setAccountNumber(details.get("accountNumber"));
			this.accountNumber = details.get("accountNumber");
		}
		
		//ctx.setProviderName(properties.get("providerName"));
		ctx.setRegionId(details.get("regionId"));
		
		if (details.get("x509Cert") != null) {
			ctx.setX509Cert(details.get("x509Cert").getBytes());
		}
		if (details.get("x509Key") != null) {
			ctx.setX509Key(details.get("x509Key").getBytes());
		}
		
		this.provider.connect(ctx);		
		
	}
	
	//the username is same as project name
	public void setProject(Account account){

		CurrentUser cuser = CurrentUser.current();
		if(account != null && cuser != null && cuser.isSuper() && account.id.longValue() != cuser.id.longValue() && provider instanceof NovaEC2){
			String sharekey = new String(ctx.getAccessPublic());
			int pos = sharekey.indexOf(':');
			sharekey = sharekey.substring(0, pos+1)+account.username;		
			ctx.setAccessPublic(sharekey.getBytes());
		}
	}
	
	public void setZoneId(String zoneId){
		ctx.setRegionId(zoneId);		
	}
	
	public CloudProvider getProvider() {
		return this.provider;
	}
	
	public Collection<Region> availableRegion () throws InternalException, CloudException {
		
		Collection<Region> regionList = provider.getDataCenterServices().listRegions();
		for(Region region : regionList) {
			String regionStatus = null;
			String regionAvailable = null;
			if(region.isActive()) {
				regionStatus = "Active";
			} else {
				regionStatus = "Inactive";
			}
			
			if(region.isAvailable()) {
				regionAvailable = "Available";
			} else {
				regionAvailable = "Unavailable";
			}
			
			log.debug("region: " + region.getName() + " " + regionStatus + " " + regionAvailable);
		}
		
		return regionList;
	}
	
	public Map<String,Object> supportedService() {
		
		Map<String,Object> supportedService = new HashMap<String,Object>();
		
		/** Compute Service Group*/
		if(provider.getComputeServices().hasImageSupport()) {
			supportedService.put("Templat Service", provider.getComputeServices().getImageSupport());
		}
		
		if(provider.getComputeServices().hasAutoScalingSupport()) {
			supportedService.put("Auto-Scaling Service", provider.getComputeServices().getAutoScalingSupport());
		}
		
		if(provider.getComputeServices().hasSnapshotSupport()) {
			supportedService.put("Snapshot Service", provider.getComputeServices().getSnapshotSupport());
		}
		
		if(provider.getComputeServices().hasVirtualMachineSupport()) {
			supportedService.put("Server Service", provider.getComputeServices().getVirtualMachineSupport());
		}
		
		if(provider.getComputeServices().hasVolumeSupport()) {
			supportedService.put("Volume Service", provider.getComputeServices().getVolumeSupport());
		}
		
		
		/** Networking Service Group*/
		if(provider.getNetworkServices().hasDnsSupport()) {
			supportedService.put("DNS Service", provider.getNetworkServices().getDnsSupport());
		}
		
		if(provider.getNetworkServices().hasFirewallSupport()) {
			supportedService.put("Security-Group Service", provider.getNetworkServices().getFirewallSupport());
		}
		
		if(provider.getNetworkServices().hasIpAddressSupport()) {
			supportedService.put("IP Address Service", provider.getNetworkServices().getIpAddressSupport());
		}
		
		if(provider.getNetworkServices().hasLoadBalancerSupport()) {
			supportedService.put("Load-Balancer Service", provider.getNetworkServices().getLoadBalancerSupport());
		}
		
		if(provider.getNetworkServices().hasVlanSupport()) {
			supportedService.put("Vlan Service", provider.getNetworkServices().getVlanSupport());
		}
		
		if(provider.getNetworkServices().hasVpnSupport()) {
			supportedService.put("VPN Service", provider.getNetworkServices().getVpnSupport());
		}
		
		
		/** Platform Service Group*/
		if(provider.getPlatformServices().hasCDNSupport()) {
			supportedService.put("CDN Service", provider.getPlatformServices().getCDNSupport());
		}
		
		if(provider.getPlatformServices().hasKeyValueDatabaseSupport()) {
			supportedService.put("KeyValue-Database Service", provider.getPlatformServices().getKeyValueDatabaseSupport());
		}
		
		if(provider.getPlatformServices().hasMessageQueueSupport()) {
			supportedService.put("Message-Queue Service", provider.getPlatformServices().getMessageQueueSupport());
		}
		
		if(provider.getPlatformServices().hasPushNotificationSupport()) {
			supportedService.put("Push-Notification Service", provider.getPlatformServices().getPushNotificationSupport());
		}
		
		if(provider.getPlatformServices().hasRelationalDatabaseSupport()) {
			supportedService.put("Relational-Database Service", provider.getPlatformServices().getRelationalDatabaseSupport());
		}
		
		
		/** Storage Service Group*/
		if(provider.getStorageServices().hasBlobStoreSupport()) {
			supportedService.put("BlobStore Service", provider.getStorageServices().getBlobStoreSupport());
		}
		
		
//		/** Admin Service Group*/
//		if(provider.getAdminServices().hasPrepaymentSupport()) {
//			supportedService.put("Prepayment Service", provider.getAdminServices().getPrepaymentSupport());
//		}
//		
//		
//		/** Identity Service Group*/
//		if(provider.getIdentityServices().hasShellKeySupport()) {
//			supportedService.put("ShellKey Service", provider.getIdentityServices().getShellKeySupport());
//		}
		
		return supportedService;
		
	}
	
}
