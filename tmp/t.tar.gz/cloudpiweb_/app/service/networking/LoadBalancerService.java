package service.networking;

import java.util.Locale;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.network.LbAlgorithm;
import org.dasein.cloud.network.LbListener;
import org.dasein.cloud.network.LbProtocol;
import org.dasein.cloud.network.LoadBalancer;
import org.dasein.cloud.network.LoadBalancerAddressType;
import org.dasein.cloud.network.LoadBalancerSupport;

import service.BaseService;


public class LoadBalancerService extends BaseService{
	
	private LoadBalancerSupport loadBalancerSupport;
	private static Logger log=LogManager.getLogger(LoadBalancerService.class); 
	
    public LoadBalancerService(String providerId) throws Exception{
    	super(providerId);
    	loadBalancerSupport = provider.getNetworkServices().getLoadBalancerSupport();
    }
    
    public Iterable<LoadBalancer> listLoadBalancers() throws CloudException, InternalException{
        return loadBalancerSupport.listLoadBalancers();
    }
    
    
    public String create(String name, String description, String addressId, String[] dataCenterIds, LbListener[] listeners, String[] serverIds) throws CloudException, InternalException{
    	log.debug("create loadBalancer"+"\n");
    	return loadBalancerSupport.create(name, description, addressId, dataCenterIds, listeners, serverIds);
    }
    
    public void addDataCenters(String toLoadBalancerId, String ... dataCenterIdsToAdd) throws CloudException, InternalException{
    	loadBalancerSupport.addDataCenters(toLoadBalancerId, dataCenterIdsToAdd);
    }
    
    public void addServers(String toLoadBalancerId, String ... serverIdsToAdd) throws CloudException, InternalException{
    	loadBalancerSupport.addServers(toLoadBalancerId, serverIdsToAdd);
    }
    
    public LoadBalancer getLoadBalancer(String loadBalancerId) throws CloudException, InternalException{
    	return loadBalancerSupport.getLoadBalancer(loadBalancerId);
    }
    
    public LoadBalancerAddressType getAddressType() throws CloudException, InternalException{   	
    	return loadBalancerSupport.getAddressType();
    }
    
    public int getMaxPublicPorts() throws CloudException, InternalException{
    	return loadBalancerSupport.getMaxPublicPorts();    	
    }
    
    public String getProviderTermForLoadBalancer(Locale locale){
    	return loadBalancerSupport.getProviderTermForLoadBalancer(locale);
    }
    
    public Iterable<LbAlgorithm> listSupportedAlgorithms() throws CloudException, InternalException{
    	return loadBalancerSupport.listSupportedAlgorithms();
    }
    
    public Iterable<LbProtocol> listSupportedProtocols() throws CloudException, InternalException{
    	return loadBalancerSupport.listSupportedProtocols();
    }
    
    public boolean isAddressAssignedByProvider() throws CloudException, InternalException{
    	return loadBalancerSupport.isAddressAssignedByProvider();
    }
    
    public boolean isDataCenterLimited() throws CloudException, InternalException{
    	return loadBalancerSupport.isDataCenterLimited();
    }
    
    public boolean requiresListenerOnCreate() throws CloudException, InternalException{
    	return loadBalancerSupport.requiresListenerOnCreate();
    }
    
    public boolean requiresServerOnCreate() throws CloudException, InternalException{
    	return loadBalancerSupport.requiresServerOnCreate();
    }
    
    public boolean isSubscribed() throws CloudException, InternalException{
    	return loadBalancerSupport.isSubscribed();
    }
    
    public boolean supportsMonitoring() throws CloudException, InternalException{
    	return loadBalancerSupport.supportsMonitoring();
    }
    
    public void remove(String loadBalancerId) throws CloudException, InternalException{
    	loadBalancerSupport.remove(loadBalancerId);
    }
    
    public void removeDataCenters(String fromLoadBalancerId, String ... dataCenterIdsToRemove) throws CloudException, InternalException{
    	loadBalancerSupport.removeDataCenters(fromLoadBalancerId, dataCenterIdsToRemove);
    }
    
    public void removeServers(String fromLoadBalancerId, String ... serverIdsToRemove) throws CloudException, InternalException{
    	loadBalancerSupport.removeServers(fromLoadBalancerId, serverIdsToRemove);
    }
    
}
