package service.networking;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import models.Setting;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.DeleteMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.params.HttpConnectionManagerParams;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;


public class DnsService {
	
	private String endpoint = "";
	
	public DnsService(){
		this.endpoint = Setting.value("dnsendpoint");
	}
	
	public DnsService(String endpoint){
		this.endpoint = endpoint;
	}
	
	public void setEndpoint(String endpoint){
		this.endpoint = endpoint;
	}
	
	public String getEndpoint(){
		return this.endpoint;
	}
	
	public Map<String, String> getMapFromJson(String json){
		Gson gson = new Gson();
        Type type = new TypeToken<Map<String,String>>(){}.getType();
        Map<String, String> map = new HashMap();
        map = gson.fromJson(json,type);
        return map;
	}
	
	public List<Map<String,String>> getListFromJson(String json){
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        JsonElement jsonElement = jsonParser.parse(json);
        JsonArray jsonArray = jsonElement.getAsJsonArray();
        Iterator<JsonElement> it = jsonArray.iterator();
        List<Map<String,String>> list1 = new ArrayList();
        
        while(it.hasNext()){
        	jsonElement = it.next();
        	
        	Type type = new TypeToken<Map<String,String>>(){}.getType();
        	
        	Map<String,String> map = new HashMap<String,String>();
        	
        	map = gson.fromJson(jsonElement, type);
        	list1.add(map);
        }
        return list1;
	}
	
	public List<Map<String,String>> listRecords(){
		return _listRecords(null, null);
	}
	
	public List<Map<String,String>> findRecordsByHost(String host){
		return _listRecords(host, null);
	}
	
	public List<Map<String,String>> findRecordsByZone(String zone){
		return _listRecords(null, zone);
	}
	
	public List<Map<String,String>> _listRecords(String host, String zone){
		HttpClient client = getClient();
		String url = this.endpoint + "/records/list.json";
		List<Map<String,String>> list = new ArrayList();
		
		PutMethod put = new PutMethod(url);
		
		List<NameValuePair> listPair = new ArrayList();
		
		Map<String,String> map = new HashMap<String,String>();
		map.put("host", host);
		map.put("zone", zone);
		
		Set<String> keys = map.keySet();
		for(String key : keys){
			if("".equals(map.get(key))||map.get(key)==null){
				continue;
			}else{
				NameValuePair param = new NameValuePair(key, map.get(key));
				listPair.add(param);
			}
		}
		NameValuePair[] data = {new NameValuePair("","")};
		if(listPair.size()>0){
			put.setQueryString(listPair.toArray(data));
		}
		
		
		try{
			client.executeMethod(put);
			String result = put.getResponseBodyAsString();
			list = getListFromJson(result);

			return list;
		}catch(Exception e){
			
		}finally{
			put.releaseConnection();
		}
		return list;
		
	}
	
	
    /*
     * 
     */
	public Map<String, String> createRecord(String zoneId, String type, String host, String ttl, String data, String view){
		HttpClient client = getClient();
		String url = this.endpoint + "/records/add.json";
		Map<String,String> record = new HashMap<String,String>();
		
		PutMethod put = new PutMethod(url);
		NameValuePair[] datas = {new NameValuePair("record[zone_id]", zoneId),
        		new NameValuePair("record[host]", host),
        		new NameValuePair("record[type]", type),
        		new NameValuePair("record[ttl]", ttl),
        		new NameValuePair("record[view]", view),
        		new NameValuePair("record[data]", data)};
		
		put.setQueryString(datas);
		try{
			client.executeMethod(put);
			String result = put.getResponseBodyAsString();
			System.out.println(">>>>result:"+result);
			record = getMapFromJson(result);

			return record;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			put.releaseConnection();
		}
		return record;
	}
	/*
	 * 
	 */
	public boolean deleteRecord(String id){
		HttpClient client = getClient();
		String url = this.endpoint + "/records/" + id + ".json";
		boolean result = false;
		
		DeleteMethod delete = new DeleteMethod(url);
		delete.addRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
		
		try{
			client.executeMethod(delete);
			String r = delete.getResponseBodyAsString();
			if(r.equalsIgnoreCase("success")){
				result = true;
			}
			return result;
		}catch(Exception e){
			
		}finally{
			delete.releaseConnection();
		}
		return result;
		
	}
	/*
	 * 
	 */
	public HttpClient getClient(){
		HttpClient client = new HttpClient();
		HttpConnectionManagerParams hmps = client.getHttpConnectionManager().getParams();
		hmps.setConnectionTimeout(30000);
        hmps.setSoTimeout(120000); 
        
        return client;
	}
}
