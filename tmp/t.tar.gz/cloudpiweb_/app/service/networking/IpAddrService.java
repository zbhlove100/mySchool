package service.networking;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import models.FirewallRule;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.compute.VirtualMachine;
import org.dasein.cloud.dc.Region;
import org.dasein.cloud.network.AddressType;
import org.dasein.cloud.network.IpAddress;
import org.dasein.cloud.network.IpAddressSupport;
import org.dasein.cloud.network.Protocol;

import service.BaseService;


/**
 * <p>
 * The class IPAddressService provides the backends functions support of all IP Address
 * operations in cloud. The implementation of the class is by calling the dasein-cloud API.
 * 
 * For web console developers, when develop the IP Address service, can call the methods of 
 * this class, or can refer to this class to learn how to call dasein-cloud API, and then
 * call the dasein-cloud API directly.
 * 
 * Note: for AWS EC2, it seems that dasein do not support the VPC
 * 
 * </p>
 * 
 */
public class IpAddrService extends BaseService {
	
	private IpAddressSupport ipAddressSupport;
	private static Logger log=LogManager.getLogger(IpAddrService.class); 
	
	
    public IpAddrService(String providerId)throws Exception{
		super(providerId);
		ipAddressSupport = provider.getNetworkServices().getIpAddressSupport();
		
	}
    
    public List<models.IpAddress> listIpFromDB() {
    	return models.IpAddress.findAll();
    }
    
    /**
     *
     * @return Iterable<IpAddress> list all public ip address
     * @throws InternalException
     * @throws CloudException
     */
    public Iterable<IpAddress> listPublicIpAddress() throws InternalException, CloudException {
    	
		Iterable<IpAddress> result = this.ipAddressSupport.listPublicIpPool(true);
		
		for(IpAddress ip:result) {
			log.debug("public ipaddress: " + ip.getAddress() + "\n");
		} 
		
		return result;
    }
    
    /**
     * 
     * @return Iterable<IpAddress> list all private ip address
     * @throws InternalException
     * @throws CloudException
     */
    public Iterable<IpAddress> listPrivateIpAddress() throws InternalException, CloudException {
    	
		Iterable<IpAddress> result = this.ipAddressSupport.listPrivateIpPool(true);
		
		for(IpAddress ip:result) {
			log.debug("public ipaddress: " + ip.getAddress() + "\n");
		} 
		
		return result;
    }
    /**
     * @description request public ip address object
     * @param address
     * @return IpAddress public ipAddress object
     * @throws InternalException
     * @throws CloudException
     */
    public Map getPublicAddress(Map inparams) throws InternalException, CloudException {
    	Map<String,Object> result = new HashMap<String,Object>();
    	System.out.println(">>>>>>>>>>>>>>>>>>>>getPublicAddress start");
    	IpAddress ipAddr = this.ipAddressSupport.getIpAddress(requestPublicIP());
    	System.out.println(">>>>>>>>>>>>>>>>>>>>getPublicAddress end");
    	//String ipAddr = requestPublicIP();
    	result.put("address", ipAddr);
    	return result;
    }
    
    /**
     * @description request public ip address object
     * @param address
     * @return IpAddress public ipAddress object
     * @throws InternalException
     * @throws CloudException
     */
    public IpAddress getAddress(String address) throws InternalException, CloudException {
    	IpAddress ipAddr = this.ipAddressSupport.getIpAddress(address);
    	return ipAddr;
    }
    
    /**
     * @description request public ip address
     * @return String public IP address
     * @throws InternalException
     * @throws CloudException
     */
    public String requestPublicIP() throws InternalException, CloudException {
    	
    	String address = null;
    	
    	/** request public ip address*/
        if( this.ipAddressSupport.isRequestable(AddressType.PUBLIC) ) {
        	try {
        		address = this.ipAddressSupport.request(AddressType.PUBLIC);
        		log.debug(address);
        		return address;
        	}
        	/** Too many addresses allocated. there is no available ip address in ip pool*/
        	catch(CloudException ce) {
        		log.error(ce);
        		return address;
        	}
        }
        
        return address;
    } 
    
    /**
     * @ request private ip address. 
     *   note: there is vpc in AWS EC2, it seems that dasein does not support the vpc.
     * @return String private IP address
     * @throws InternalException
     * @throws CloudException
     */
    public String requestPrivateIP() throws InternalException, CloudException {
    	
    	String address = null;
    	
    	/** request private ip address*/
        if( this.ipAddressSupport.isRequestable(AddressType.PRIVATE) ) {
        	try {
        		address = this.ipAddressSupport.request(AddressType.PRIVATE);
        		log.debug(address);
        		return address;
        	}
        	/** Too many addresses allocated. there is no available ip address in ip pool*/
        	catch(CloudException ce) {
        		log.error(ce);
        		return address;
        	}
        }
        
        return address;
    } 
    
    /**
     * @description release public ip address from public ip pool
     * @param publicIpAddrId
     * @return return true if release successfully, return false if fail to release.
     * @throws InternalException
     * @throws CloudException
     */
    public Map releasePublicIP(Map inparams) throws InternalException, CloudException {

    	boolean released = false;
    	Map<String,Object> result = new HashMap<String,Object>();
    	String publicIpAddr = (String)inparams.get("publicIpAddr");
    	
        IpAddress ipAddress = getAddress(publicIpAddr);
        System.out.println(">>>>>>>>>>ipAddrService-ipAddress:"+ipAddress);
        if(ipAddress==null){
            released = true;
     	    result.put("result", released);
     	    return result;
        }else{
        	/** release the specifing public ip address */
        	if( this.ipAddressSupport.isRequestable(AddressType.PUBLIC) ) {
            	this.ipAddressSupport.releaseFromPool(publicIpAddr);
            }   
        	
        	/** sleep 5 seconds and then check release success or not */
            try { 
            	Thread.sleep(5000L); 
            }
            catch( InterruptedException e ) {
            	
            }
                
           IpAddress tmp = this.ipAddressSupport.getIpAddress(publicIpAddr);
           if(tmp == null) {
        	   released = true;
        	   result.put("result", released);
        	   return result;
           } else {
        	   log.debug("fail to release, the ip is still in the public ip pool ");
        	   result.put("result", released);
        	   return result;
           }
        }
        
    	
    	 
    }
    
	public Map releasePublicIPForCS(Map inparams) throws InternalException, CloudException{
        boolean released = false;
        Map<String,Object> result = new HashMap<String,Object>();
        String providerIpAddressId = (String)inparams.get("providerIpAddressId");
        
        //IpAddress ipAddress = getAddress(publicIpAddr);
        if( this.ipAddressSupport.isRequestable(AddressType.PUBLIC) ) {
        	this.ipAddressSupport.releaseFromPool(providerIpAddressId);
        	released = true;
     	    result.put("result", released);
     	    return result;
        }
        return result;
        
        //System.out.println(">>>>>>>>>>ipAddrService-ipAddress:"+ipAddress);
//        if(ipAddress==null){
//        	released = true;
//     	    result.put("result", released);
//     	    return result;
//        }else{
//        	/** release the specifing public ip address */
//        	if( this.ipAddressSupport.isRequestable(AddressType.PUBLIC) ) {
//            	this.ipAddressSupport.releaseFromPool(providerIpAddressId);
//            }   
//        	
//        	/** sleep 5 seconds and then check release success or not */
//            try { 
//            	Thread.sleep(5000L); 
//            }
//            catch( InterruptedException e ) {
//            	
//            }
//                
//           IpAddress tmp = this.ipAddressSupport.getIpAddress(publicIpAddr);
//           System.out.println("tmp:"+tmp);
//           if(tmp == null) {
//        	   released = true;
//        	   result.put("result", released);
//        	   return result;
//           } else {
//        	   log.debug("fail to release, the ip is still in the public ip pool ");
//        	   result.put("result", released);
//        	   return result;
//           }
//        }
    	
    }
    
    
    /**
     * @description release private ip address from private ip pool
     * @param privateIpAddrId
     * @return return true if release successfully, return false if fail to release.
     * @throws InternalException
     * @throws CloudException
     */
    public boolean releasePrivateIP(String privateIpAddrId) throws InternalException, CloudException {

    	boolean released = false;
       	IpAddress tmp = null;
    	
    	/** check the input ip is in ip pool or not */
    	tmp = this.ipAddressSupport.getIpAddress(privateIpAddrId);
    	if(tmp == null) {
    		log.debug("there is no such ip in ip pool, please check again!");
    		return released;
    	
    	/** release the specifing private ip address */
    	} else if( this.ipAddressSupport.isRequestable(AddressType.PRIVATE) ) {
        	this.ipAddressSupport.releaseFromPool(privateIpAddrId);
        }   
    	
    	/** sleep 5 seconds and then check release success or not */
        try { 
        	Thread.sleep(5000L); 
        }
        catch( InterruptedException e ) {
        	
        }
            
       tmp = this.ipAddressSupport.getIpAddress(privateIpAddrId);
       if(tmp == null) {
    	   released = true;
    	   return released;
       } else {
    	   log.debug("fail to release, the ip is still in the private ip pool ");
    	   return released;
       }
    	 
    }
    
    /**
     * @description disassociate a public ip from server 
     * @param address
     * @return return true if disassociate ip from server successfully, otherwise return false
     * @throws InternalException
     * @throws CloudException
     */
    public Map disAssociatePublicIP(Map inparams) throws InternalException, CloudException {
    	String address = (String)inparams.get("publicIpAddress");
    	Map<String,Object> result = new HashMap<String,Object>();
    	boolean disAssociated = false;
       	IpAddress tmp = null;
       	
       	/**check whether the ip is associate to a server or not*/
       	if(!(this.ipAddressSupport.getIpAddress(address).isAssigned())) {
       		log.debug("this ip is not associated with any server!");
       		result.put("result", disAssociated);
       		return result;   
       		
       	/** disassocaite the ip from server*/
       	} else if( this.ipAddressSupport.isAssigned(AddressType.PUBLIC) ) {
        	this.ipAddressSupport.releaseFromServer(address);
       	}
       	
    	/** sleep 5 seconds and then check release success or not */
        try { 
        	Thread.sleep(5000L); 
        }
        catch( InterruptedException e ) {
        	
        }
            
       tmp = this.ipAddressSupport.getIpAddress(address);
       if(tmp.isAssigned()) {
    	   log.error("the ip is still associate to the server");
    	   result.put("result", disAssociated);
      	   return result; 
       } else {
    	   result.put("result", disAssociated);
      	   return result; 
    	
       }
        
    }
    
    /**
     * @description disassociate a private ip from server 
     * @param address
     * @return return true if disassociate ip from server successfully, otherwise return false
     * @throws InternalException
     * @throws CloudException
     */
    public boolean disAssociatePrivateIP(String address) throws InternalException, CloudException {
    	
    	boolean disAssociated = false;
       	IpAddress tmp = null;
       	
       	/**check whether the ip is associate to a server or not*/
       	if(!(this.ipAddressSupport.getIpAddress(address).isAssigned())) {
       		log.debug("this ip is not associated with any server!");
       		return disAssociated;   
       		
       	/** disassocaite the ip from server*/
       	} else if( this.ipAddressSupport.isAssigned(AddressType.PRIVATE) ) {
        	this.ipAddressSupport.releaseFromServer(address);
       	}
       	
    	/** sleep 5 seconds and then check release success or not */
        try { 
        	Thread.sleep(5000L); 
        }
        catch( InterruptedException e ) {
        	
        }
            
       tmp = this.ipAddressSupport.getIpAddress(address);
       if(tmp.isAssigned()) {
    	   log.error("the ip is still associate to the server");
    	   return disAssociated;
       } else {
    	   disAssociated = true;
    	   return disAssociated;
    	
       }
        
    }
    
    public boolean isAssigned(String address) {
    	
    	try {
			return this.ipAddressSupport.getIpAddress(address).isAssigned();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
    	
    }
    
    /**
     * @description "AWS"- asociate a public ip to the server
     * @param address, public ip address
     * @param serverId, server id
     * @return associate successfully, return true. otherwise return false.
     * @throws InternalException
     * @throws CloudException
     */
    public Map associatePublicIP(Map inparams) throws InternalException, CloudException {
    	
    	String address = (String)inparams.get("publicIpAddress");
    	String serverId = (String)inparams.get("implinstanceId");
    	Map<String,Object> result = new HashMap<String,Object>();
    	boolean associated = false;
    	IpAddress tmpIp = null;
    	VirtualMachine tmpServer = null;
    	
    	/** check the server is available or not */
    	if((provider.getComputeServices().getVirtualMachineSupport().getVirtualMachine(serverId)) == null) {
    		log.debug("the server is not available, please check!");
    		result.put("result", associated);
    		return result;   
    	
    	/** check whether the ip is validated or not */
    	} else if((this.ipAddressSupport.getIpAddress(address)) == null) {
    		log.debug("the ip address is not available in ip pool");
    		result.put("result", associated);
    		return result; 
    	
//    	/** check whether the ip is associated with other server or not.*/
//    	} else if(this.ipAddressSupport.getIpAddress(address).isAssigned()) {
//    		log.debug("the ip has been associated to other server!");
//    		return associated;
    	}
    	
    	/**associate the ip to the server*/
    	else if( this.ipAddressSupport.isAssigned(AddressType.PUBLIC) ) {
            this.ipAddressSupport.assign(address, serverId);
    	}
    	
    	/** sleep 5 seconds and then check release success or not */
        try { 
        	Thread.sleep(5000L); 
        }
        catch( InterruptedException e ) {
        	
        }
            
        tmpIp = this.ipAddressSupport.getIpAddress(address);
       if(tmpIp.isAssigned()) {
    	   associated = true;
    	   result.put("result", associated);
   		return result; 
       } else {
    	   log.debug("fail to associate the ip to the server!");
    	   result.put("result", associated);
   		return result;     	
       }
    }
    
    /**
     * @description asociate a private ip to the server
     * @param address, private ip address
     * @param serverId, server id
     * @return associate successfully, return true. otherwise return false.
     * @throws InternalException
     * @throws CloudException
     */
    public boolean associatePrivateIP(String address, String serverId) throws InternalException, CloudException {
    	
    	boolean associated = false;
    	IpAddress tmpIp = null;
    	VirtualMachine tmpServer = null;
    	
    	/** check the server is available or not */
    	if((provider.getComputeServices().getVirtualMachineSupport().getVirtualMachine(serverId)) == null) {
    		log.debug("the server is not available, please check!");
    		return associated;   
    	
    	/** check whether the ip is validated or not */
    	} else if((this.ipAddressSupport.getIpAddress(address)) == null) {
    		log.debug("the ip address is not available in ip pool");
    		return associated;
    	
    	/** check whether the ip is associated with other server or not.*/
    	} else if(this.ipAddressSupport.getIpAddress(address).isAssigned()) {
    		log.debug("the ip has been associated to other server!");
    		return associated;
    	}
    	
    	/**associate the ip to the server*/
    	else if( this.ipAddressSupport.isAssigned(AddressType.PRIVATE) ) {
            this.ipAddressSupport.assign(address, serverId);
    	}
    	
    	/** sleep 5 seconds and then check release success or not */
        try { 
        	Thread.sleep(5000L); 
        }
        catch( InterruptedException e ) {
        	
        }
            
        tmpIp = this.ipAddressSupport.getIpAddress(address);
       if(tmpIp.isAssigned()) {
    	   associated = true;
    	   return associated;
       } else {
    	   log.debug("fail to associate the ip to the server!");
    	   return associated;    	
       }
    }
    
    /**
     * @Description work with cloudstack, associate an IP to a server
     * @param addressId
     * @param publicPort
     * @param protocol
     * @param privatePort
     * @param onServerId
     * @return
     * @throws CloudException 
     * @throws InternalException 
     */
    public Map createForwardingRules(Map inparams) throws InternalException, CloudException {
    	System.out.println(">>>>>>>>>>>>>>>>>>>createForwardingRules start");
    	Map<String,Object> result = new HashMap<String,Object>();
    	
    	//String address = (String)inparams.get("publicIpAddress");
    	String addressId = (String)inparams.get("providerIpAddressId");
    	//String addressId = getAddress(address).getProviderIpAddressId();
    	int publicPort = (Integer)inparams.get("publicPort");
    	int privatePort = (Integer)inparams.get("privatePort");
    	String p = (String)inparams.get("protocol");
    	Protocol protocol = (p.equals("TCP")?Protocol.TCP:Protocol.UDP);
    	String onServerId = (String)inparams.get("implinstanceId");
    	System.out.println(">>>>>>>>>>>>>>>>>>>try start");
    	try {
    		System.out.println(">>>>>>>>forward start");
			String rule = this.ipAddressSupport.forward(addressId, publicPort, protocol, privatePort, onServerId);
			System.out.println(">>>>>>>>forward end");
			result.put("result", true);
			result.put("rule", rule);
			return result;
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
    	
    }
    
    /**
     * @Description work with cloudstack, de-associate an IP to a server
     * @param ruleId
     */
    public Map removeForwardingRules(Map inparams) {
    	String implfirewallruleId = (String)inparams.get("implfirewallruleId");
    	FirewallRule firewallRule = FirewallRule.findById(Long.parseLong(implfirewallruleId));
    	String ruleId = firewallRule.implfirewallruleId;
    	Map<String,Object> result = new HashMap<String,Object>();
    	try {
			ipAddressSupport.stopForward(ruleId);
			return result;
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
    	return result;
    }
    
    public Collection<Region> listZone(){
    	try {
			return provider.getDataCenterServices().listRegions();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
    }
    
    // todo, sync more attributes.
	public void synchronizeIPs(){
		Iterable<IpAddress> result=null;
		try {
			result = this.ipAddressSupport.listPublicIpPool(true);
			for(IpAddress ip:result){
				models.IpAddress ips=new models.IpAddress();
				ips.publicIpAddress = ip.getAddress();
				ips.save();
			}
		} catch (CloudException e) {
			e.printStackTrace();
		} catch (InternalException e) {
			e.printStackTrace();
		}
	}
	
}
