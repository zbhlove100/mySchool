package service.networking;

import java.util.Collection;
import java.util.List;

import models.Account;
import models.Domain;
import models.Security;
import models.spec.CurrentUser;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.network.Direction;
import org.dasein.cloud.network.Firewall;
import org.dasein.cloud.network.FirewallSupport;
import org.dasein.cloud.network.Protocol;

import play.cache.Cache;
import play.mvc.Scope;
import service.BaseService;

public class FireWallService extends BaseService {
	private FirewallSupport firewallSupport;
	public FireWallService(String providerId) throws Exception{
		super(providerId);
		firewallSupport=provider.getNetworkServices().getFirewallSupport();
	}
	
	public Collection<Firewall> listFireWall(){
		if(firewallSupport==null){
			return null;
		}
		Collection<Firewall> result=null;
		try {
			result=firewallSupport.list();
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<Security> listFireWallFromDB(){
		Domain domain=new Domain();
		CurrentUser currentuser=(CurrentUser)Cache.get(Scope.Session.current().getId());
		domain.id=currentuser.domainid;
		Account account=new Account();
		account.id=currentuser.id;
		return Security.find("domain=? and state='AVAILABLE' and (ispublic=? or created_by=?) and cloudprovider=?", domain,true,account,this.providerVO).fetch();
	}
	
	public Firewall getSecurityGroup(String providerFirewallId) {
		
		Firewall firewall = null;
		try {
			firewall = firewallSupport.getFirewall(providerFirewallId);
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return firewall;
	}
	
	public String addSecurityGroupRules(String providerFirewallId, String cidr, Protocol protocol, int startPort, int endPort) {
		
		try {
			firewallSupport.authorize(providerFirewallId, cidr, protocol, startPort, endPort);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return getRuleId(providerFirewallId, cidr, Direction.INGRESS, protocol, startPort, endPort);
		
	}
	
	public void removeSecurityGroupRules(String providerFirewallId, String cidr, Protocol protocol, int startPort, int endPort) {
		
		try {
			firewallSupport.revoke(providerFirewallId, cidr, protocol, startPort, endPort);
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    static public String getRuleId(String providerFirewallId, String cidr, Direction direction, Protocol protocol, int startPort, int endPort) {
        return providerFirewallId + ":" + cidr + ":" + direction + ":" + protocol + ":" + startPort + ":" + endPort;
    }

	public String createSecurityGroup(String name, String description) {
		
		String securityGroupId = null;
		try {
			securityGroupId = firewallSupport.create(name, description);
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return securityGroupId;
	}
	
	public void removeSecurityGroup(String providerFirewallId) {
		
		try {
			firewallSupport.delete(providerFirewallId);
		} catch (InternalException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CloudException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Collection<Firewall> synchronizeFireWall(){
		Collection<Firewall> result=null;
		try {
			result=firewallSupport.list();
			
			for(Firewall firewall:result){
//				if(firewall.getName()!=null&&"default".equals(firewall.getName())){
//					continue;
//				}
				Security security=Security.find("cloudprovider_id=? and implsecurityId=?", this.providerVO.id,firewall.getProviderFirewallId()).first();
				if(security==null){
					security=new Security();
				}
				security.name=firewall.getName();
				security.createdAt=new java.util.Date();
				security.ispublic=false;
				Domain domain=new Domain();
				CurrentUser currentuser=(CurrentUser)Cache.get(Scope.Session.current().getId());
				domain.id=currentuser.domainid;
				security.domain=domain;

				security.created_by=new Account(currentuser.id);
				security.state="AVAILABLE";
				security.implsecurityId=firewall.getProviderFirewallId();
				security.cloudprovider=this.providerVO;
				security.description = firewall.getDescription();

				/*Collection<FirewallRule> firewallRules=firewallSupport.getRules(firewall.getProviderFirewallId());
				for(FirewallRule firewallRule:firewallRules){
					models.FirewallRule rule=new models.FirewallRule();
					firewallRule.getProviderRuleId();
					//rule.security=security;
					rule.protocol=firewallRule.getProtocol().name();
					rule.purpose="predined";
					rule.startPort=firewallRule.getStartPort();
					rule.endPort=firewallRule.getEndPort();
					rule.sourceCidr=firewallRule.getCidr();
					rule.createdById=currentuser.id;
					rule.implfirewallruleId=firewallRule.getProviderRuleId();
					rule.createdAt=firewall
					//rule.ip_address
					firewallRule.getCidr();
					rule.save();
				}*/
				security.save();
			}
		} catch (InternalException e) {
			e.printStackTrace();
		} catch (CloudException e) {
			e.printStackTrace();
		}
		return result;
	}
}
