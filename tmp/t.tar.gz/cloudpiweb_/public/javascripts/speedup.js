/**
 * @author Roger Wu
 */
/*@cc_on _d=document;eval('var document=_d')@*/
/*@cc_on eval((function(props) {var code = [];for (var i = 0,l = props.length;i<l;i++){var prop = props[i];window['_'+prop]=window[prop];code.push(prop+'=_'+prop);}return 'var '+code.join(',');})('document self top parent alert setInterval clearInterval setTimeout clearTimeout'.split(' ')))@*/