$("#mytype").change(function(){
	if($("#mytype").val() !=null && $("#mytype").val()=="AWS"){
		$("#showOrhide1").html("<p><label>Account Number:</label><input name=\"object.cloudproviderDetails[2].name\" id=\"accountNumber\"  type=\"hidden\"    value=\"accountNumber\"/><input name=\"object.cloudproviderDetails[2].value\" id=\"accountNumbervalue\"   type=\"text\"   /></p><p><label>Access Key:</label><input name=\"object.cloudproviderDetails[0].name\" id=\"apiSharedKey\" type=\"hidden\"    value=\"apiSharedKey\"/><input name=\"object.cloudproviderDetails[0].value\" id=\"apiSharedKeyvalue\"    type=\"text\"   /></p><p><label>Secret Key:</label><input name=\"object.cloudproviderDetails[1].name\" id=\"apiSecretKey\"  type=\"hidden\"    value=\"apiSecretKey\"/><input name=\"object.cloudproviderDetails[1].value\"  id=\"apiSecretKeyvalue\"   type=\"text\"   /></p><p><label>End Point:</label><input name=\"object.cloudproviderDetails[3].name\"  id=\"endpoint\"  type=\"hidden\"    value=\"endpoint\"/><input name=\"object.cloudproviderDetails[3].value\" id=\"endpointvalue\" value=\"http://amazon.com\" type=\"text\"   /></p><p><label>Region Id:</label><input name=\"object.cloudproviderDetails[4].name\" id=\"regionId\"  type=\"hidden\"    value=\"regionId\"/><input name=\"object.cloudproviderDetails[4].value\" id=\"regionIdvalue\"     type=\"text\"   /></p>");
	}
	if($("#mytype").val() !=null && $("#mytype").val()=="CLOUDSTACK"){
		$("#showOrhide1").html("<p> <label>Access Key:</label> <input name=\"object.cloudproviderDetails[0].name\" id=\"apiSharedKey\" type=\"hidden\"  value=\"apiSharedKey\"/><input name=\"object.cloudproviderDetails[0].value\" id=\"apiSharedKeyvalue\"   type=\"text\"   /></p><p><label>Secret Key:</label><input name=\"object.cloudproviderDetails[1].name\" id=\"apiSecretKey\" type=\"hidden\"  value=\"apiSecretKey\"/><input name=\"object.cloudproviderDetails[1].value\" id=\"apiSecretKeyvalue\"  type=\"text\"   /></p><p><label>End Point:</label><input name=\"object.cloudproviderDetails[2].name\"  id=\"endpoint\"  type=\"hidden\"  value=\"endpoint\"/><input name=\"object.cloudproviderDetails[2].value\" id=\"endpointvalue\"   type=\"text\"   /></p><p><label>Zone Id:</label><input name=\"object.cloudproviderDetails[3].name\" id=\"regionId\"  type=\"hidden\"    value=\"regionId\"/><input name=\"object.cloudproviderDetails[3].value\" id=\"regionIdvalue\"     type=\"text\"   /></p><p><label>accountNumber:</label><input name=\"object.cloudproviderDetails[4].name\" id=\"acountNumber\"  type=\"hidden\"    value=\"accountNumber\"/><input name=\"object.cloudproviderDetails[4].value\" id=\"accountNumbervalue\"     type=\"text\"   /></p>	");
	}
	if($("#mytype").val() !=null && $("#mytype").val()=="RACKSPACE"){
		$("#showOrhide1").html("<p> <label>Account Number:</label> <input name=\"object.cloudproviderDetails[0].name\" id=\"apiSharedKey\" type=\"hidden\"  value=\"apiSharedKey\"/><input name=\"object.cloudproviderDetails[0].value\" id=\"apiShareKeyvalue\"   type=\"text\"   /></p><p><label>API Key:</label><input name=\"object.cloudproviderDetails[1].name\" id=\"apiKey\" type=\"hidden\"  value=\"apiSecretKey\"/><input name=\"object.cloudproviderDetails[1].value\" id=\"apikeyvalue\"  type=\"text\"   /></p><p><label>End Point:</label><input name=\"object.cloudproviderDetails[2].name\"  id=\"endpoint\"  type=\"hidden\"  value=\"endpoint\"/><input name=\"object.cloudproviderDetails[2].value\" id=\"endpointvalue\" value=\"https://auth.api.rackspacecloud.com/v1.0\" type=\"text\"   /></p><p><label>Region Id:</label><input name=\"object.cloudproviderDetails[3].name\" id=\"regionId\"  type=\"hidden\"    value=\"regionId\"/><input name=\"object.cloudproviderDetails[3].value\" id=\"regionIdvalue\"     type=\"text\"   /></p>	");
	}	
	if($("#mytype").val() !=null && $("#mytype").val()=="OPENSTACK"){
		$("#showOrhide1").html("<p> <label>Account Number:</label> <input name=\"object.cloudproviderDetails[3].name\" id=\"accountNumber\" type=\"hidden\"  value=\"accountNumber\"/><input name=\"object.cloudproviderDetails[3].value\" id=\"accountNumbervalue\"   type=\"text\"   /></p><p> <label>Access Key:</label> <input name=\"object.cloudproviderDetails[0].name\" id=\"publickey\" type=\"hidden\"  value=\"apiSharedKey\"/><input name=\"object.cloudproviderDetails[0].value\" id=\"publickeyvalue\"   type=\"text\"   /></p><p><label>Secret Key:</label><input name=\"object.cloudproviderDetails[1].name\" id=\"privatekey\" type=\"hidden\"  value=\"apiSecretKey\"/><input name=\"object.cloudproviderDetails[1].value\" id=\"privatekeyvalue\"  type=\"text\"   /></p><p><label>End Point:</label><input name=\"object.cloudproviderDetails[2].name\"  id=\"endpoint\"  type=\"hidden\"  value=\"endpoint\"/><input name=\"object.cloudproviderDetails[2].value\" id=\"endpointvalue\"   type=\"text\"   /></p>");		
	}
	if($("#mytype").val() !=null && $("#mytype").val()=="SWIFT"){
		$("#showOrhide1").html("<p><label>Account Number:</label><input name=\"object.cloudproviderDetails[2].name\" id=\"accountNumber\"  type=\"hidden\"    value=\"accountNumber\"/><input name=\"object.cloudproviderDetails[2].value\" id=\"accountNumbervalue\"   type=\"text\"   /></p><p><label>Access Key:</label><input name=\"object.cloudproviderDetails[0].name\" id=\"apiSharedKey\" type=\"hidden\"    value=\"apiSharedKey\"/><input name=\"object.cloudproviderDetails[0].value\" id=\"apiSharedKeyvalue\"    type=\"text\"   /></p><p><label>Secret Key:</label><input name=\"object.cloudproviderDetails[1].name\" id=\"apiSecretKey\"  type=\"hidden\"    value=\"apiSecretKey\"/><input name=\"object.cloudproviderDetails[1].value\"  id=\"apiSecretKeyvalue\"   type=\"text\"   /></p><p><label>End Point:</label><input name=\"object.cloudproviderDetails[3].name\"  id=\"endpoint\"  type=\"hidden\"    value=\"endpoint\"/><input name=\"object.cloudproviderDetails[3].value\" id=\"endpointvalue\" value=\"\" type=\"text\"   /></p><p><label>Region Id:</label><input name=\"object.cloudproviderDetails[4].name\" id=\"regionId\"  type=\"hidden\"    value=\"regionId\"/><input name=\"object.cloudproviderDetails[4].value\" id=\"regionIdvalue\"     type=\"text\"   /></p>");
	}
});

//Created by liubs
function DrapDropBar(tabid){
	var resizing = false;
	
	var pbid = "#"+ tabid + "Bar";
	var tabledivid = "#"+ tabid + "TableDiv";
	var tableid = "#"+ tabid + "Table";
	var tabsdivid = "#"+ tabid + "TabsDiv";
	
	$(pbid).mouseup(function(e) {
	    resizing = false;
	});
	
	$(pbid).mousedown(function(e) {
	    resizing = true;
	});
	
	$(".pageContent").mousemove(function(e) {
		if(resizing) {
	       var tablediv = $(tabledivid);
	       var table = $(tableid);
			var scroller = $(tableid).children('.gridScroller');
			
	       var tabsdiv = $(tabsdivid);
	        				
		    var origHeightDiv = tablediv.height();
	       var origHeightTable = table.height();
	       var origHeightScroll = scroller.height();
	       var origHeightTabs = tabsdiv.height();
	
		        
	       var origPosYGrip = $(pbid).offset().top;
	       var gripHeight = $(pbid).height();
	        
	       tablediv.height(e.pageY - origPosYGrip + origHeightDiv - gripHeight/2);
	       table.height(e.pageY - origPosYGrip + origHeightTable - gripHeight/2);
	       scroller.height(e.pageY - origPosYGrip + origHeightScroll - gripHeight/2);
	       tabsdiv.height(e.pageY + origPosYGrip - origHeightTable + gripHeight/2);
       
		}
	});  	
}