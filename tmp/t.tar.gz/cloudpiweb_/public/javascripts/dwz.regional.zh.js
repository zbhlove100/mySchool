/**
 * @author ZhangHuihua@msn.com
 */
(function($){
	// jQuery validate
	$.extend($.validator.messages, {
		required: "Required field",
		remote: "Please correct the fields",
		email: "Please enter the correct e-mail format",
		url: "Please enter a valid address",
		date: "Please enter a valid date",
		dateISO: "Please enter a valid date (ISO).",
		number: "Please enter a valid number",
		digits: "Please enter valid digits",
		creditcard: "Please enter a valid credit card number",
		equalTo: "Please re-enter the same value",
		accept: "Please enter a legitimate extension of the string",
		maxlength: $.validator.format("Maximum length of string is {0}"),
		minlength: $.validator.format("Minimum length of string is {0}"),
		rangelength: $.validator.format("Length between {0} and {1} string"),
		range: $.validator.format("Please enter a number from {0} and {1} value between"),
		max: $.validator.format("Please enter a maximum value of {0}"),
		min: $.validator.format("Please enter a minimum value of {0}"),
		
		alphanumeric: "Letters, numbers, underscores",
		lettersonly: "Must be a letter",
		phone: "Numbers, spaces, brackets"
	});
	
	// DWZ regional
	$.setRegional("datepicker", {
		dayNames: ['日', '一', '二', '三', '四', '五', '六'],
		monthNames: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月']
	});
	$.setRegional("alertMsg", {
		title:{error:"error", info:"info", warn:"warn", correct:"correct", confirm:"Confirmation"},
		butMsg:{ok:"ok", yes:"yes", no:"no", cancel:"cancel"}
	});
})(jQuery);