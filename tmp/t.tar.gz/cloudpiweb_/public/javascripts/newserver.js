function showmsg(tt){
	switch(tt){
	case 1:
		$("#msgid1").show();
		$("#msgid2").hide();
		$("#msgid3").hide();
		$("#keypair").val("");
		break;
	case 2:
		$("#msgid1").hide();
		$("#msgid2").show();
		$("#msgid3").hide();
		$("#keypair").val("");
		break;
	default:
		$("#msgid1").hide();
		$("#msgid2").hide();
		$("#msgid3").show();
		$("input[type='hidden'][name=keypair]").val('none');
	}
}
function dialogAjaxDone2(json){
	DWZ.ajaxDone(json);
	if (json.statusCode == DWZ.statusCode.ok){
		$.pdialog.reload(json.forwardUrl,null);
	}
}
function back(){
	var temp=$("input[name=step]").val();
	temp=temp-2;
	$("input[name=step]").val(temp);
	$.ajax({
		type: 'POST',
		url:"/servers/save",
		dataType:"json",
		data:$("form[action=/servers/save]").serializeArray(),
		cache: false,
		success: dialogAjaxDone2,
		error: DWZ.ajaxError
	});
}
function selectType(cloudtype){
	var result=new Array();
	var url="/Servers/seleccloudtype?cloudtype="+cloudtype;   
        $.ajax({
            url: url,   //接收页面
            type: 'post',      //POST方式发送数据
            async: false,      //ajax同步
            success: function(data) {
            	 for(var i=0;i<data.length;i++){
						result[i]=new Array(data[i].id,data[i].name);
				  }  
            }
        });
        return result;
}
function save(){
	var temp=$("input[name=step]").val();
	$("input[name=step]").val(temp);
	if (!$("form[action=/servers/save]").valid()) {
		return false;
	}
	$.ajax({
		type: 'POST',
		url:"/servers/save",
		dataType:"json",
		data:$("form[action=/servers/save]").serializeArray(),
		cache: false,
		success: dialogAjaxDone,
		error: DWZ.ajaxError
	});
}
function createKeyPair(){
	var temp=$("#keypairname").val();
	if(temp==null||temp==''){
		alert("please enter the keypair name");
		return false;
	}
	var url="/servers/createKeyPair?keypairname="+temp;
	$.ajax({
		type: 'POST',
		url:url,
		dataType:"json",
		cache: false,
		success: function(json){
				if(json=='fail'){
					alert("create keypair failed!");
				}else{
					$("#keypair").attr("innerHTML",json.html);
					$("#msgid2").hide();
					$("input[type='hidden'][name=keypair]").val(json.result.id);
				}
			},
		error: DWZ.ajaxError
	});
}

function connectSever(){
	var i=0;
	var ids='';
	$("[name='ids']").each(function(){
		if($(this).attr('checked')==true)
		{
			i++;
			ids=$(this).val();
		}
		});
	if(i>1){
		alert("You can't select multiservers!");
		return false;
	}
	if(i<1){
		alert("Please select the server you will connect to");
		return false;
	}
	var url="/servers/connectSever?serverId="+ids;
	
	var options = {};
	options.width = 500;
	options.height = 500;
	
	$.pdialog.open(url, "_blank", "Connect Help-Secure Shell(ssh)", options);
}
function selectKeyPair(keypairselect){
	$("input[type='hidden'][name=keypair]").val(keypairselect);
}
