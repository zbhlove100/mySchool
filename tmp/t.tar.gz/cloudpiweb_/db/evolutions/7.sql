# --- !Ups

insert into setting(name,`value`) values ('view', 'USA');
insert into setting(name,`value`) values ('view', 'China');
insert into setting(name,`value`) values ('view', 'Korea');
insert into setting(name,`value`) values ('view', 'Singapore');
insert into setting(name,`value`) values ('view', 'Others');