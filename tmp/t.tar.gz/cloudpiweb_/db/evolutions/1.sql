/*
Cloudpi db
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `account`
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain_id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL COMMENT 'type(sha,md5):hashvalue',
  `email` varchar(100) DEFAULT NULL,
  `api_key` varchar(255) DEFAULT NULL,
  `secret_key` varchar(255) DEFAULT NULL,
  `timezone` varchar(30) DEFAULT NULL,
  `is_supper` bit(1) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL COMMENT 'if not null, the record will be hidden for any user except root',
  `password_base64` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Index_1` (`username`),
  KEY `FK_Reference_2` (`domain_id`),
  KEY `FK_Reference_3` (`role_id`),
  CONSTRAINT `FK_Reference_2` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_3` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of account
-- ----------------------------
INSERT INTO `account` VALUES ('1', '1', 'root', '341c3ac76bfb54cb02d6a689caba6641', null, null, null, null, '', '1', 'Active', null, '2011-10-23 06:15:50', null, 'Y2xvdWRwaQ==');


-- ----------------------------
-- Table structure for `alert`
-- ----------------------------
DROP TABLE IF EXISTS `alert`;
CREATE TABLE `alert` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `description` text,
  `state` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_11` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_11` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of alert
-- ----------------------------

-- ----------------------------
-- Table structure for `application`
-- ----------------------------
DROP TABLE IF EXISTS `application`;
CREATE TABLE `application` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `project_id` bigint(20) NOT NULL,
  `target_id` bigint(20) NOT NULL,
  `url` varchar(512) DEFAULT NULL,
  `branch` varchar(20) DEFAULT NULL,
  `tag` varchar(20) DEFAULT NULL,
  `instances` bigint(5) NOT NULL DEFAULT '1',
  `account_id` bigint(20) NOT NULL,
  `memory` bigint(20) NOT NULL,
  `status` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_APPLICATION_TARGET` (`target_id`),
  KEY `FK_APPLICATION_ACCOUNT` (`account_id`),
  KEY `FK_APPLICATION_PROJECT` (`project_id`),
  CONSTRAINT `FK_APPLICATION_ACCOUNT` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_APPLICATION_PROJECT` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_APPLICATION_TARGET` FOREIGN KEY (`target_id`) REFERENCES `target` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of application
-- ----------------------------

-- ----------------------------
-- Table structure for `application_autoscale`
-- ----------------------------
DROP TABLE IF EXISTS `application_autoscale`;
CREATE TABLE `application_autoscale` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `application_id` bigint(20) NOT NULL,
  `is_enable` bigint(5) NOT NULL DEFAULT '0',
  `min_instance` bigint(10) DEFAULT NULL,
  `max_instance` bigint(10) DEFAULT NULL,
  `metric_measurement` varchar(100) DEFAULT NULL,
  `metric_period` bigint(10) DEFAULT NULL,
  `metric_statistic` varchar(20) DEFAULT NULL,
  `upper_threthod` decimal(10,2) DEFAULT NULL,
  `lower_threthod` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_APPLICATION_AUTOSCALE` (`application_id`),
  CONSTRAINT `FK_APPLICATION_AUTOSCALE` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of application_autoscale
-- ----------------------------
INSERT INTO `application_autoscale` VALUES ('7', '80', '1', '3', '3', '', '0', '', '0.00', '0.00');

-- ----------------------------
-- Table structure for `application_service`
-- ----------------------------
DROP TABLE IF EXISTS `application_service`;
CREATE TABLE `application_service` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `application_id` bigint(20) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_APPLICATION_SERVICE` (`application_id`),
  CONSTRAINT `FK_APPLICATION_SERVICE` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of application_service
-- ----------------------------

-- ----------------------------
-- Table structure for `cloudprovider`
-- ----------------------------
DROP TABLE IF EXISTS `cloudprovider`;
CREATE TABLE `cloudprovider` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ispublic` bit(1) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `location` varchar(200) DEFAULT NULL,
  `provider` varchar(200) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cloudprovider
-- ----------------------------

-- ----------------------------
-- Table structure for `cloudprovider_detail`
-- ----------------------------
DROP TABLE IF EXISTS `cloudprovider_detail`;
CREATE TABLE `cloudprovider_detail` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `account_id` bigint(20) DEFAULT NULL COMMENT 'if account is just for user, should query details by account_id',
  `implaccount_id` varchar(20) DEFAULT NULL,
  `impluser_id` varchar(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_41` (`account_id`),
  KEY `FK_Reference_42` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_41` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_Reference_42` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=473 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cloudprovider_detail
-- ----------------------------

-- ----------------------------
-- Table structure for `container`
-- ----------------------------
DROP TABLE IF EXISTS `container`;
CREATE TABLE `container` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `put_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `object_count` bigint(20) DEFAULT NULL,
  `bytes_used` bigint(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `removed_at` timestamp NULL DEFAULT NULL,
  `zone_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_56` (`created_by_id`),
  CONSTRAINT `FK_Reference_56` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of container
-- ----------------------------

-- ----------------------------
-- Table structure for `dns`
-- ----------------------------
DROP TABLE IF EXISTS `dns`;
CREATE TABLE `dns` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bak` varchar(255) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `userid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dns
-- ----------------------------

-- ----------------------------
-- Table structure for `dns_dnstarget`
-- ----------------------------
DROP TABLE IF EXISTS `dns_dnstarget`;
CREATE TABLE `dns_dnstarget` (
  `dnses_id` bigint(20) NOT NULL,
  `dnsTargets_id` bigint(20) NOT NULL,
  KEY `FK1FE8946497576248` (`dnses_id`),
  KEY `FK1FE894649A13DCD7` (`dnsTargets_id`),
  CONSTRAINT `FK1FE8946497576248` FOREIGN KEY (`dnses_id`) REFERENCES `dns` (`id`),
  CONSTRAINT `FK1FE894649A13DCD7` FOREIGN KEY (`dnsTargets_id`) REFERENCES `dnstarget` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dns_dnstarget
-- ----------------------------

INSERT INTO `dns_dnstarget` VALUES ('62', '80');

-- ----------------------------
-- Table structure for `dnsrecord`
-- ----------------------------
DROP TABLE IF EXISTS `dnsrecord`;
CREATE TABLE `dnsrecord` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `dnszone_id` bigint(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `ttl` int(11) DEFAULT NULL,
  `priority` smallint(6) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `view` varchar(100) NOT NULL,
  `impldnsrecord_id` varchar(255) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_35` (`dnszone_id`),
  CONSTRAINT `FK_Reference_35` FOREIGN KEY (`dnszone_id`) REFERENCES `dnszone` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dnsrecord
-- ----------------------------

-- ----------------------------
-- Table structure for `dnstarget`
-- ----------------------------
DROP TABLE IF EXISTS `dnstarget`;
CREATE TABLE `dnstarget` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bak` varchar(255) DEFAULT NULL,
  `createdon` datetime DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `routeip` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `zonerecordid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dnstarget
-- ----------------------------


-- ----------------------------
-- Table structure for `dnszone`
-- ----------------------------
DROP TABLE IF EXISTS `dnszone`;
CREATE TABLE `dnszone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `impldnszone_id` varchar(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_38` (`domain_id`),
  CONSTRAINT `FK_Reference_38` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dnszone
-- ----------------------------

-- ----------------------------
-- Table structure for `domain`
-- ----------------------------
DROP TABLE IF EXISTS `domain`;
CREATE TABLE `domain` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKB0F3D4C43B711875` (`created_by_id`),
  CONSTRAINT `FKB0F3D4C43B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of domain
-- ----------------------------
INSERT INTO `domain` VALUES ('1', 'root', 'Active', null, '2011-09-26 09:38:15', null);



-- ----------------------------
-- Table structure for `domain_cloudprovider`
-- ----------------------------
DROP TABLE IF EXISTS `domain_cloudprovider`;
CREATE TABLE `domain_cloudprovider` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain_id` bigint(20) DEFAULT NULL,
  `cloudprovider_id` bigint(20) NOT NULL,
  `impldomain_id` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_6` (`cloudprovider_id`),
  KEY `FK_Reference_7` (`domain_id`),
  CONSTRAINT `FK_Reference_6` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK_Reference_7` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of domain_cloudprovider
-- ----------------------------

-- ----------------------------
-- Table structure for `domain_target`
-- ----------------------------
DROP TABLE IF EXISTS `domain_target`;
CREATE TABLE `domain_target` (
  `domain_id` bigint(20) NOT NULL,
  `target_id` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`domain_id`,`target_id`),
  KEY `FK_Reference_9` (`target_id`),
  CONSTRAINT `FK_Reference_10` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_9` FOREIGN KEY (`target_id`) REFERENCES `target` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of domain_target
-- ----------------------------

-- ----------------------------
-- Table structure for `event`
-- ----------------------------
DROP TABLE IF EXISTS `event`;
CREATE TABLE `event` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(100) NOT NULL,
  `description` text,
  `level` varchar(10) NOT NULL,
  `trace_url` varchar(512) DEFAULT NULL,
  `rawdata` text,
  `state` varchar(100) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_1` (`created_by_id`),
  CONSTRAINT `FK_Reference_1` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4836 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of event
-- ----------------------------


-- ----------------------------
-- Table structure for `firewall_rule`
-- ----------------------------
DROP TABLE IF EXISTS `firewall_rule`;
CREATE TABLE `firewall_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_id` bigint(20) DEFAULT NULL,
  `ip_address_id` bigint(20) NOT NULL,
  `purpose` varchar(32) DEFAULT NULL,
  `protocol` varchar(16) NOT NULL,
  `start_port` int(11) DEFAULT NULL,
  `end_port` int(11) DEFAULT NULL,
  `source_cidr` varchar(1000) DEFAULT NULL COMMENT 'split with ,',
  `implfirewallrule_id` varchar(20) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `state` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_52` (`ip_address_id`),
  CONSTRAINT `FK_Reference_48` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`),
  CONSTRAINT `FK_Reference_52` FOREIGN KEY (`ip_address_id`) REFERENCES `ip_address` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of firewall_rule
-- ----------------------------

-- ----------------------------
-- Table structure for `firewall_rule_cidr`
-- ----------------------------
DROP TABLE IF EXISTS `firewall_rule_cidr`;
CREATE TABLE `firewall_rule_cidr` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `source_cidr` varchar(255) DEFAULT NULL,
  `firewallRule_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of firewall_rule_cidr
-- ----------------------------

-- ----------------------------
-- Table structure for `hq_agent`
-- ----------------------------
DROP TABLE IF EXISTS `hq_agent`;
CREATE TABLE `hq_agent` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `serviceprovider_id` bigint(20) NOT NULL,
  `server_id` bigint(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `agent_ip` varchar(15) DEFAULT NULL,
  `implagent_id` varchar(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_20` (`serviceprovider_id`),
  KEY `FK_Reference_21` (`server_id`),
  CONSTRAINT `FK_Reference_20` FOREIGN KEY (`serviceprovider_id`) REFERENCES `serviceprovider` (`id`),
  CONSTRAINT `FK_Reference_21` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hq_agent
-- ----------------------------

-- ----------------------------
-- Table structure for `hq_alert`
-- ----------------------------
DROP TABLE IF EXISTS `hq_alert`;
CREATE TABLE `hq_alert` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) NOT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `reason` varchar(500) NOT NULL,
  `detail` varchar(100) DEFAULT NULL,
  `implalert_id` varchar(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  `hqAgent_id` bigint(20) DEFAULT NULL,
  `hqResource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_23` (`agent_id`),
  KEY `FK_Reference_24` (`resource_id`),
  CONSTRAINT `FK_Reference_23` FOREIGN KEY (`agent_id`) REFERENCES `hq_agent` (`id`),
  CONSTRAINT `FK_Reference_24` FOREIGN KEY (`resource_id`) REFERENCES `hq_resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hq_alert
-- ----------------------------

-- ----------------------------
-- Table structure for `hq_resource`
-- ----------------------------
DROP TABLE IF EXISTS `hq_resource`;
CREATE TABLE `hq_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `implresource_id` varchar(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  `hqAgent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_22` (`agent_id`),
  CONSTRAINT `FK_Reference_22` FOREIGN KEY (`agent_id`) REFERENCES `hq_agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hq_resource
-- ----------------------------

-- ----------------------------
-- Table structure for `ip_address`
-- ----------------------------
DROP TABLE IF EXISTS `ip_address`;
CREATE TABLE `ip_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) DEFAULT NULL,
  `zone_id` bigint(20) DEFAULT NULL,
  `domain_id` bigint(20) DEFAULT NULL,
  `network_id` bigint(20) DEFAULT NULL,
  `account_id` bigint(20) DEFAULT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `public_ip_address` varchar(20) NOT NULL,
  `source_nat` int(11) NOT NULL,
  `allocated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `mac_address` varchar(50) DEFAULT NULL,
  `one_to_one_nat` int(11) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_49` (`domain_id`),
  KEY `FK_Reference_53` (`network_id`),
  CONSTRAINT `FK_Reference_49` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_53` FOREIGN KEY (`network_id`) REFERENCES `network` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ip_address
-- ----------------------------

-- ----------------------------
-- Table structure for `network`
-- ----------------------------
DROP TABLE IF EXISTS `network`;
CREATE TABLE `network` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `traffic_type` varchar(20) DEFAULT NULL,
  `boadcast_domain_type` varchar(50) DEFAULT NULL,
  `gateway` varchar(16) NOT NULL,
  `cidr` varchar(18) NOT NULL,
  `mode` varchar(10) DEFAULT NULL,
  `dns1` varchar(500) DEFAULT NULL,
  `dns2` varchar(500) DEFAULT NULL,
  `network_domain` varchar(100) DEFAULT NULL,
  `isdefault` bit(1) NOT NULL,
  `implnetwork_id` varchar(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_45` (`domain_id`),
  CONSTRAINT `FK_Reference_45` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of network
-- ----------------------------

-- ----------------------------
-- Table structure for `object`
-- ----------------------------
DROP TABLE IF EXISTS `object`;
CREATE TABLE `object` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `container_id` bigint(20) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `size` bigint(20) DEFAULT NULL,
  `coutent_type` varchar(20) DEFAULT NULL,
  `etag` varchar(50) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL COMMENT 'if not null, the record will be hidden for any user except root',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_54` (`container_id`),
  CONSTRAINT `FK_Reference_54` FOREIGN KEY (`container_id`) REFERENCES `container` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of object
-- ----------------------------

-- ----------------------------
-- Table structure for `play_evolutions`
-- ----------------------------
DROP TABLE IF EXISTS `play_evolutions`;
CREATE TABLE `play_evolutions` (
  `id` int(11) NOT NULL,
  `hash` varchar(255) NOT NULL,
  `applied_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `apply_script` text,
  `revert_script` text,
  `state` varchar(255) DEFAULT NULL,
  `last_problem` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of play_evolutions
-- ----------------------------


-- ----------------------------
-- Table structure for `product`
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `implproduct_id` varchar(100) DEFAULT NULL,
  `bits` int(11) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_40` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_40` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of product
-- ----------------------------

-- ----------------------------
-- Table structure for `product_property`
-- ----------------------------
DROP TABLE IF EXISTS `product_property`;
CREATE TABLE `product_property` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `product_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_31` (`product_id`),
  CONSTRAINT `FK_Reference_31` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='cpu, speed, ramsize, limit_cpu_use\r\nt1.micro\r\nalso';

-- ----------------------------
-- Records of product_property
-- ----------------------------

-- ----------------------------
-- Table structure for `project`
-- ----------------------------
DROP TABLE IF EXISTS `project`;
CREATE TABLE `project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `runtime` varchar(50) DEFAULT NULL,
  `framework` varchar(50) DEFAULT NULL,
  `account_id` bigint(20) NOT NULL,
  `description` varchar(512) DEFAULT NULL,
  `git_url` varchar(512) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `domain_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_PROJECT_DOMAIN` (`domain_id`),
  KEY `FK_PROJECT_ACCOUNT` (`account_id`),
  CONSTRAINT `FK_PROJECT_ACCOUNT` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_PROJECT_DOMAIN` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of project
-- ----------------------------

-- ----------------------------
-- Table structure for `project_event`
-- ----------------------------
DROP TABLE IF EXISTS `project_event`;
CREATE TABLE `project_event` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `target_name` varchar(100) NOT NULL,
  `application_name` varchar(100) NOT NULL,
  `project_id` bigint(20) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `event_detail` varchar(1000) DEFAULT NULL,
  `event_type` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_EVENT_ACCOUNT` (`account_id`),
  KEY `FK_PROJECT_EVENT` (`project_id`),
  CONSTRAINT `FK_PROJECT_EVENT` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of project_event
-- ----------------------------

-- ----------------------------
-- Table structure for `property`
-- ----------------------------
DROP TABLE IF EXISTS `property`;
CREATE TABLE `property` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clsid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of property
-- ----------------------------

-- ----------------------------
-- Table structure for `quota`
-- ----------------------------
DROP TABLE IF EXISTS `quota`;
CREATE TABLE `quota` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain_id` bigint(20) NOT NULL,
  `cloudprovider_id` bigint(20) NOT NULL,
  `instance_limit` int(11) NOT NULL DEFAULT '-1',
  `ip_limit` int(11) NOT NULL DEFAULT '-1',
  `template_limit` int(11) NOT NULL DEFAULT '-1',
  `volume_limit` int(11) NOT NULL DEFAULT '-1',
  `snapshot_limit` int(11) NOT NULL DEFAULT '-1',
  PRIMARY KEY (`id`),
  KEY `FK_Reference_8` (`domain_id`),
  CONSTRAINT `FK_Reference_8` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='limit = -1 is no limit';

-- ----------------------------
-- Records of quota
-- ----------------------------

-- ----------------------------
-- Table structure for `resource`
-- ----------------------------
DROP TABLE IF EXISTS `resource`;
CREATE TABLE `resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL COMMENT 'three roles: root,domainadmin,user',
  `resource` varchar(500) NOT NULL COMMENT 'menu,url,data,vo...',
  `action` varchar(100) NOT NULL COMMENT 'support wildchar?',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of resource
-- ----------------------------

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL COMMENT 'three roles: domainadmin,user',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', 'root');
INSERT INTO `role` VALUES ('2', 'domainadmin');
INSERT INTO `role` VALUES ('3', 'user');

-- ----------------------------
-- Table structure for `role_resource`
-- ----------------------------
DROP TABLE IF EXISTS `role_resource`;
CREATE TABLE `role_resource` (
  `role_id` bigint(20) NOT NULL COMMENT 'three roles: root,domainadmin,user',
  `resource_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  `resources_id` bigint(20) NOT NULL,
  KEY `FK_Reference_4` (`roles_id`),
  KEY `FK_Reference_5` (`resources_id`),
  CONSTRAINT `FK_Reference_4` FOREIGN KEY (`roles_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FK_Reference_5` FOREIGN KEY (`resources_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role_resource
-- ----------------------------

-- ----------------------------
-- Table structure for `scalr_setting`
-- ----------------------------
DROP TABLE IF EXISTS `scalr_setting`;
CREATE TABLE `scalr_setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `access_url` varchar(512) NOT NULL,
  `admin_api_key` varchar(100) NOT NULL,
  `admin_api_key_secret` varchar(100) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of scalr_setting
-- ----------------------------

-- ----------------------------
-- Table structure for `security`
-- ----------------------------
DROP TABLE IF EXISTS `security`;
CREATE TABLE `security` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) DEFAULT NULL,
  `domain_id` bigint(20) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ispublic` bit(1) NOT NULL COMMENT 'all created by user is only for private',
  `implsecurity_id` varchar(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `description` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_44` (`created_by_id`),
  KEY `FK_Reference_46` (`domain_id`),
  CONSTRAINT `FK_Reference_44` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_Reference_46` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of security
-- ----------------------------


-- ----------------------------
-- Table structure for `security_rule`
-- ----------------------------
DROP TABLE IF EXISTS `security_rule`;
CREATE TABLE `security_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) DEFAULT NULL,
  `security_id` bigint(20) NOT NULL,
  `protocol` varchar(16) NOT NULL,
  `start_port` int(11) DEFAULT NULL,
  `end_port` int(11) DEFAULT NULL,
  `allowed_ip_cidrs` varchar(44) NOT NULL COMMENT 'split with ,',
  `implsecurityrule_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_43` (`security_id`),
  CONSTRAINT `FK_Reference_43` FOREIGN KEY (`security_id`) REFERENCES `security` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of security_rule
-- ----------------------------

-- ----------------------------
-- Table structure for `server`
-- ----------------------------
DROP TABLE IF EXISTS `server`;
CREATE TABLE `server` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) NOT NULL,
  `domain_id` bigint(20) NOT NULL,
  `cloudprovider_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `template_id` bigint(20) NOT NULL,
  `ssh_keypair_id` bigint(20) DEFAULT NULL,
  `private_ip` varchar(32) DEFAULT NULL,
  `hypervisor_type` varchar(20) DEFAULT NULL,
  `implinstance_id` varchar(20) DEFAULT NULL,
  `ismonitor` bit(1) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  `metric_id` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_14` (`domain_id`),
  KEY `FK_Reference_15` (`cloudprovider_id`),
  KEY `FK_Reference_25` (`zone_id`),
  KEY `FK_Reference_32` (`product_id`),
  CONSTRAINT `FK_Reference_14` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_15` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK_Reference_25` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`),
  CONSTRAINT `FK_Reference_32` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=108 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of server
-- ----------------------------

-- ----------------------------
-- Table structure for `server_property`
-- ----------------------------
DROP TABLE IF EXISTS `server_property`;
CREATE TABLE `server_property` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `server_id` bigint(20) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `value` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_12` (`server_id`),
  CONSTRAINT `FK_Reference_12` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of server_property
-- ----------------------------

-- ----------------------------
-- Table structure for `service`
-- ----------------------------
DROP TABLE IF EXISTS `service`;
CREATE TABLE `service` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `bak` varchar(900) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `registered` int(11) NOT NULL,
  `registered_date` datetime DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `owned_by_id` bigint(20) DEFAULT NULL,
  `used_by_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7643C6B554E7D18A` (`used_by_id`),
  KEY `FK7643C6B5E74E0A72` (`owned_by_id`),
  CONSTRAINT `FK7643C6B554E7D18A` FOREIGN KEY (`used_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK7643C6B5E74E0A72` FOREIGN KEY (`owned_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of service
-- ----------------------------

-- ----------------------------
-- Table structure for `serviceprovider`
-- ----------------------------
DROP TABLE IF EXISTS `serviceprovider`;
CREATE TABLE `serviceprovider` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cloudprovider_id` bigint(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_47` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_47` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of serviceprovider
-- ----------------------------

-- ----------------------------
-- Table structure for `serviceprovider_property`
-- ----------------------------
DROP TABLE IF EXISTS `serviceprovider_property`;
CREATE TABLE `serviceprovider_property` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `serviceprovider_id` bigint(20) NOT NULL COMMENT 'class'' name +"_"+ id',
  `name` varchar(500) NOT NULL,
  `value` text,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_50` (`serviceprovider_id`),
  CONSTRAINT `FK_Reference_50` FOREIGN KEY (`serviceprovider_id`) REFERENCES `serviceprovider` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='for hp server: host user password\r\nfor scalr: scalr_key';

-- ----------------------------
-- Records of serviceprovider_property
-- ----------------------------

-- ----------------------------
-- Table structure for `setting`
-- ----------------------------
DROP TABLE IF EXISTS `setting`;
CREATE TABLE `setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `value` varchar(500) DEFAULT NULL,
  `extvalue` varchar(500) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of setting
-- ----------------------------
INSERT INTO `setting` VALUES ('1', 'pagesize', '20', null, null);
INSERT INTO `setting` VALUES ('2', 'AWS', 'Ec2 Instances', null, null);
INSERT INTO `setting` VALUES ('3', 'AWS', 'Ec2 Images', null, null);
INSERT INTO `setting` VALUES ('4', 'AWS', 'Ec2 Security Groups', null, null);
INSERT INTO `setting` VALUES ('5', 'AWS', 'Ec2 SSH Keys', null, null);
INSERT INTO `setting` VALUES ('6', 'AWS', 'Ec2 Licenses', null, null);
INSERT INTO `setting` VALUES ('7', 'AWS', 'Ec2 Elastic IPs', null, null);
INSERT INTO `setting` VALUES ('8', 'AWS', 'EBS Volumes', null, null);
INSERT INTO `setting` VALUES ('9', 'AWS', 'EBS Snapshots', null, null);
INSERT INTO `setting` VALUES ('10', 'AWS', 'Load Balancing', null, null);
INSERT INTO `setting` VALUES ('11', 'AWS', 'RDS Security Groups', null, null);
INSERT INTO `setting` VALUES ('12', 'AWS', 'RDS Parameter Groups', null, null);
INSERT INTO `setting` VALUES ('13', 'AWS', 'RDS Snapshots', null, null);
INSERT INTO `setting` VALUES ('14', 'CLOUDSTACK', 'Server Service', null, null);
INSERT INTO `setting` VALUES ('15', 'CLOUDSTACK', 'IP Address Service', null, null);
INSERT INTO `setting` VALUES ('16', 'CLOUDSTACK', 'Volume Server', null, null);
INSERT INTO `setting` VALUES ('17', 'CLOUDSTACK', 'Snapshot Service', null, null);
INSERT INTO `setting` VALUES ('18', 'CLOUDSTACK', 'Template Service', null, null);
INSERT INTO `setting` VALUES ('19', 'zoneId', '4', null, null);
INSERT INTO `setting` VALUES ('20', 'GIT_SERVER', 'http://109.105.20.204:3000', null, null);
INSERT INTO `setting` VALUES ('21', 'DNS_API_ADDRESS', 'http://46.137.247.177/api/', '', '');
INSERT INTO `setting` VALUES ('22', 'DNS_ZONE_ID', '7', null, null);
INSERT INTO `setting` VALUES ('23', 'DNS_PUBLIC_DOMAIN_NAME_POSTFIX', '.cloudpiapp.org', null, null);
INSERT INTO `setting` VALUES ('24', 'DNS_SERVER_ADDRESS', '46.137.247.151', '', '');
INSERT INTO `setting` VALUES ('25', 'DNS_TARGET_NAME_POSTFIX', '.samsungcloud.net', '', '');
INSERT INTO `setting` VALUES ('26', 'SCALR_KEY_ID', '95294cfe4e7049fe', null, null);
INSERT INTO `setting` VALUES ('27', 'SCALR_KEY', 'LFMQRC1tdmkBwfaocLT55eiIfD3wFHGmG6ipZim17ufVGnm1DlJJz/ZHvsbG8OErYD8tYxT9NddLqJXIS8pDxkBIwWwrAwS5JnQq+Yh+6IQ2MzWT1J5ZNCFhesXXThFiuG5CR9QVaAAx2l/JeqBuH0N/aDE3JXBcQAOHTTO9oic=', null, null);
INSERT INTO `setting` VALUES ('28', 'SCALR_API_URL', 'http://scalr.cloudpi.org/api/api.php', null, null);
INSERT INTO `setting` VALUES ('29', 'DNS_TARGET_ZONE_ID', '1', null, null);
INSERT INTO `setting` VALUES ('30', 'PUBLIC_DNSZONE_ID', '17', null, null);
INSERT INTO `setting` VALUES ('31', 'PRIVATE_DNSZONE_ID', '19', null, null);
INSERT INTO `setting` VALUES ('32', 'PRIVATE_VIEW', 'Internal', null, null);
INSERT INTO `setting` VALUES ('33', 'dnsendpoint', 'http://46.51.240.6/api/records', null, null);
INSERT INTO `setting` VALUES ('34', 'view', 'USA', null, null);
INSERT INTO `setting` VALUES ('35', 'view', 'China', null, null);
INSERT INTO `setting` VALUES ('36', 'view', 'Korea', null, null);
INSERT INTO `setting` VALUES ('37', 'view', 'Singapore', null, null);
INSERT INTO `setting` VALUES ('38', 'view', 'Others', null, null);

-- ----------------------------
-- Table structure for `snapshot`
-- ----------------------------
DROP TABLE IF EXISTS `snapshot`;
CREATE TABLE `snapshot` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) DEFAULT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `volume_id` bigint(20) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `size` bigint(20) NOT NULL,
  `source_id` varchar(20) DEFAULT NULL,
  `implsnapshot_id` varchar(20) DEFAULT NULL,
  `hypervisor_type` varchar(20) DEFAULT NULL,
  `version` varchar(10) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_18` (`volume_id`),
  KEY `FK_Reference_19` (`server_id`),
  CONSTRAINT `FK_Reference_18` FOREIGN KEY (`volume_id`) REFERENCES `volume` (`id`),
  CONSTRAINT `FK_Reference_19` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of snapshot
-- ----------------------------
-- ----------------------------
-- Table structure for `snapshot_policy`
-- ----------------------------
DROP TABLE IF EXISTS `snapshot_policy`;
CREATE TABLE `snapshot_policy` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `schedule` varchar(100) DEFAULT NULL,
  `timezone` varchar(100) DEFAULT NULL,
  `intervalsecs` int(11) NOT NULL,
  `max_snaps` int(11) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of snapshot_policy
-- ----------------------------

-- ----------------------------
-- Table structure for `snapshot_schedule`
-- ----------------------------
DROP TABLE IF EXISTS `snapshot_schedule`;
CREATE TABLE `snapshot_schedule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `volume_id` bigint(20) DEFAULT NULL,
  `policy_id` bigint(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `snapshot_id` bigint(20) DEFAULT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `snapshotPolicy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_28` (`policy_id`),
  KEY `FK_Reference_29` (`volume_id`),
  KEY `FK_Reference_30` (`snapshot_id`),
  CONSTRAINT `FK_Reference_28` FOREIGN KEY (`policy_id`) REFERENCES `snapshot_policy` (`id`),
  CONSTRAINT `FK_Reference_29` FOREIGN KEY (`volume_id`) REFERENCES `volume` (`id`),
  CONSTRAINT `FK_Reference_30` FOREIGN KEY (`snapshot_id`) REFERENCES `snapshot` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of snapshot_schedule
-- ----------------------------

-- ----------------------------
-- Table structure for `ssh_keypair`
-- ----------------------------
DROP TABLE IF EXISTS `ssh_keypair`;
CREATE TABLE `ssh_keypair` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `domain_id` bigint(20) NOT NULL,
  `name` varchar(256) NOT NULL,
  `fingerprint` varchar(256) DEFAULT NULL,
  `public_key` varchar(5120) DEFAULT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_36` (`created_by_id`),
  CONSTRAINT `FK_Reference_36` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of ssh_keypair
-- ----------------------------

-- ----------------------------
-- Table structure for `systemservice`
-- ----------------------------
DROP TABLE IF EXISTS `systemservice`;
CREATE TABLE `systemservice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `tier` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `version` varchar(255) DEFAULT NULL,
  `owned_by_account_id` bigint(20) DEFAULT NULL,
  `owned_by_domain_id` bigint(20) DEFAULT NULL,
  `owned_by_target_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8BFA51A698D5F8D0` (`owned_by_domain_id`),
  KEY `FK8BFA51A6E8736BC4` (`owned_by_account_id`),
  KEY `FK8BFA51A65BDDA9B0` (`owned_by_target_id`),
  CONSTRAINT `FK8BFA51A65BDDA9B0` FOREIGN KEY (`owned_by_target_id`) REFERENCES `target` (`id`),
  CONSTRAINT `FK8BFA51A698D5F8D0` FOREIGN KEY (`owned_by_domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK8BFA51A6E8736BC4` FOREIGN KEY (`owned_by_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of systemservice
-- ----------------------------

-- ----------------------------
-- Table structure for `tag`
-- ----------------------------
DROP TABLE IF EXISTS `tag`;
CREATE TABLE `tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `clsid` bigint(20) NOT NULL COMMENT 'class'' name plus ''_'' plus object''s id',
  `tag` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tag
-- ----------------------------

-- ----------------------------
-- Table structure for `target`
-- ----------------------------
DROP TABLE IF EXISTS `target`;
CREATE TABLE `target` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `impltarget_id` varchar(20) DEFAULT NULL,
  `target_url` varchar(512) DEFAULT NULL,
  `admin_id` varchar(100) DEFAULT NULL,
  `admin_password` varchar(100) DEFAULT NULL,
  `provider` varchar(200) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_id` bigint(20) NOT NULL,
  `removed_at` timestamp NULL DEFAULT NULL,
  `routeip` varchar(50) DEFAULT NULL,
  `zoneid` bigint(20) DEFAULT NULL,
  `recordid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of target
-- ----------------------------

-- ----------------------------
-- Table structure for `template`
-- ----------------------------
DROP TABLE IF EXISTS `template`;
CREATE TABLE `template` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `ispublic` bit(1) NOT NULL,
  `format` varchar(20) NOT NULL,
  `hypervisor_type` varchar(20) NOT NULL,
  `isbootable` bit(1) NOT NULL,
  `checksum` varchar(255) DEFAULT NULL,
  `impltemplate_id` varchar(20) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `bits` int(11) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_13` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_13` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=121 DEFAULT CHARSET=utf8 COMMENT='imgid here';

-- ----------------------------
-- Records of template
-- ----------------------------


-- ----------------------------
-- Table structure for `volume`
-- ----------------------------
DROP TABLE IF EXISTS `volume`;
CREATE TABLE `volume` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) DEFAULT NULL,
  `zone_id` bigint(20) DEFAULT NULL,
  `type` varchar(20) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `size` bigint(20) NOT NULL,
  `device` varchar(50) DEFAULT NULL,
  `implvolume_id` varchar(20) DEFAULT NULL,
  `state` varchar(10) NOT NULL,
  `server_id` bigint(20) DEFAULT NULL,
  `source_clsid` varchar(50) DEFAULT NULL,
  `attached_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `removed_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_Reference_17` (`server_id`),
  KEY `FK_Reference_51` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_17` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`),
  CONSTRAINT `FK_Reference_51` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=236 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of volume
-- ----------------------------

-- ----------------------------
-- Table structure for `zone`
-- ----------------------------
DROP TABLE IF EXISTS `zone`;
CREATE TABLE `zone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `implzone_id` varchar(20) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Index_1` (`name`),
  KEY `FK_Reference_39` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_39` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zone
-- ----------------------------
