# --- !Ups

insert into account(id,domain_id,username,password,is_supper,role_id,state,created_at,password_base64) values(1, 1, 'root', '341c3ac76bfb54cb02d6a689caba6641', 1, '1', 'Active', '2011-08-29 01:27:53', 'Y2xvdWRwaQ==');
