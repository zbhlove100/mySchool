# --- !Ups

insert into setting(name,`value`) values('pagesize','20');

insert into setting(name,`value`) values('AWS','Ec2 Instances');
insert into setting(name,`value`) values('AWS','Ec2 Images');
insert into setting(name,`value`) values('AWS','Ec2 Security Groups');
insert into setting(name,`value`) values('AWS','Ec2 SSH Keys');
insert into setting(name,`value`) values('AWS','Ec2 Licenses');
insert into setting(name,`value`) values('AWS','Ec2 Elastic IPs');
insert into setting(name,`value`) values('AWS','EBS Volumes');
insert into setting(name,`value`) values('AWS','EBS Snapshots');
insert into setting(name,`value`) values('AWS','Load Balancing');
insert into setting(name,`value`) values('AWS','RDS Security Groups');
insert into setting(name,`value`) values('AWS','RDS Parameter Groups');
insert into setting(name,`value`) values('AWS','RDS Snapshots');
insert into setting(name,`value`) values ('CLOUDSTACK', 'Server Service');
insert into setting(name,`value`) values ('CLOUDSTACK', 'IP Address Service');
insert into setting(name,`value`) values ('CLOUDSTACK', 'Volume Server');
insert into setting(name,`value`) values ('CLOUDSTACK', 'Snapshot Service');
insert into setting(name,`value`) values ('CLOUDSTACK', 'Template Service');
insert into setting(name,`value`) values ('zoneId', '4');
insert into setting(name,`value`) values ('GIT_SERVER', 'http://109.105.20.204:3000');
insert into setting(name,`value`) values ('DNS_API_ADDRESS', 'http://109.105.4.13/api/');
insert into setting(name,`value`) values ('DNS_ZONE_ID', '7');
insert into setting(name,`value`) values ('DNS_PUBLIC_DOMAIN_NAME_POSTFIX', '.cloudpiapp.org');
insert into setting(name,`value`) values ('DNS_SERVER_ADDRESS', '109.105.4.13');
insert into setting(name,`value`) values ('DNS_TARGET_NAME_POSTFIX', '.cloudpi.org');
insert into setting(name,`value`) values ('SCALR_KEY_ID', '95294cfe4e7049fe');
insert into setting(name,`value`) values ('SCALR_KEY', 'LFMQRC1tdmkBwfaocLT55eiIfD3wFHGmG6ipZim17ufVGnm1DlJJz/ZHvsbG8OErYD8tYxT9NddLqJXIS8pDxkBIwWwrAwS5JnQq+Yh+6IQ2MzWT1J5ZNCFhesXXThFiuG5CR9QVaAAx2l/JeqBuH0N/aDE3JXBcQAOHTTO9oic=');
insert into setting(name,`value`) values ('SCALR_API_URL', 'http://scalr.cloudpi.org/api/api.php');
insert into setting(name,`value`) values ('DNS_TARGET_ZONE_ID', '1');
