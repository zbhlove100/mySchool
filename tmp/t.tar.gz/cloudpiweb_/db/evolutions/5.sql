# --- !Ups

alter table server add column metric_id varchar(20) NULL;
alter table dnsrecord add column created_at timestamp  NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
alter table dnsrecord add column removed_at timestamp NULL;