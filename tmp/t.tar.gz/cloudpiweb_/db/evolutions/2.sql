# --- !Ups

insert into role(name) value('root');
insert into role(name) value('domainadmin');
insert into role(name) value('user');

insert into domain(id, name,state,created_at) values(1, 'ROOT','Active', '2011-08-29 01:27:53');

