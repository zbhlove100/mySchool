# --- !Ups

insert into dnszone(id,`name`,domain_id,state,created_by_id) values(2,'aws',1,'Active',1);
insert into dnszone(id,`name`,domain_id,state,created_by_id) values(3,'cloudstack',1,'Active',1);
insert into dnszone(id,`name`,domain_id,state,created_by_id) values(4,'rackspace',1,'Active',1);
insert into dnszone(id,`name`,domain_id,state,created_by_id) values(5,'openstack',1,'Active',1);

insert into setting(name,`value`) values ('PUBLIC_DNSZONE_ID', '21');
insert into setting(name,`value`) values ('PRIVATE_DNSZONE_ID', '22');
insert into setting(name,`value`) values ('PRIVATE_VIEW', 'Internal');
insert into setting(name,`value`) values ('dnsendpoint','http://46.137.247.177/api');