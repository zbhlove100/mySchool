/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2011-10-10 17:35:59                          */
/*==============================================================*/

# --- !Ups

/*==============================================================*/
/* Table: account                                               */
/*==============================================================*/
create table account
(
   id                   bigint not null auto_increment,
   domain_id            bigint not null,
   username             varchar(100) not null,
   password             varchar(100) not null comment 'type(sha,md5):hashvalue',
   email                varchar(100),
   api_key              varchar(255),
   secret_key           varchar(255),
   timezone             varchar(30),
   is_supper            bit not null,
   role_id              bigint not null,
   state                varchar(10) not null,
   created_by_id        bigint,
   created_at           timestamp not null,
   removed_at           timestamp null comment 'if not null, the record will be hidden for any user except root',
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique index Index_1 on account
(
   username
);

/*==============================================================*/
/* Table: alert                                                 */
/*==============================================================*/
create table alert
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint not null,
   category             varchar(20) not null,
   subject              varchar(500) not null,
   description          text,
   state                varchar(20) not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: cloudprovider                                         */
/*==============================================================*/
create table cloudprovider
(
   id                   bigint not null auto_increment,
   ispublic             bit not null,
   type                 varchar(50) not null,
   name                 varchar(200) not null,
   location             varchar(200),
   provider             varchar(200),
   state                varchar(10) not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on cloudprovider
(
   type
);

/*==============================================================*/
/* Table: cloudprovider_detail                                  */
/*==============================================================*/
create table cloudprovider_detail
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint not null,
   account_id           bigint comment 'if account is just for user, should query details by account_id',
   implaccount_id       varchar(20),
   impluser_id          varchar(20),
   name                 varchar(100) not null,
   value                text,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: container                                             */
/*==============================================================*/
create table container
(
   id                   bigint not null,
   name                 varchar(100) not null,
   put_timestamp        timestamp,
   object_count         bigint,
   bytes_used           bigint,
   state                varchar(10) not null,
   created_by_id        bigint,
   created_at           timestamp not null,
   removed_at           timestamp null comment 'if not null, the record will be hidden for any user except root',
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique index Index_1 on container
(
   name
);

/*==============================================================*/
/* Table: dnszone                                               */
/*==============================================================*/
create table dnszone
(
   id                   bigint not null auto_increment,
   domain_id            bigint not null,
   name                 varchar(200) not null,
   description          varchar(500),
   state                varchar(10) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on dnszone
(
   name
);

/*==============================================================*/
/* Table: dnszone_record                                        */
/*==============================================================*/
create table dnszone_record
(
   id                   bigint not null auto_increment,
   dnszone_id           bigint not null,
   ip_address_id        bigint,
   type                 varchar(10) not null,
   ttl                  int,
   priority             smallint,
   name                 varchar(100) not null,
   value                varchar(100) not null,
   view                 varchar(100) not null,      
   state                varchar(10) not null,
   created_by_id        bigint,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on dnszone_record
(
   dnszone_id
);

/*==============================================================*/
/* Table: domain                                                */
/*==============================================================*/
create table domain
(
   id                   bigint not null auto_increment,
   name                 varchar(200) not null,
   state                varchar(10) not null,
   created_by_id        bigint,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on domain
(
   name
);

/*==============================================================*/
/* Table: domain_cloudprovider                                  */
/*==============================================================*/
create table domain_cloudprovider
(
   id                   bigint not null auto_increment,
   domain_id            bigint,
   cloudprovider_id     bigint not null,
   impldomain_id        varchar(20),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on domain_cloudprovider
(
   cloudprovider_id,
   domain_id
);

/*==============================================================*/
/* Table: domain_target                                         */
/*==============================================================*/
create table domain_target
(
   domains_id           bigint not null,
   targets_id           bigint not null
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on domain_target
(
   domains_id,
   targets_id
);

/*==============================================================*/
/* Table: event                                                 */
/*==============================================================*/
create table event
(
   id                   bigint not null auto_increment,
   type                 varchar(100) not null,
   description          text,
   level                varchar(10) not null,
   trace_url            varchar(512),
   rawdata              text,
   state                varchar(100) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: firewall_rule                                         */
/*==============================================================*/
create table firewall_rule
(
   id                   bigint not null,
   server_id            bigint,
   ip_address_id        bigint not null,
   purpose              varchar(32),
   protocol             varchar(16) not null,
   start_port           int,
   end_port             int,
   source_cidr          varchar(1000) comment 'split with ,',
   implfirewallrule_id  varchar(20),
   created_by_id        bigint not null,
   created_at           timestamp not null,
   state                varchar(20) not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: hq_agent                                              */
/*==============================================================*/
create table hq_agent
(
   id                   bigint not null auto_increment,
   serviceprovider_id   bigint not null,
   server_id            bigint not null,
   type                 varchar(10) not null,
   agent_ip             varchar(15),
   implagent_id         varchar(20),
   state                varchar(10) not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: hq_alert                                              */
/*==============================================================*/
create table hq_alert
(
   id                   bigint not null auto_increment,
   agent_id             bigint not null,
   resource_id          bigint,
   reason               varchar(500) not null,
   detail               varchar(100),
   implalert_id         varchar(20),
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: hq_resource                                           */
/*==============================================================*/
create table hq_resource
(
   id                   bigint not null auto_increment,
   agent_id             bigint not null,
   type                 varchar(10) not null,
   name                 varchar(100),
   implresource_id      varchar(20),
   state                varchar(10) not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: ip_address                                            */
/*==============================================================*/
create table ip_address
(
   id                   bigint not null,
   cloudprovider_id     bigint,
   zone_id              bigint not null,
   domain_id            bigint not null,
   network_id           bigint,
   account_id           bigint,
   server_id            bigint,
   public_ip_address    varchar(20) not null,
   source_nat           int not null,
   allocated            timestamp,
   mac_address          varchar(50),
   one_to_one_nat       int,
   state                varchar(10) not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on ip_address
(
   public_ip_address
);

/*==============================================================*/
/* Table: network                                               */
/*==============================================================*/
create table network
(
   id                   bigint not null auto_increment,
   domain_id            bigint not null,
   name                 varchar(200) not null,
   description          varchar(500),
   traffic_type         varchar(20),
   boadcast_domain_type varchar(50),
   gateway              varchar(16) not null,
   cidr                 varchar(18) not null,
   mode                 varchar(10),
   dns1                 varchar(500),
   dns2                 varchar(500),
   network_domain       varchar(100),
   isdefault            bit not null,
   implnetwork_id       varchar(20),
   state                varchar(10) not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on network
(
   name
);

/*==============================================================*/
/* Table: object                                                */
/*==============================================================*/
create table object
(
   id                   bigint not null,
   container_id         bigint,
   name                 varchar(100) not null,
   size                 bigint,
   coutent_type         varchar(20),
   etag                 varchar(50),
   state                varchar(10) not null,
   created_by_id        bigint,
   created_at           timestamp not null,
   removed_at           timestamp null comment 'if not null, the record will be hidden for any user except root',
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique index Index_1 on object
(
   name
);

/*==============================================================*/
/* Table: product                                               */
/*==============================================================*/
create table product
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint not null,
   name                 varchar(50) not null,
   implproduct_id       varchar(100),
   bits                 int,
   state                varchar(10) not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: product_property                                      */
/*==============================================================*/
create table product_property
(
   id                   bigint not null auto_increment,
   product_id           bigint not null,
   name                 varchar(100) not null,
   value                varchar(500),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

alter table product_property comment 'cpu, speed, ramsize, limit_cpu_use
t1.micro
also';

/*==============================================================*/
/* Table: quota                                                 */
/*==============================================================*/
create table quota
(
   id                   bigint not null auto_increment,
   domain_id            bigint not null,
   cloudprovider_id     bigint not null,
   instance_limit       int not null default -1,
   ip_limit             int not null default -1,
   template_limit       int not null default -1,
   volume_limit         int not null default -1,
   snapshot_limit       int not null default -1,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

alter table quota comment 'limit = -1 is no limit';

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on quota
(
   domain_id
);

/*==============================================================*/
/* Index: Index_2                                               */
/*==============================================================*/
create index Index_2 on quota
(
   ip_limit
);

/*==============================================================*/
/* Table: resource                                              */
/*==============================================================*/
create table resource
(
   id                   bigint not null auto_increment,
   type                 varchar(20) not null,
   name                 varchar(200) not null comment 'three roles: root,domainadmin,user',
   resource             varchar(500) not null comment 'menu,url,data,vo...',
   action               varchar(100) not null comment 'support wildchar?',
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on resource
(
   type,
   name
);

/*==============================================================*/
/* Table: role                                                  */
/*==============================================================*/
create table role
(
   id                   bigint not null auto_increment,
   name                 varchar(200) not null comment 'three roles: domainadmin,user',
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on role
(
   name
);

/*==============================================================*/
/* Table: role_resource                                         */
/*==============================================================*/
create table role_resource
(
   roles_id             bigint not null comment 'three roles: root,domainadmin,user',
   resources_id         bigint not null
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on role_resource
(
   roles_id
);

/*==============================================================*/
/* Table: security                                              */
/*==============================================================*/
create table security
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint,
   domain_id            bigint not null,
   account_id           bigint not null,
   name                 varchar(50) not null,
   ispublic             bit not null comment 'all created by user is only for private',
   implsecurity_id      varchar(20),
   state                varchar(10) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: security_rule                                         */
/*==============================================================*/
create table security_rule
(
   id                   bigint not null auto_increment,
   security_id          bigint not null,
   protocol             varchar(16) not null,
   start_port           int,
   end_port             int,
   allowed_ip_cidrs     varchar(44) not null comment 'split with ,',
   implsecurityrule_id  varchar(20),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: server                                                */
/*==============================================================*/
create table server
(
   id                   bigint not null auto_increment,
   zone_id              bigint not null,
   domain_id            bigint not null,
   cloudprovider_id     bigint not null,
   product_id           bigint not null,
   name                 varchar(200) not null,
   template_id          bigint not null,
   ssh_keypairs_id      bigint,
   private_ip           varchar(32),
   hypervisor_type      varchar(20),
   implinstance_id      varchar(20),
   ismonitor            bit,
   state                varchar(10) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   updated_at           timestamp,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on server
(
   template_id
);

/*==============================================================*/
/* Table: server_property                                       */
/*==============================================================*/
create table server_property
(
   id                   bigint not null auto_increment,
   server_id            bigint not null,
   name                 varchar(200),
   value                varchar(500),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on server_property
(
   server_id,
   name
);

/*==============================================================*/
/* Table: serviceprovider                                       */
/*==============================================================*/
create table serviceprovider
(
   id                   bigint not null auto_increment,
   type                 varchar(50) not null,
   name                 varchar(200) not null,
   cloudprovider_id     bigint,
   state                varchar(10) not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on serviceprovider
(
   type
);

/*==============================================================*/
/* Table: serviceprovider_property                              */
/*==============================================================*/
create table serviceprovider_property
(
   id                   bigint not null auto_increment,
   serviceprovider_id   bigint not null comment 'class'' name +"_"+ id',
   name                 varchar(500) not null,
   value                text,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

alter table serviceprovider_property comment 'for hp server: host user password
for scalr: scalr_key';

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on serviceprovider_property
(
   serviceprovider_id,
   name
);

/*==============================================================*/
/* Table: setting                                               */
/*==============================================================*/
create table setting
(
   id                   bigint not null auto_increment,
   name                 varchar(200) not null,
   value                varchar(500),
   extvalue             varchar(500),
   description          varchar(1000),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on setting
(
   name
);

/*==============================================================*/
/* Table: snapshot                                              */
/*==============================================================*/
create table snapshot
(
   id                   bigint not null auto_increment,
   server_id            bigint,
   volume_id            bigint,
   type                 varchar(10),
   name                 varchar(200),
   size                 bigint not null,
   source_id            varchar(20),
   implsnapshot_id      varchar(20),
   hypervisor_type      varchar(20) not null,
   version              varchar(10),
   state                varchar(10) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_2                                               */
/*==============================================================*/
create index Index_2 on snapshot
(
   created_by_id
);

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique index Index_1 on snapshot
(
   removed_at
);

/*==============================================================*/
/* Table: snapshot_policy                                       */
/*==============================================================*/
create table snapshot_policy
(
   id                   bigint not null auto_increment,
   schedule             varchar(100),
   timezone             varchar(100),
   intervalsecs         int not null,
   max_snaps            int,
   state                varchar(10) not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: snapshot_schedule                                     */
/*==============================================================*/
create table snapshot_schedule
(
   id                   bigint not null auto_increment,
   volume_id            bigint,
   policy_id            bigint,
   state                varchar(10) not null,
   snapshot_id          bigint,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: ssh_keypair                                           */
/*==============================================================*/
create table ssh_keypair
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint,
   domain_id            bigint,
   name                 varchar(256),
   fingerprint          varchar(128),
   public_key           varchar(5120),
   created_by_id        bigint not null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: tag                                                   */
/*==============================================================*/
create table tag
(
   id                   bigint not null auto_increment,
   clsid                bigint not null comment 'class'' name plus ''_'' plus object''s id',
   tag                  varchar(200),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on tag
(
   clsid
);


/*==============================================================*/
/* Table: target                                                */
/*==============================================================*/
create table target
(
   id                   bigint not null auto_increment,
   name                 varchar(200) not null,
   impltarget_id        varchar(20),
   target_url           varchar(512),
   admin_id             varchar(100),
   admin_password       varchar(100),
   provider             varchar(200),
   state                varchar(10) not null,
   created_at           timestamp not null,
   created_by_id        bigint not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Table: template                                              */
/*==============================================================*/
create table template
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint not null,
   name                 varchar(200) not null,
   platform             varchar(50),
   ispublic             bit not null,
   format               varchar(20) not null,
   hypervisor_type      varchar(20) not null,
   isbootable           bit not null,
   checksum             varchar(255),
   impltemplate_id      varchar(20),
   password             varchar(50),
   bits                 int,
   description          text,
   state                varchar(10) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

alter table template comment 'imgid here';

/*==============================================================*/
/* Index: Index_2                                               */
/*==============================================================*/
create index Index_2 on template
(
   created_by_id
);

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique index Index_1 on template
(
   removed_at
);

/*==============================================================*/
/* Table: volume                                                */
/*==============================================================*/
create table volume
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint,
   zone_id              bigint,
   type                 varchar(20),
   name                 varchar(200),
   size                 bigint not null,
   device               varchar(50),
   implvolume_id        varchar(20),
   server_id            bigint,
   source_clsid         varchar(50),
   attached_at          timestamp,
   description          text,
   state                varchar(10) not null,
   created_by_id        bigint not null,
   created_at           timestamp not null,
   removed_at           timestamp null,
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_2                                               */
/*==============================================================*/
create index Index_2 on volume
(
   created_by_id
);

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create unique index Index_1 on volume
(
   removed_at
);

/*==============================================================*/
/* Table: zone                                                  */
/*==============================================================*/
create table zone
(
   id                   bigint not null auto_increment,
   cloudprovider_id     bigint not null,
   name                 varchar(200) not null,
   implzone_id          varchar(20),
   description          varchar(500),
   primary key (id)
)
ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*==============================================================*/
/* Index: Index_1                                               */
/*==============================================================*/
create index Index_1 on zone
(
   name
);

alter table account add constraint FK_Reference_2 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table account add constraint FK_Reference_3 foreign key (role_id)
      references role (id) on delete restrict on update restrict;

alter table alert add constraint FK_Reference_11 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table cloudprovider_detail add constraint FK_Reference_41 foreign key (account_id)
      references account (id) on delete restrict on update restrict;

alter table cloudprovider_detail add constraint FK_Reference_42 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table container add constraint FK_Reference_56 foreign key (created_by_id)
      references account (id) on delete restrict on update restrict;

alter table dnszone add constraint FK_Reference_38 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table dnszone_record add constraint FK_Reference_35 foreign key (dnszone_id)
      references dnszone (id) on delete restrict on update restrict;

alter table domain_cloudprovider add constraint FK_Reference_6 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table domain_cloudprovider add constraint FK_Reference_7 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table domain_target add constraint FK_Reference_10 foreign key (domains_id)
      references domain (id) on delete restrict on update restrict;

alter table domain_target add constraint FK_Reference_9 foreign key (targets_id)
      references target (id) on delete restrict on update restrict;

alter table event add constraint FK_Reference_1 foreign key (created_by_id)
      references account (id) on delete restrict on update restrict;

alter table firewall_rule add constraint FK_Reference_48 foreign key (id)
      references server (id) on delete restrict on update restrict;

alter table firewall_rule add constraint FK_Reference_52 foreign key (ip_address_id)
      references ip_address (id) on delete restrict on update restrict;

alter table hq_agent add constraint FK_Reference_20 foreign key (serviceprovider_id)
      references serviceprovider (id) on delete restrict on update restrict;

alter table hq_agent add constraint FK_Reference_21 foreign key (server_id)
      references server (id) on delete restrict on update restrict;

alter table hq_alert add constraint FK_Reference_23 foreign key (agent_id)
      references hq_agent (id) on delete restrict on update restrict;

alter table hq_alert add constraint FK_Reference_24 foreign key (resource_id)
      references hq_resource (id) on delete restrict on update restrict;

alter table hq_resource add constraint FK_Reference_22 foreign key (agent_id)
      references hq_agent (id) on delete restrict on update restrict;

alter table ip_address add constraint FK_Reference_49 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table ip_address add constraint FK_Reference_53 foreign key (network_id)
      references network (id) on delete restrict on update restrict;

alter table network add constraint FK_Reference_45 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table object add constraint FK_Reference_54 foreign key (container_id)
      references container (id) on delete restrict on update restrict;

alter table product add constraint FK_Reference_40 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table product_property add constraint FK_Reference_31 foreign key (product_id)
      references product (id) on delete restrict on update restrict;

alter table quota add constraint FK_Reference_8 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table role_resource add constraint FK_Reference_4 foreign key (roles_id)
      references role (id) on delete restrict on update restrict;

alter table role_resource add constraint FK_Reference_5 foreign key (resources_id)
      references resource (id) on delete restrict on update restrict;

alter table security add constraint FK_Reference_44 foreign key (created_by_id)
      references account (id) on delete restrict on update restrict;

alter table security add constraint FK_Reference_46 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table security_rule add constraint FK_Reference_43 foreign key (security_id)
      references security (id) on delete restrict on update restrict;

alter table server add constraint FK_Reference_14 foreign key (domain_id)
      references domain (id) on delete restrict on update restrict;

alter table server add constraint FK_Reference_15 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table server add constraint FK_Reference_25 foreign key (zone_id)
      references zone (id) on delete restrict on update restrict;

alter table server add constraint FK_Reference_32 foreign key (product_id)
      references product (id) on delete restrict on update restrict;

alter table server_property add constraint FK_Reference_12 foreign key (server_id)
      references server (id) on delete restrict on update restrict;

alter table serviceprovider add constraint FK_Reference_47 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table serviceprovider_property add constraint FK_Reference_50 foreign key (serviceprovider_id)
      references serviceprovider (id) on delete restrict on update restrict;

alter table snapshot add constraint FK_Reference_18 foreign key (volume_id)
      references volume (id) on delete restrict on update restrict;

alter table snapshot add constraint FK_Reference_19 foreign key (server_id)
      references server (id) on delete restrict on update restrict;

alter table snapshot_schedule add constraint FK_Reference_28 foreign key (policy_id)
      references snapshot_policy (id) on delete restrict on update restrict;

alter table snapshot_schedule add constraint FK_Reference_29 foreign key (volume_id)
      references volume (id) on delete restrict on update restrict;

alter table snapshot_schedule add constraint FK_Reference_30 foreign key (snapshot_id)
      references snapshot (id) on delete restrict on update restrict;

alter table ssh_keypair add constraint FK_Reference_36 foreign key (created_by_id)
      references account (id) on delete restrict on update restrict;

alter table template add constraint FK_Reference_13 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table volume add constraint FK_Reference_17 foreign key (server_id)
      references server (id) on delete restrict on update restrict;

alter table volume add constraint FK_Reference_51 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

alter table zone add constraint FK_Reference_39 foreign key (cloudprovider_id)
      references cloudprovider (id) on delete restrict on update restrict;

