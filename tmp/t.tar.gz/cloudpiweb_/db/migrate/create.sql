/*
SQLyog Enterprise - MySQL GUI v6.14
MySQL - 5.0.87-community-nt : Database - cloudpi-dev
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

create database if not exists `cloudpi-dev`;

USE `cloudpi-dev`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `account` */

DROP TABLE IF EXISTS `account`;

CREATE TABLE `account` (
  `id` bigint(20) NOT NULL auto_increment,
  `domain_id` bigint(20) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL COMMENT 'type(sha,md5):hashvalue',
  `email` varchar(100) default NULL,
  `api_key` varchar(255) default NULL,
  `secret_key` varchar(255) default NULL,
  `timezone` varchar(30) default NULL,
  `is_supper` bit(1) NOT NULL,
  `role_id` bigint(20) NOT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL COMMENT 'if not null, the record will be hidden for any user except root',
  `password_base64` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`username`),
  KEY `FK_Reference_2` (`domain_id`),
  KEY `FK_Reference_3` (`role_id`),
  KEY `FKB9D38A2D3B711875` (`created_by_id`),
  CONSTRAINT `FKB9D38A2D3B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_Reference_2` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_3` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

/*Data for the table `account` */

insert  into `account`(`id`,`domain_id`,`username`,`password`,`email`,`api_key`,`secret_key`,`timezone`,`is_supper`,`role_id`,`state`,`created_by_id`,`created_at`,`removed_at`,`password_base64`) values (1,1,'root','341c3ac76bfb54cb02d6a689caba6641',NULL,NULL,NULL,NULL,'',1,'Active',NULL,'2011-10-23 06:15:50',NULL,'Y2xvdWRwaQ==');

/*Table structure for table `alert` */

DROP TABLE IF EXISTS `alert`;

CREATE TABLE `alert` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `description` text,
  `state` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_11` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_11` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `alert` */

/*Table structure for table `application` */

DROP TABLE IF EXISTS `application`;

CREATE TABLE `application` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `project_id` bigint(20) NOT NULL,
  `target_id` bigint(20) NOT NULL,
  `url` varchar(512) default NULL,
  `branch` varchar(20) default NULL,
  `tag` varchar(20) default NULL,
  `instances` bigint(5) NOT NULL default '1',
  `account_id` bigint(20) NOT NULL,
  `memory` bigint(20) NOT NULL,
  `status` varchar(30) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `FK_APPLICATION_TARGET` (`target_id`),
  KEY `FK_APPLICATION_ACCOUNT` (`account_id`),
  KEY `FK_APPLICATION_PROJECT` (`project_id`),
  CONSTRAINT `FK_APPLICATION_PROJECT` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_APPLICATION_ACCOUNT` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_APPLICATION_TARGET` FOREIGN KEY (`target_id`) REFERENCES `target` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `application` */

/*Table structure for table `application_service` */

DROP TABLE IF EXISTS `application_service`;

CREATE TABLE `application_service` (
  `id` bigint(20) NOT NULL auto_increment,
  `application_id` bigint(20) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `FK_APPLICATION_SERVICE` (`application_id`),
  CONSTRAINT `FK_APPLICATION_SERVICE` FOREIGN KEY (`application_id`) REFERENCES `application` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `application_service` */

/*Table structure for table `cloudprovider` */

DROP TABLE IF EXISTS `cloudprovider`;

CREATE TABLE `cloudprovider` (
  `id` bigint(20) NOT NULL auto_increment,
  `ispublic` bit(1) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `location` varchar(200) default NULL,
  `provider` varchar(200) default NULL,
  `state` varchar(10) NOT NULL,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

/*Data for the table `cloudprovider` */

/*Table structure for table `cloudprovider_detail` */

DROP TABLE IF EXISTS `cloudprovider_detail`;

CREATE TABLE `cloudprovider_detail` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `account_id` bigint(20) default NULL COMMENT 'if account is just for user, should query details by account_id',
  `implaccount_id` varchar(20) default NULL,
  `impluser_id` varchar(20) default NULL,
  `name` varchar(100) NOT NULL,
  `value` text,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_41` (`account_id`),
  KEY `FK_Reference_42` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_41` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_Reference_42` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=449 DEFAULT CHARSET=utf8;

/*Data for the table `cloudprovider_detail` */

/*Table structure for table `container` */

DROP TABLE IF EXISTS `container`;

CREATE TABLE `container` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `put_timestamp` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `object_count` bigint(20) default NULL,
  `bytes_used` bigint(20) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) default NULL,
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `removed_at` timestamp NULL default NULL COMMENT 'if not null, the record will be hidden for any user except root',
  `zone_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `zone_id` (`zone_id`),
  CONSTRAINT `container_ibfk_1` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

/*Data for the table `container` */

/*Table structure for table `dns` */

DROP TABLE IF EXISTS `dns`;

CREATE TABLE `dns` (
  `id` bigint(20) NOT NULL auto_increment,
  `bak` varchar(255) default NULL,
  `created_on` datetime default NULL,
  `name` varchar(255) default NULL,
  `userid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

/*Data for the table `dns` */

/*Table structure for table `dns_dnstarget` */

DROP TABLE IF EXISTS `dns_dnstarget`;

CREATE TABLE `dns_dnstarget` (
  `dnses_id` bigint(20) NOT NULL,
  `dnsTargets_id` bigint(20) NOT NULL,
  KEY `FK1FE8946497576248` (`dnses_id`),
  KEY `FK1FE894649A13DCD7` (`dnsTargets_id`),
  CONSTRAINT `FK1FE8946497576248` FOREIGN KEY (`dnses_id`) REFERENCES `dns` (`id`),
  CONSTRAINT `FK1FE894649A13DCD7` FOREIGN KEY (`dnsTargets_id`) REFERENCES `dnstarget` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dns_dnstarget` */

/*Table structure for table `dnstarget` */

DROP TABLE IF EXISTS `dnstarget`;

CREATE TABLE `dnstarget` (
  `id` bigint(20) NOT NULL auto_increment,
  `bak` varchar(255) default NULL,
  `createdon` datetime default NULL,
  `name` varchar(255) default NULL,
  `routeip` varchar(255) default NULL,
  `url` varchar(255) default NULL,
  `zonerecordid` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8;

/*Data for the table `dnstarget` */

/*Table structure for table `dnszone` */

DROP TABLE IF EXISTS `dnszone`;

CREATE TABLE `dnszone` (
  `id` bigint(20) NOT NULL auto_increment,
  `domain_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`name`),
  KEY `FK_Reference_38` (`domain_id`),
  CONSTRAINT `FK_Reference_38` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dnszone` */

/*Table structure for table `dnszone_record` */

DROP TABLE IF EXISTS `dnszone_record`;

CREATE TABLE `dnszone_record` (
  `id` bigint(20) NOT NULL auto_increment,
  `dnszone_id` bigint(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `ttl` int(11) default NULL,
  `priority` smallint(6) default NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(100) NOT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`dnszone_id`),
  CONSTRAINT `FK_Reference_35` FOREIGN KEY (`dnszone_id`) REFERENCES `dnszone` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `dnszone_record` */

/*Table structure for table `domain` */

DROP TABLE IF EXISTS `domain`;

CREATE TABLE `domain` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`name`),
  KEY `FKB0F3D4C43B711875` (`created_by_id`),
  CONSTRAINT `FKB0F3D4C43B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

/*Data for the table `domain` */

insert  into `domain`(`id`,`name`,`state`,`created_by_id`,`created_at`,`removed_at`) values (1,'ROOT','Active',NULL,'2011-09-26 09:38:15',NULL);

/*Table structure for table `domain_cloudprovider` */

DROP TABLE IF EXISTS `domain_cloudprovider`;

CREATE TABLE `domain_cloudprovider` (
  `id` bigint(20) NOT NULL auto_increment,
  `domain_id` bigint(20) default NULL,
  `cloudprovider_id` bigint(20) NOT NULL,
  `impldomain_id` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`cloudprovider_id`,`domain_id`),
  KEY `FK_Reference_7` (`domain_id`),
  CONSTRAINT `FK_Reference_6` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK_Reference_7` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

/*Data for the table `domain_cloudprovider` */

/*Table structure for table `domain_target` */

DROP TABLE IF EXISTS `domain_target`;

CREATE TABLE `domain_target` (
  `domain_id` bigint(20) NOT NULL,
  `target_id` bigint(20) NOT NULL,
  `id` bigint(20) NOT NULL auto_increment,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`domain_id`,`target_id`),
  KEY `FK_Reference_9` (`target_id`),
  CONSTRAINT `FK_Reference_10` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_9` FOREIGN KEY (`target_id`) REFERENCES `target` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

/*Data for the table `domain_target` */

/*Table structure for table `event` */

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `id` bigint(20) NOT NULL auto_increment,
  `type` varchar(100) NOT NULL,
  `description` text,
  `level` varchar(10) NOT NULL,
  `trace_url` varchar(512) default NULL,
  `rawdata` text,
  `state` varchar(100) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_1` (`created_by_id`),
  CONSTRAINT `FK_Reference_1` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `event` */

/*Table structure for table `firewall_rule` */

DROP TABLE IF EXISTS `firewall_rule`;

CREATE TABLE `firewall_rule` (
  `id` bigint(20) NOT NULL auto_increment,
  `server_id` bigint(20) default NULL,
  `ip_address_id` bigint(20) NOT NULL,
  `purpose` varchar(32) default NULL,
  `protocol` varchar(16) NOT NULL,
  `start_port` int(11) default NULL,
  `end_port` int(11) default NULL,
  `source_cidr` varchar(1000) default NULL COMMENT 'split with ,',
  `implfirewallrule_id` varchar(20) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `state` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK35E0F2DBAE2702FE` (`server_id`),
  KEY `FK35E0F2DBF78DF987` (`ip_address_id`),
  CONSTRAINT `FK35E0F2DBAE2702FE` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`),
  CONSTRAINT `FK35E0F2DBF78DF987` FOREIGN KEY (`ip_address_id`) REFERENCES `ip_address` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

/*Data for the table `firewall_rule` */

/*Table structure for table `firewall_rule_cidr` */

DROP TABLE IF EXISTS `firewall_rule_cidr`;

CREATE TABLE `firewall_rule_cidr` (
  `id` bigint(20) NOT NULL auto_increment,
  `source_cidr` varchar(255) default NULL,
  `firewallRule_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FKE604EE5842F5657E` (`firewallRule_id`),
  CONSTRAINT `FKE604EE5842F5657E` FOREIGN KEY (`firewallRule_id`) REFERENCES `firewall_rule` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `firewall_rule_cidr` */

/*Table structure for table `hq_agent` */

DROP TABLE IF EXISTS `hq_agent`;

CREATE TABLE `hq_agent` (
  `id` bigint(20) NOT NULL auto_increment,
  `serviceprovider_id` bigint(20) NOT NULL,
  `server_id` bigint(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `agent_ip` varchar(15) default NULL,
  `implagent_id` varchar(20) default NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_20` (`serviceprovider_id`),
  KEY `FK_Reference_21` (`server_id`),
  CONSTRAINT `FK_Reference_20` FOREIGN KEY (`serviceprovider_id`) REFERENCES `serviceprovider` (`id`),
  CONSTRAINT `FK_Reference_21` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `hq_agent` */

/*Table structure for table `hq_alert` */

DROP TABLE IF EXISTS `hq_alert`;

CREATE TABLE `hq_alert` (
  `id` bigint(20) NOT NULL auto_increment,
  `agent_id` bigint(20) NOT NULL,
  `resource_id` bigint(20) default NULL,
  `reason` varchar(500) NOT NULL,
  `detail` varchar(100) default NULL,
  `implalert_id` varchar(20) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  `hqAgent_id` bigint(20) default NULL,
  `hqResource_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_23` (`agent_id`),
  KEY `FK_Reference_24` (`resource_id`),
  KEY `FK34C04EA6DC92149E` (`hqResource_id`),
  KEY `FK34C04EA657029476` (`hqAgent_id`),
  CONSTRAINT `FK34C04EA657029476` FOREIGN KEY (`hqAgent_id`) REFERENCES `hq_agent` (`id`),
  CONSTRAINT `FK34C04EA6DC92149E` FOREIGN KEY (`hqResource_id`) REFERENCES `hq_resource` (`id`),
  CONSTRAINT `FK_Reference_23` FOREIGN KEY (`agent_id`) REFERENCES `hq_agent` (`id`),
  CONSTRAINT `FK_Reference_24` FOREIGN KEY (`resource_id`) REFERENCES `hq_resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `hq_alert` */

/*Table structure for table `hq_resource` */

DROP TABLE IF EXISTS `hq_resource`;

CREATE TABLE `hq_resource` (
  `id` bigint(20) NOT NULL auto_increment,
  `agent_id` bigint(20) NOT NULL,
  `type` varchar(10) NOT NULL,
  `name` varchar(100) default NULL,
  `implresource_id` varchar(20) default NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  `hqAgent_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_22` (`agent_id`),
  KEY `FK4264828457029476` (`hqAgent_id`),
  CONSTRAINT `FK4264828457029476` FOREIGN KEY (`hqAgent_id`) REFERENCES `hq_agent` (`id`),
  CONSTRAINT `FK_Reference_22` FOREIGN KEY (`agent_id`) REFERENCES `hq_agent` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `hq_resource` */

/*Table structure for table `ip_address` */

DROP TABLE IF EXISTS `ip_address`;

CREATE TABLE `ip_address` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) default NULL,
  `zone_id` bigint(20) default NULL,
  `domain_id` bigint(20) default NULL,
  `network_id` bigint(20) default NULL,
  `account_id` bigint(20) default NULL,
  `server_id` bigint(20) default NULL,
  `public_ip_address` varchar(20) NOT NULL,
  `source_nat` int(11) NOT NULL,
  `allocated` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `mac_address` varchar(50) default NULL,
  `one_to_one_nat` int(11) default NULL,
  `state` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`public_ip_address`),
  KEY `FK_Reference_48` (`network_id`),
  KEY `FK_Reference_49` (`domain_id`),
  KEY `FK583738DCAE2702FE` (`server_id`),
  KEY `FK583738DC493AF75E` (`zone_id`),
  KEY `FK583738DC9737AEF6` (`account_id`),
  KEY `FK583738DCA70FAB56` (`cloudprovider_id`),
  CONSTRAINT `FK583738DC493AF75E` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`),
  CONSTRAINT `FK583738DC9737AEF6` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK583738DCA70FAB56` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK583738DCAE2702FE` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`),
  CONSTRAINT `FK_Reference_48` FOREIGN KEY (`network_id`) REFERENCES `network` (`id`),
  CONSTRAINT `FK_Reference_49` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8;

/*Data for the table `ip_address` */

/*Table structure for table `network` */

DROP TABLE IF EXISTS `network`;

CREATE TABLE `network` (
  `id` bigint(20) NOT NULL auto_increment,
  `domain_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) default NULL,
  `traffic_type` varchar(20) default NULL,
  `boadcast_domain_type` varchar(50) default NULL,
  `gateway` varchar(16) NOT NULL,
  `cidr` varchar(18) NOT NULL,
  `mode` varchar(10) default NULL,
  `dns1` varchar(500) default NULL,
  `dns2` varchar(500) default NULL,
  `network_domain` varchar(100) default NULL,
  `isdefault` bit(1) NOT NULL,
  `implnetwork_id` varchar(20) default NULL,
  `state` varchar(10) NOT NULL,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`name`),
  KEY `FK_Reference_45` (`domain_id`),
  CONSTRAINT `FK_Reference_45` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `network` */

/*Table structure for table `object` */

DROP TABLE IF EXISTS `object`;

CREATE TABLE `object` (
  `id` bigint(20) NOT NULL auto_increment,
  `container_id` bigint(20) default NULL,
  `name` varchar(100) NOT NULL,
  `size` bigint(20) default NULL,
  `coutent_type` varchar(20) default NULL,
  `etag` varchar(50) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL COMMENT 'if not null, the record will be hidden for any user except root',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=183 DEFAULT CHARSET=utf8;

/*Data for the table `object` */

/*Table structure for table `product` */

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(100) default NULL,
  `implproduct_id` varchar(100) default NULL,
  `bits` int(11) default NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_40` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_40` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

/*Data for the table `product` */

/*Table structure for table `product_property` */

DROP TABLE IF EXISTS `product_property`;

CREATE TABLE `product_property` (
  `id` bigint(20) NOT NULL auto_increment,
  `product_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `value` varchar(500) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_31` (`product_id`),
  CONSTRAINT `FK_Reference_31` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='cpu, speed, ramsize, limit_cpu_use\r\nt1.micro\r\nalso';

/*Data for the table `product_property` */

/*Table structure for table `project` */

DROP TABLE IF EXISTS `project`;

CREATE TABLE `project` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  `runtime` varchar(50) default NULL,
  `framework` varchar(50) default NULL,
  `account_id` bigint(20) NOT NULL,
  `description` varchar(512) default NULL,
  `git_url` varchar(512) default NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `domain_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_PROJECT_DOMAIN` (`domain_id`),
  KEY `FK_PROJECT_ACCOUNT` (`account_id`),
  CONSTRAINT `FK_PROJECT_ACCOUNT` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FK_PROJECT_DOMAIN` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

/*Data for the table `project` */

/*Table structure for table `project_event` */

DROP TABLE IF EXISTS `project_event`;

CREATE TABLE `project_event` (
  `id` bigint(20) NOT NULL auto_increment,
  `target_name` varchar(100) NOT NULL,
  `application_name` varchar(100) NOT NULL,
  `project_id` bigint(20) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `event_detail` varchar(1000) default NULL,
  `event_type` varchar(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `FK_EVENT_ACCOUNT` (`account_id`),
  KEY `FK_PROJECT_EVENT` (`project_id`),
  CONSTRAINT `FK_PROJECT_EVENT` FOREIGN KEY (`project_id`) REFERENCES `project` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

/*Data for the table `project_event` */

/*Table structure for table `property` */

DROP TABLE IF EXISTS `property`;

CREATE TABLE `property` (
  `id` bigint(20) NOT NULL auto_increment,
  `clsid` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `value` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `property` */

/*Table structure for table `quota` */

DROP TABLE IF EXISTS `quota`;

CREATE TABLE `quota` (
  `id` bigint(20) NOT NULL auto_increment,
  `domain_id` bigint(20) NOT NULL,
  `cloudprovider_id` bigint(20) NOT NULL,
  `instance_limit` int(11) NOT NULL default '-1',
  `ip_limit` int(11) NOT NULL default '-1',
  `template_limit` int(11) NOT NULL default '-1',
  `volume_limit` int(11) NOT NULL default '-1',
  `snapshot_limit` int(11) NOT NULL default '-1',
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`domain_id`),
  KEY `Index_2` (`ip_limit`),
  KEY `FK66F3E78A70FAB56` (`cloudprovider_id`),
  CONSTRAINT `FK66F3E78A70FAB56` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK_Reference_8` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='limit = -1 is no limit';

/*Data for the table `quota` */

/*Table structure for table `resource` */

DROP TABLE IF EXISTS `resource`;

CREATE TABLE `resource` (
  `id` bigint(20) NOT NULL auto_increment,
  `type` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL COMMENT 'three roles: root,domainadmin,user',
  `resource` varchar(500) NOT NULL COMMENT 'menu,url,data,vo...',
  `action` varchar(100) NOT NULL COMMENT 'support wildchar?',
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`type`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `resource` */

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL COMMENT 'three roles: domainadmin,user',
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

/*Data for the table `role` */

/*Table structure for table `role_resource` */

DROP TABLE IF EXISTS `role_resource`;

CREATE TABLE `role_resource` (
  `role_id` bigint(20) NOT NULL COMMENT 'three roles: root,domainadmin,user',
  `resource_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  `resources_id` bigint(20) NOT NULL,
  KEY `Index_1` (`role_id`),
  KEY `FK_Reference_5` (`resource_id`),
  KEY `FKAEE599B74001C377` (`roles_id`),
  KEY `FKAEE599B7704B8CA7` (`resources_id`),
  CONSTRAINT `FKAEE599B74001C377` FOREIGN KEY (`roles_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FKAEE599B7704B8CA7` FOREIGN KEY (`resources_id`) REFERENCES `resource` (`id`),
  CONSTRAINT `FK_Reference_4` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  CONSTRAINT `FK_Reference_5` FOREIGN KEY (`resource_id`) REFERENCES `resource` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `role_resource` */

/*Table structure for table `scalr_setting` */

DROP TABLE IF EXISTS `scalr_setting`;

CREATE TABLE `scalr_setting` (
  `id` bigint(20) NOT NULL auto_increment,
  `access_url` varchar(512) NOT NULL,
  `admin_api_key` varchar(100) NOT NULL,
  `admin_api_key_secret` varchar(100) NOT NULL,
  `created_by` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `scalr_setting` */

/*Table structure for table `security` */

DROP TABLE IF EXISTS `security`;

CREATE TABLE `security` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) default NULL,
  `domain_id` bigint(20) NOT NULL,
  `account_id` bigint(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ispublic` bit(1) NOT NULL COMMENT 'all created by user is only for private',
  `implsecurity_id` varchar(20) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `description` varchar(50) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_44` (`created_by_id`),
  KEY `FK_Reference_46` (`domain_id`),
  CONSTRAINT `FK_Reference_44` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_Reference_46` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

/*Data for the table `security` */

/*Table structure for table `security_rule` */

DROP TABLE IF EXISTS `security_rule`;

CREATE TABLE `security_rule` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) default NULL,
  `security_id` bigint(20) NOT NULL,
  `protocol` varchar(16) NOT NULL,
  `start_port` int(11) default NULL,
  `end_port` int(11) default NULL,
  `allowed_ip_cidrs` varchar(44) NOT NULL COMMENT 'split with ,',
  `implsecurityrule_id` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `security_rule` */

/*Table structure for table `server` */

DROP TABLE IF EXISTS `server`;

CREATE TABLE `server` (
  `id` bigint(20) NOT NULL auto_increment,
  `zone_id` bigint(20) NOT NULL,
  `domain_id` bigint(20) NOT NULL,
  `cloudprovider_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `template_id` bigint(20) NOT NULL,
  `ssh_keypair_id` bigint(20) default NULL,
  `private_ip` varchar(32) default NULL,
  `hypervisor_type` varchar(20) default NULL,
  `implinstance_id` varchar(20) default NULL,
  `ismonitor` bit(1) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`template_id`),
  KEY `FK_Reference_14` (`domain_id`),
  KEY `FK_Reference_15` (`cloudprovider_id`),
  KEY `FK_Reference_25` (`zone_id`),
  KEY `FK_Reference_32` (`product_id`),
  KEY `FKCA022F4361D7BCAD` (`ssh_keypair_id`),
  KEY `FKCA022F433B711875` (`created_by_id`),
  CONSTRAINT `FKCA022F433B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKCA022F4361D7BCAD` FOREIGN KEY (`ssh_keypair_id`) REFERENCES `ssh_keypair` (`id`),
  CONSTRAINT `FK_Reference_14` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_15` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK_Reference_25` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`),
  CONSTRAINT `FK_Reference_32` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8;

/*Data for the table `server` */

/*Table structure for table `server_property` */

DROP TABLE IF EXISTS `server_property`;

CREATE TABLE `server_property` (
  `id` bigint(20) NOT NULL auto_increment,
  `server_id` bigint(20) default NULL,
  `name` varchar(200) default NULL,
  `value` varchar(500) default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`server_id`,`name`),
  CONSTRAINT `FK_Reference_12` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `server_property` */

/*Table structure for table `service` */

DROP TABLE IF EXISTS `service`;

CREATE TABLE `service` (
  `id` bigint(20) NOT NULL auto_increment,
  `bak` varchar(900) default NULL,
  `name` varchar(255) default NULL,
  `registered` int(11) NOT NULL,
  `registered_date` datetime default NULL,
  `type` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `owned_by_id` bigint(20) default NULL,
  `used_by_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK7643C6B554E7D18A` (`used_by_id`),
  KEY `FK7643C6B5E74E0A72` (`owned_by_id`),
  CONSTRAINT `FK7643C6B554E7D18A` FOREIGN KEY (`used_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK7643C6B5E74E0A72` FOREIGN KEY (`owned_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

/*Data for the table `service` */

/*Table structure for table `serviceprovider` */

DROP TABLE IF EXISTS `serviceprovider`;

CREATE TABLE `serviceprovider` (
  `id` bigint(20) NOT NULL auto_increment,
  `type` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `cloudprovider_id` bigint(20) default NULL,
  `state` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`type`),
  KEY `FK_Reference_47` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_47` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `serviceprovider` */

/*Table structure for table `serviceprovider_property` */

DROP TABLE IF EXISTS `serviceprovider_property`;

CREATE TABLE `serviceprovider_property` (
  `id` bigint(20) NOT NULL auto_increment,
  `serviceprovider_id` bigint(20) NOT NULL COMMENT 'class'' name +"_"+ id',
  `name` varchar(500) NOT NULL,
  `value` text,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`serviceprovider_id`,`name`(255)),
  CONSTRAINT `FK_Reference_50` FOREIGN KEY (`serviceprovider_id`) REFERENCES `serviceprovider` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='for hp server: host user password\r\nfor scalr: scalr_key';

/*Data for the table `serviceprovider_property` */

/*Table structure for table `setting` */

DROP TABLE IF EXISTS `setting`;

CREATE TABLE `setting` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `value` varchar(500) default NULL,
  `extvalue` varchar(500) default NULL,
  `description` varchar(1000) default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

/*Data for the table `setting` */

insert  into `setting`(`id`,`name`,`value`,`extvalue`,`description`) values (19,'AWS','Ec2 Instances',NULL,NULL),(20,'AWS','Ec2 Images',NULL,NULL),(21,'AWS','Ec2 Security Groups',NULL,NULL),(22,'AWS','Ec2 SSH Keys',NULL,NULL),(23,'AWS','Ec2 Licenses',NULL,NULL),(24,'AWS','Ec2 Elastic IPs',NULL,NULL),(25,'AWS','EBS Volumes',NULL,NULL),(26,'AWS','EBS Snapshots',NULL,NULL),(27,'AWS','Load Balancing',NULL,NULL),(28,'AWS','RDS Security Groups',NULL,NULL),(29,'AWS','RDS Parameter Groups',NULL,NULL),(30,'AWS','RDS Snapshots',NULL,NULL),(31,'CLOUDSTACK','Server Service','',''),(32,'CLOUDSTACK','IP Address Service','',''),(33,'CLOUDSTACK','Volume Server','',''),(34,'CLOUDSTACK','Snapshot Service','',''),(35,'CLOUDSTACK','Template Service','',''),(36,'zoneId','4','','');

/*Table structure for table `snapshot` */

DROP TABLE IF EXISTS `snapshot`;

CREATE TABLE `snapshot` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) default NULL,
  `server_id` bigint(20) default NULL,
  `volume_id` bigint(20) default NULL,
  `type` varchar(10) default NULL,
  `name` varchar(200) default NULL,
  `size` bigint(20) NOT NULL,
  `source_id` varchar(20) default NULL,
  `implsnapshot_id` varchar(20) default NULL,
  `hypervisor_type` varchar(20) default NULL,
  `version` varchar(10) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_2` (`created_by_id`),
  KEY `FK_Reference_18` (`volume_id`),
  KEY `FK_Reference_19` (`server_id`),
  KEY `FK10FAD5C43B711875` (`created_by_id`),
  KEY `FK10FAD5C4A70FAB56` (`cloudprovider_id`),
  CONSTRAINT `FK10FAD5C43B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK10FAD5C4A70FAB56` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK_Reference_18` FOREIGN KEY (`volume_id`) REFERENCES `volume` (`id`),
  CONSTRAINT `FK_Reference_19` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `snapshot` */

/*Table structure for table `snapshot_policy` */

DROP TABLE IF EXISTS `snapshot_policy`;

CREATE TABLE `snapshot_policy` (
  `id` bigint(20) NOT NULL auto_increment,
  `schedule` varchar(100) default NULL,
  `timezone` varchar(100) default NULL,
  `intervalsecs` int(11) NOT NULL,
  `max_snaps` int(11) default NULL,
  `state` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `snapshot_policy` */

/*Table structure for table `snapshot_schedule` */

DROP TABLE IF EXISTS `snapshot_schedule`;

CREATE TABLE `snapshot_schedule` (
  `id` bigint(20) NOT NULL auto_increment,
  `volume_id` bigint(20) default NULL,
  `policy_id` bigint(20) default NULL,
  `state` varchar(10) NOT NULL,
  `snapshot_id` bigint(20) default NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `snapshotPolicy_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_28` (`policy_id`),
  KEY `FK_Reference_29` (`volume_id`),
  KEY `FK_Reference_30` (`snapshot_id`),
  KEY `FK676B2AB257EA3E` (`snapshotPolicy_id`),
  CONSTRAINT `FK676B2AB257EA3E` FOREIGN KEY (`snapshotPolicy_id`) REFERENCES `snapshot_policy` (`id`),
  CONSTRAINT `FK_Reference_28` FOREIGN KEY (`policy_id`) REFERENCES `snapshot_policy` (`id`),
  CONSTRAINT `FK_Reference_29` FOREIGN KEY (`volume_id`) REFERENCES `volume` (`id`),
  CONSTRAINT `FK_Reference_30` FOREIGN KEY (`snapshot_id`) REFERENCES `snapshot` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `snapshot_schedule` */

/*Table structure for table `ssh_keypair` */

DROP TABLE IF EXISTS `ssh_keypair`;

CREATE TABLE `ssh_keypair` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `domain_id` bigint(20) NOT NULL,
  `name` varchar(256) NOT NULL,
  `fingerprint` varchar(256) default NULL,
  `public_key` varchar(5120) default NULL,
  `created_by_id` bigint(20) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_Reference_36` (`created_by_id`),
  KEY `FK37889682C7C3875E` (`domain_id`),
  KEY `FK37889682A70FAB56` (`cloudprovider_id`),
  CONSTRAINT `FK37889682A70FAB56` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`),
  CONSTRAINT `FK37889682C7C3875E` FOREIGN KEY (`domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK_Reference_36` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;

/*Data for the table `ssh_keypair` */

/*Table structure for table `systemservice` */

DROP TABLE IF EXISTS `systemservice`;

CREATE TABLE `systemservice` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `tier` varchar(255) default NULL,
  `type` varchar(255) default NULL,
  `version` varchar(255) default NULL,
  `owned_by_account_id` bigint(20) default NULL,
  `owned_by_domain_id` bigint(20) default NULL,
  `owned_by_target_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK8BFA51A698D5F8D0` (`owned_by_domain_id`),
  KEY `FK8BFA51A6E8736BC4` (`owned_by_account_id`),
  KEY `FK8BFA51A65BDDA9B0` (`owned_by_target_id`),
  CONSTRAINT `FK8BFA51A65BDDA9B0` FOREIGN KEY (`owned_by_target_id`) REFERENCES `target` (`id`),
  CONSTRAINT `FK8BFA51A698D5F8D0` FOREIGN KEY (`owned_by_domain_id`) REFERENCES `domain` (`id`),
  CONSTRAINT `FK8BFA51A6E8736BC4` FOREIGN KEY (`owned_by_account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

/*Data for the table `systemservice` */

/*Table structure for table `tag` */

DROP TABLE IF EXISTS `tag`;

CREATE TABLE `tag` (
  `id` bigint(20) NOT NULL auto_increment,
  `clsid` bigint(20) NOT NULL COMMENT 'class'' name plus ''_'' plus object''s id',
  `tag` varchar(200) default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`clsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `tag` */

/*Table structure for table `target` */

DROP TABLE IF EXISTS `target`;

CREATE TABLE `target` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(200) NOT NULL,
  `impltarget_id` varchar(20) default NULL,
  `target_url` varchar(512) default NULL,
  `admin_id` varchar(100) default NULL,
  `admin_password` varchar(100) default NULL,
  `provider` varchar(200) default NULL,
  `state` varchar(10) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `created_by_id` bigint(20) NOT NULL,
  `removed_at` timestamp NULL default NULL,
  `routeip` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

/*Data for the table `target` */

/*Table structure for table `template` */

DROP TABLE IF EXISTS `template`;

CREATE TABLE `template` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `platform` varchar(50) default NULL,
  `ispublic` bit(1) NOT NULL,
  `format` varchar(20) NOT NULL,
  `hypervisor_type` varchar(20) NOT NULL,
  `isbootable` bit(1) NOT NULL,
  `checksum` varchar(255) default NULL,
  `impltemplate_id` varchar(20) default NULL,
  `password` varchar(50) default NULL,
  `bits` int(11) default NULL,
  `state` varchar(10) NOT NULL,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_2` (`created_by_id`),
  KEY `FK_Reference_13` (`cloudprovider_id`),
  KEY `FKB13ACC7A3B711875` (`created_by_id`),
  CONSTRAINT `FKB13ACC7A3B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FK_Reference_13` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8 COMMENT='imgid here';

/*Data for the table `template` */

/*Table structure for table `volume` */

DROP TABLE IF EXISTS `volume`;

CREATE TABLE `volume` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) default NULL,
  `zone_id` bigint(20) default NULL,
  `type` varchar(20) default NULL,
  `name` varchar(200) default NULL,
  `size` bigint(20) NOT NULL,
  `device` varchar(50) default NULL,
  `implvolume_id` varchar(20) default NULL,
  `state` varchar(10) NOT NULL,
  `server_id` bigint(20) default NULL,
  `source_clsid` varchar(50) default NULL,
  `attached_at` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `created_by_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL default '0000-00-00 00:00:00',
  `removed_at` timestamp NULL default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_2` (`created_by_id`),
  KEY `FK_Reference_17` (`server_id`),
  KEY `FK_Reference_51` (`cloudprovider_id`),
  KEY `FKCFAAE71A493AF75E` (`zone_id`),
  KEY `FKCFAAE71A3B711875` (`created_by_id`),
  CONSTRAINT `FKCFAAE71A3B711875` FOREIGN KEY (`created_by_id`) REFERENCES `account` (`id`),
  CONSTRAINT `FKCFAAE71A493AF75E` FOREIGN KEY (`zone_id`) REFERENCES `zone` (`id`),
  CONSTRAINT `FK_Reference_17` FOREIGN KEY (`server_id`) REFERENCES `server` (`id`),
  CONSTRAINT `FK_Reference_51` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8;

/*Data for the table `volume` */

/*Table structure for table `zone` */

DROP TABLE IF EXISTS `zone`;

CREATE TABLE `zone` (
  `id` bigint(20) NOT NULL auto_increment,
  `cloudprovider_id` bigint(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `implzone_id` varchar(20) default NULL,
  `description` varchar(500) default NULL,
  PRIMARY KEY  (`id`),
  KEY `Index_1` (`name`),
  KEY `FK_Reference_39` (`cloudprovider_id`),
  CONSTRAINT `FK_Reference_39` FOREIGN KEY (`cloudprovider_id`) REFERENCES `cloudprovider` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

/*Data for the table `zone` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
