package units.others;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import models.Account;
import models.Domain;
import models.Event;
import models.IpAddress;
import models.Resource;
import models.Role;
import models.Setting;
import models.spec.BaseModel;
import models.spec.Where;

import org.junit.Test;

import play.libs.WS;
import play.test.UnitTest;
import service.admin.OpenstackCall;

public class ModelsTest extends UnitTest {
	
    //@Test
    public void checkInitailDataTest() {

		List<Role> roles = Role.all().fetch();		
		assertEquals(roles.size(), 3);
		Domain domain = Domain.findById(1l);
		assertEquals(domain.name, "ROOT");				
		Account acc = Account.findById(1l);
		assertEquals(acc.username, "root");
	
/*		
		JPAQuery jq = Account.find("byIdAndDomain_id",1l,domain.id);
		System.out.println("zzzzzzzzzzzz:"+jq.sq);	
		List<Account> rl = jq.fetch();
		System.out.println(rl.get(0).username);
*/		
/*		
		JPAQuery jq = Account.find("id=:id and domain_id=:did");
		//Query  q = jq.query;
		String sq = "from Role where id=:id";
		
		jq.bind("id", 1l);
		jq.bind("did", 1l);
		List<Account> rl = jq.fetch();
		for(Account r:rl){
			System.out.println(r.username);
		}
    	System.out.println("zzzzzzzzzzzz:"+jq.sq);		
*/		
/*		
		
		EntityManager em = acc.em();
		CriteriaBuilder cb = em.getCriteriaBuilder();
		
		CriteriaQuery<Account> cq = cb.createQuery(Account.class);
		
		Root<Account> accobj= cq.from(Account.class);
		//List<Restriction> wheres = new ArrayList<Restriction> ();
		//wheres.add(new Restriction("id",1l,"="));
		//jq.query.
		Predicate pkgLineQuery = cb.equal( accobj.get( "Id" ), 1l );
		Predicate wrapQuery = cb.equal( accobj.get( "domain" ), 1l);
		
		//Predicate dateQuery = cb.between( accobj.get( "timeStamp" ).as( Date.class ), startDate, endDate );

		cq.where( cb.and( pkgLineQuery, wrapQuery ) );
		
		//cq.orderBy( builder.desc( pkgLoad.get( "timeStamp" ) ) );

		System.out.println("zzzzzzzzzzzz:"+cq.toString());
//*/		

    }
    
    //@Test
    public void checkSettingsTest() {
    	String sv = Setting.value("pagesize");
    	assertEquals(sv, "20");
    }
    //@Test
    public void checkSaveEventTest() {
    	Account acc = Account.findById(1l);
		Event event = new Event();
		event.created_by = acc;
		event.createdAt = new Date(System.currentTimeMillis());
		event.level = "Warning";
		event.state = "Active";
		event.type = "Login";
		event.traceUrl = "http://localhost:9000/test";
		event = event.save();  
		Event check_event = Event.findById(event.id);
		assertEquals(check_event.id, check_event.id);
		assertEquals(check_event.created_by.username, acc.username);
    }
    
    //@Test
    public void testOne2ManyQuery(){
    	
		Account acc = new Account();
		acc.username = "root";
		 
		String sql = "FROM IpAddress s WHERE s.account.username=?1";
		    
		Query test = IpAddress.em().createQuery(sql);
		test.setParameter(1, "cc");
		List objs = test.getResultList();
		
		
		List<IpAddress> ips = IpAddress.find("account.username=? and account.state=?", "cc","Active").fetch();
		
		//System.out.println("============>"+IpAddress.find("account", acc).sq);
		
    }
    
    //@Test
    public void checkCloudProviderTest() {

//    	CloudstackJsonCall cscs = new CloudstackJsonCall("2");
//    	Map<String,String> params = new HashMap<String,String>();
//    	params.put("name", "testAPIcall2");
//    	Map result = cscs.call("createDomain", params);
    	
    }

    //@Test
    public void templateTest() {
    	
    	String searchFields="name,listdd";
    	String search = "dddd";
    	
    	StringBuffer allwhere = new StringBuffer();
    	
    	List<Object> allparams = new ArrayList();
    	
    	if(searchFields != null && search != null ){
    		
    		allwhere.append("(");
        	String [] sfs = searchFields.split(",");
        	for(String sf: sfs){
        		allwhere.append(String.format("%s like '?%%' or ",sf));
        		allparams.add(search);
        	}
        	allwhere.setLength(allwhere.length()-3);
        	allwhere.append(") ");
    	}
    	
    	System.out.println("====>"+allwhere.toString());
    	System.out.println(allparams.size());
    }

    //@Test
    public void listTest() {
    	  
    	String providerId = "1";
    	Where where = new Where(null);
    	where.block();		
    	where.or();
    	where.addValue("ispublic=", true);
    	List<Long> cpids = new ArrayList<Long>();
    	
    	//cpids.add(1l);
    	//cpids.add(2l);
    	//cpids.add(3l);
    	
    	where.in("cloudprovider_id",cpids);
    	where.endblock();
    	where.and();
    	where.addValue("state !=", BaseModel.DELETE);
    	if(providerId != null)
    		where.addValue("cloudprovider_id =", providerId);
    	System.out.println("======>"+where.where());
    	
    	
    	/*
    	List<Long> ids = new ArrayList<Long>();
    	
    	ids.add(1l);
    	ids.add(2l);
    	ids.add(3l);
    	
    	List<Object> objs = new ArrayList<Object>();
    	TTT t = new TTT();
    	t.setC1(100);
    	t.setC2(100);
    	objs.add(t);
 
    	t = new TTT();
    	t.setC1(101);
    	t.setC2(101);
    	objs.add(t);
    	
    	t = new TTT();
    	t.setC1(102);
    	t.setC2(102);
    	objs.add(t);   
    	
    	
    	Where w = new Where(null);
    	w.in("domainid", ids);
    	w.notin("id", ids);
    	w.block();
    	w.notin("ccid", ids);
    	w.or();
    	w.in("domainid", ids);
    	w.in("domainid", objs,"getC1");
    	w.endblock();
    	w.and();
    	
    	w.in("domainid", ids);
    	w.or();
    	w.block();
    	w.isnull("username");
    	w.notnull("username");
    	w.endblock();
    	
    	
    	System.out.println("======>"+w.where());
    	*/
    }
    
    //@Test
    public void m2mTest() {
    	
    	List<Long> ids = new ArrayList<Long>();
    	ids.add(new Long(1l));
    	Object[] params = new Object[1];
    	params[0]= (ids);
    	
    	//Resource.find("role in ?",params).fetch();
    	//List<Resource> ress = Resource.find("role.id in (1)").fetch();
    	//List<Resource> ress = Resource.find("role.id = 1").fetch();
    	//System.out.println("==========>"+ress.size());
    	
    	List<Role> roles = Role.find("from Role a join a.resources b where b.id in (1)").fetch();
    	System.out.println("==========>"+roles.size());
    	
    	Resource res = Resource.findById(1l);
    	System.out.println("==========>"+res.roles.size());
    	
    	Role role = Role.findById(1l);
    	System.out.println("==========>"+role.resources.size());
    	for(Resource eachres:role.resources){
    		System.out.println("==========>"+eachres.name);
    	}
    }
    
    //@Test
    public void netTest() {
    	try{
//	     	CloudstackJsonCall cscs = new CloudstackJsonCall("63");
//	     	Map<String,String> params = new HashMap<String,String>();
//	     	
//			params.put("id", "210");
//	//    	
//	    	Map result = cscs.call("listTemplatePermissions", params);
//	    	System.out.println(result);		
	    	
    		OpenstackCall osc =  new OpenstackCall("68");
    		osc.setService("Admin");
    		Map<String,String> params = new HashMap<String,String>();
    		
    		//Map result = osc.call("DescribeInstances", params);
    		//Map result = osc.call("DescribeKeyPairs", params);
    		//Map result = osc.call("DescribeProjects", params);
    		
    		params.put("name", "project-001");
    		//params.put("manager_user", "liaofan");
    		
    		//Map result = osc.call("RegisterProject", params);
    		//Map result = osc.call("DescribeProject", params);
    		Map result = osc.call("DeregisterProject", params);
    		
    		System.out.println(result);		
    		
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }    
    
    @Test
    public void wsTest() {
    	try{    
    		String response = WS.url("http://localhost:9000/@cas/serviceValidate?service=http://localhost:9000/authenticate&ticket=ST-9159c034-8a28-4121-bed7-f11235db6b6d").get().getString();
			System.out.println(response);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }

}
