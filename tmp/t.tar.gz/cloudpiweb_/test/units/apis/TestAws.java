package units.apis;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import org.dasein.cloud.CloudException;
import org.dasein.cloud.CloudProvider;
import org.dasein.cloud.InternalException;
import org.dasein.cloud.ProviderContext;
import org.dasein.cloud.aws.AWSCloud;
import org.dasein.cloud.compute.VirtualMachine;

public class TestAws {

	public static void main(String[] args) throws InternalException, CloudException {
		CloudProvider provider = new AWSCloud();
		//set providercontext parameters begin
		ProviderContext ctx =new ProviderContext();
				FileInputStream fis = null;
		try {
			Properties props = new Properties();
			String path = "D:/playframeworkworkspace/cloudpi/resourse";

			fis = new FileInputStream(path + "/cloud.properties");

			props.load(fis);
			
			String publicKey, privateKey;

			publicKey = props.getProperty("cloud.apiSharedKey");
			privateKey = props.getProperty("cloud.apiSecretKey");
			if (publicKey != null && privateKey != null) {
				ctx.setAccessKeys(publicKey.getBytes(), privateKey.getBytes());
			}

			ctx.setAccountNumber(props.getProperty("cloud.accountNumber"));
			ctx.setCloudName(props.getProperty("cloud.cloudName"));
			ctx.setEndpoint(props.getProperty("cloud.endpoint"));
			ctx.setProviderName(props.getProperty("cloud.providerName"));
			String regionId =  props.getProperty("cloud.regionId");
			ctx.setRegionId(regionId);

			publicKey = props.getProperty("cloud.x509Cert");
			privateKey = props.getProperty("cloud.x509Key");
			if (publicKey != null && privateKey != null) {
				ctx.setStorageKeys(publicKey.getBytes(), privateKey.getBytes());
			}

			Properties custom = new Properties();
			Enumeration<?> names = props.propertyNames();

			while (names.hasMoreElements()) {
				String name = (String) names.nextElement();

				if (name.startsWith("test.")) {
					custom.setProperty(name, props.getProperty(name));
				}
			}
			ctx.setCustomProperties(custom);
			provider.connect(ctx);//connect
			Iterable<VirtualMachine> result=provider.getComputeServices().getVirtualMachineSupport().listVirtualMachines();
			for(VirtualMachine vm:result){
				System.out.println("vmId:"+vm.getProviderVirtualMachineId());
				System.out.println("Server Name:"+vm.getName());
				System.out.println("ProviderName:"+provider.getProviderName());
				System.out.println("Zone:"+provider.getDataCenterServices().getRegion(regionId));
				System.out.println("State:"+vm.getCurrentState());
				System.out.println("Account:"+provider.getContext().getAccountNumber());
				System.out.println("avaliable: true ");
			}
		} catch (IOException e1) {
			e1.printStackTrace();
		} finally {
			if (fis != null)
				try {
					fis.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}

}
