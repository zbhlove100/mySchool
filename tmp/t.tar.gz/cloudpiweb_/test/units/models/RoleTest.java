package units.models;
import java.util.ArrayList;
import java.util.List;

import models.Role;

import org.junit.Test;

import play.test.UnitTest;

public class RoleTest extends UnitTest {
	
    @Test
    public void checkData() {

		List<Role> roles = Role.all().fetch();		
		assertEquals(roles.size(), 3);
		List<String> initdatas = new ArrayList<String>();
		initdatas.add("root");
		initdatas.add("domainadmin");
		initdatas.add("user");
		for(Role role: roles){
			assertTrue(initdatas.contains(role.name));
		}

    }
	
}
