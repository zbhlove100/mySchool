package units.models;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import models.Account;
import models.Domain;
import models.Event;
import models.IpAddress;
import models.Resource;
import models.Role;
import models.Setting;
import models.spec.BaseModel;
import models.spec.Where;

import org.junit.Test;

import play.test.UnitTest;
import service.admin.OpenstackCall;

public class DomainTest extends UnitTest {
	
    @Test
    public void checkData() {
		Domain domain = Domain.findById(1l);
		assertEquals(domain.name, "ROOT");				
    }
	
}
