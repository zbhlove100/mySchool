package units.models;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import models.Account;
import models.Domain;
import models.Event;
import models.IpAddress;
import models.Resource;
import models.Role;
import models.Setting;
import models.spec.BaseModel;
import models.spec.Where;

import org.junit.Test;

import play.test.UnitTest;
import service.admin.OpenstackCall;

public class AccountTest extends UnitTest {
	
    @Test
    public void checkData() {
		Account acc = Account.findById(1l);
		assertEquals(acc.username, "root");
		assertTrue(acc.checkPassword("cloudpi"));
    }

    @Test
    public void checkPassword() {
		Account acc = new Account();
		acc.setPassword("cloudpi");		
		assertTrue(acc.checkPassword("cloudpi"));
    }
    
}
