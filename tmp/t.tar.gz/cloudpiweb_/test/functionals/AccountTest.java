package functionals;
import models.Account;

import org.junit.Test;

import play.test.FunctionalTest;

public class AccountTest extends FunctionalTest {
	
    @Test
    public void checkData() {
		Account acc = Account.findById(1l);
		assertEquals(acc.username, "root");
		assertTrue(acc.checkPassword("cloudpi"));
    }

    @Test
    public void checkPassword() {
		Account acc = new Account();
		acc.setPassword("cloudpi");		
		assertTrue(acc.checkPassword("cloudpi"));
    }
    
}
