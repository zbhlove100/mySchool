package functionals;

import org.dasein.cloud.CloudException;
import org.junit.Test;

import play.mvc.Http.Response;
import play.test.FunctionalTest;

public class ApplicationTest extends FunctionalTest {

    @Test
    public void testThatIndexPageWorks() {
        Response response = GET("/");
        assertIsOk(response);
        assertContentType("text/html", response);
        assertCharset(play.Play.defaultWebEncoding, response);
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Thread.currentThread().setPriority(10);
			System.err.println(Thread.currentThread().getId()+":"+Thread.currentThread().getPriority());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
    
    static private String verifyName(String name) throws CloudException {
    	if( name == null ) {
    		return null;
    	}
    	StringBuilder str = new StringBuilder();
    	name = name.toLowerCase().trim();
    	if( name.length() > 255 ) {
    		String extra = name.substring(255);
    		int idx = extra.indexOf(".");
    		
    		if( idx > -1 ) {
    			throw new CloudException("S3 names are limited to 255 characters.");
    		}
    		name = name.substring(0,255);
    	}
        while( name.indexOf("--") != -1 ) {
            name = name.replaceAll("--", "-");         
        }
        while( name.indexOf("..") != -1 ) {
            name = name.replaceAll("\\.\\.", ".");         
        }
        while( name.indexOf(".-") != -1 ) {
            name = name.replaceAll("\\.-", ".");         
        }
        while( name.indexOf("-.") != -1 ) {
            name = name.replaceAll("-\\.", ".");         
        }
    	for( int i=0; i<name.length(); i++ ) {
    		char c = name.charAt(i);
    		
    		if( Character.isLetterOrDigit(c) ) {
    			str.append(c);
    		}
    		else {
    			if( i > 0 ) {
    				if( c == '/' ) {
    					c = '.';
    				}
    				else if( c != '.' && c != '-' && c != '(' && c != ')') {
    					c = '-';
    				}
    				str.append(c);
    			}
    		}
    	}
    	name = str.toString();
        while( name.indexOf("..") != -1 ) {
            name = name.replaceAll("\\.\\.", ".");         
        }
        if( name.length() < 1 ) { 
            return "000";
        }
    	while( name.charAt(name.length()-1) == '-' || name.charAt(name.length()-1) == '.' ) {
    		name = name.substring(0,name.length()-1);
            if( name.length() < 1 ) { 
                return "000";
            }
    	}
        if( name.length() < 1 ) { 
            return "000";
        }
        else if( name.length() == 1 ) {
    		name = name + "00";
    	}
    	else if ( name.length() == 2 ) {
    		name = name + "0";
    	}
    	return name;
    }
}